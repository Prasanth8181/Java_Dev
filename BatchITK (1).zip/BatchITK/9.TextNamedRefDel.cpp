#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include<string>
#include<tccore/item.h>


using namespace std;

int DeleteNamedRef()

{
	int ifail;
	tag_t dat = NULLTAG;
	int n_found;
	tag_t *ref = NULLTAG;
	char *name = NULL;                                                       
	tag_t obj = NULLTAG;


	
	AE_find_dataset2("pra", &dat);
	if(dat!=NULLTAG){}

	AOM_refresh(dat, 1);
	AE_remove_dataset_named_ref2(dat, "Text");
	AOM_save_without_extensions(dat);
	///*AOM_ask_name(dat, &name);
	//cout << name << endl;*/
		
	/*cout << n_found << endl;*/	
	AOM_refresh(dat, 0);
	return 0;

}


