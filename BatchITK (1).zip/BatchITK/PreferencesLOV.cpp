#include <iostream>
#include"Header.h"
#include<tccore/item.h>

#include<tccore/aom.h>

#include<tccore/aom_prop.h>//del from parent
#include<tc/preferences.h>

using namespace std;

int PreferenceLOV()
{
	char *value;
	tag_t tObj;
	PREF_ask_char_value("TC_config_rule_name", 0, &value);
	ITEM_find_rev("000457", "A", &tObj);

	//ITEM_find_item("000457", &tObj);
	AOM_refresh(tObj, 0);
	AOM_UIF_set_value(tObj, "object_desc", value);
	AOM_save_without_extensions(tObj);
	AOM_refresh(tObj, 1);


	return 0;
}

