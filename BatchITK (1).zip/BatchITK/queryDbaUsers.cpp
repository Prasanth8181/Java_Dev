#include <qry/qry.h>
#include "Header.h"
#include <tccore/item.h>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <iostream>

using namespace std;

int queryDbaUsers() {
	tag_t qry = NULLTAG;
	int n_entries = 0, n_found = 0;
	char **entries = nullptr, **values = nullptr, *value = nullptr;
	tag_t *results = nullptr;

	// Find the query
	checkiFail(QRY_find2("DbaUsers", &qry));

	if (qry != NULLTAG) {
		// Get user entries for the query
		checkiFail(QRY_find_user_entries(qry, &n_entries, &entries, &values));

		if (n_entries > 0 && entries != NULL && values != NULL) {
			// Execute the query
			checkiFail(QRY_execute(qry, n_entries, entries, values, &n_found, &results));

			if (results != NULL) {
				// Print user IDs
				for (int i = 0; i < n_found; i++) {
					checkiFail(AOM_ask_value_string(results[i], "user_id", &value));
					if (value != NULL) {
						cout << value << endl;
						MEM_free(value);
					}
				}
				MEM_free(results);
			}
			MEM_free(entries);
			MEM_free(values);
		}
	}
	return 0;
}

//#include<qry/qry.h>
//#include"Header.h"
//#include<tccore/item.h>
//#include<tccore/grm.h>
//#include<tccore/aom_prop.h>
//#include<iostream>
//
//using namespace std;
//
//int queryDbaUsers()
//{
//	tag_t qry;
//	QRY_find2("DbaUsers",&qry);
//	int n_entries;
//	char **entries;
//	char **values;
//	char *value;
//	
//	QRY_find_user_entries(qry, &n_entries,&entries,&values);
//	int n_found;
//	tag_t *results;
//	QRY_execute(qry,n_entries,entries,values,&n_found,&results);
//	for (int i = 0; i < n_found; i++) {
//		AOM_ask_value_string(results[i], "user_id", &value);
//
//		cout << value << endl;
//	}
//	return 0;
//}
