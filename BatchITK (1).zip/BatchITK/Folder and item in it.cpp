#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include<tc\folder.h>
#include<tccore/aom.h>
#include<tccore/tctype.h>
#include "Header.h"
#include<tccore/aom_prop.h>
using namespace std;

int CreateAttachFolder()
{
	int iFail = 0;

	tag_t tNewFolder = NULL;

	tag_t tCreate_input = NULL, tType = NULL, tBo = NULL;

	iFail = FL_create2("FolderP", "Desc", &tNewFolder);
	checkiFail(iFail);

	iFail = TCTYPE_ask_type("Item", &tType);
	checkiFail(iFail);



	iFail = TCTYPE_construct_create_input(tType, &tCreate_input);
	checkiFail(iFail);

	AOM_UIF_set_value(tCreate_input, "object_name", "Item_Name");
	AOM_UIF_set_value(tCreate_input, "object_desc", "Item_Desc");

	iFail = TCTYPE_create_object(tCreate_input, &tBo);
	checkiFail(iFail);

	iFail = FL_insert(tNewFolder, tBo, 1);
	checkiFail(iFail);

	iFail = ITEM_save_item(tBo);
	checkiFail(iFail);

	AOM_save_without_extensions(tNewFolder);

	return iFail;
}