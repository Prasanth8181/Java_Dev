#include <iostream>
#include<tccore/tctype.h>
#include <tcinit/tcinit.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include"Header.h"
#include<sa\user.h>
#include<tccore/item.h>

using namespace std;

int FormItemUpdate()
{
	//int ifail;
	tag_t FormType = NULL;
	tag_t create_input = NULL;
	tag_t bo = NULL;

	TCTYPE_ask_type("Item Master", &FormType);

	//TCTYPE_find_type("Item Master", "Form", &FormType);

	TCTYPE_construct_create_input(FormType, &create_input);

	AOM_UIF_set_value(create_input, "object_name", "Form_Name");//How to add name to the Item Master.
	AOM_UIF_set_value(create_input, "object_desc", "Form_Desc");


	TCTYPE_create_object(create_input, &bo);

	newstuffinsert("izn", bo);

	AOM_save_without_extensions(bo);



	tag_t tCreate_input = NULL, tType = NULL, tBo = NULL;

	
	int iFail;
	iFail = TCTYPE_ask_type("Item", &tType);
	checkiFail(iFail);



	iFail = TCTYPE_construct_create_input(tType, &tCreate_input);
	checkiFail(iFail);

	AOM_UIF_set_value(tCreate_input, "object_name", "Item_Name");
	AOM_UIF_set_value(tCreate_input, "object_desc", "Item_Desc");

	iFail = TCTYPE_create_object(tCreate_input, &tBo);
	checkiFail(iFail);
	tag_t foldertag;
	foldertag = newstuffinsert("izn", tBo);
	

	iFail = ITEM_save_item(tBo);
	checkiFail(iFail);
	

	AOM_save_without_extensions(foldertag);


	return 0;
}