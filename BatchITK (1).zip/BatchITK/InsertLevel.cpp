#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include"Header.h"

using namespace std;
int InsertLevel()
{
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tInsertI = NULLTAG, tInsertIR = NULLTAG, *child = NULL, tOut = NULLTAG;
	int iCount = 0;
	char *cChildName = NULL, *cQuantity;
	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
	const char *cFind = ITK_ask_cli_argument("-find=");
	const char *cInsertI = ITK_ask_cli_argument("-insertI=");
	const char *cInsertIR = ITK_ask_cli_argument("-insertIR=");
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
	checkiFail(ITEM_find_item(cInsertI, &tInsertI));
	checkiFail(ITEM_find_rev(cInsertI, cInsertIR, &tInsertIR));

	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
		checkiFail(BOM_create_window(&tWindow));
		if (tWindow != NULLTAG) {
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
			//checkiFail(AOM_save_without_extensions(tWindow));
			if (tBomLine != NULLTAG) {
				//checkiFail(AOM_save_without_extensions(tBomLine));
				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
				/*checkiFail(AOM_save_without_extensions(tWindow));
				checkiFail(AOM_save_without_extensions(tBomLine));*/
				for (int i = 0; i < iCount; i++) {
					
					//checkiFail(BOM_line_unpack(child[i]));
					checkiFail(AOM_ask_value_string(child[i], "bl_item_item_id", &cChildName));
					if (strcmp(cFind, cChildName) == 0) {
						tag_t childs[2] = { child[i],child[i + 1] };
						checkiFail(BOM_line_insert_level(2,childs,tInsertIR,NULL));
						checkiFail(AOM_save_without_extensions(child[i]));
						//checkiFail(AOM_save_without_extensions(child[i]));
					}

					checkiFail(AOM_save_without_extensions(tBomLine));
					checkiFail(AOM_save_without_extensions(tWindow));
				}
				//checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
				/*
				for (int i = 0; i < iCount; i++) {
					checkiFail(AOM_ask_value_string(child[i], "bl_quantity", &cQuantity));
					cout << cQuantity;
					cout << cChildName << endl;
				}*/
				checkiFail(BOM_save_window(tWindow));
				checkiFail(BOM_close_window(tWindow));
			}
		}
	}
	return 0;
}