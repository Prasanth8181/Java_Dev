#include<sa/user.h>
#include <iostream>
#include<tccore/aom.h>
#include"Header.h"
int AllUsers() {
	int n_users = 0;
	tag_t* users = NULL;

	// Initialize os_user_name to avoid undefined behavior
	char* os_user_name = nullptr;

	// Get the list of users
	checkiFail(SA_extent_user(&n_users, &users));

	// Check if users list is not NULL
	if (users != NULL) {
		// Iterate through the users and print their OS user names
		for (int i = 0; i < n_users; i++) {
			checkiFail(SA_ask_os_user_name2(users[i], &os_user_name));
			checkiFail(AOM_ask_name(users[i], &os_user_name));
			cout << os_user_name << endl;
		}
	}
	else {
		cout << "Error: Users list is NULL." << endl;
	}

	return 0;
}