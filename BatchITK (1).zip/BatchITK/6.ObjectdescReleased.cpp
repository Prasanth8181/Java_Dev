#include"Header.h"
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tccore/item.h>
#include <iostream>
#include <tccore/workspaceobject.h>
#include<res/res_itk.h>
//#include<tc/tc_startup.h>
using namespace std;
int ObjectdescReleased()
{
	// Initialize variables
	tag_t tItem = NULLTAG;
	tag_t* tValue = NULL;
	int iNum = 0;

	// Find the item revision with ID "000476" and revision "A"
	checkiFail(ITEM_find_rev("000498", "A", &tItem));

	// Check if the item tag is not NULLTAG
	if (tItem != NULLTAG) {
		// Set bypass to true
		ITK_set_bypass(true);

		// Refresh the item
		AOM_refresh(tItem, 1);

		// Get the release status list of the item
		checkiFail(AOM_ask_value_tags(tItem, "release_status_list", &iNum, &tValue));

		// Check if there are any release statuses
		if (iNum > 0) {
			// Set the object description to "Released"
			checkiFail(AOM_set_value_string(tItem, "object_desc", "Released"));
			cout << "inside if" << endl;
		}

		// Save the item without extensions
		AOM_save_without_extensions(tItem);

		// Refresh the item again
		AOM_refresh(tItem, 0);

		// Print the number of release statuses
		cout << iNum << endl;
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}