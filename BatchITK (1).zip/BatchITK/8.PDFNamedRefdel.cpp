#include <iostream>

#include <ae/dataset.h>

#include <ae/datasettype.h>

#include <tcinit/tcinit.h>

#include <tccore/aom.h>

#include <string>

#include"Header.h"
#include<tccore/aom_prop.h>


using namespace std;

int DelNamedRefofDataset()

{

	/*char*in = ITK_ask_cli_argument("-i=");*/
	//tag_t dataset = NULLTAG;

	//AE_reference_type_t referenceType;

	//tag_t refObj = NULLTAG;

	//int n_found;

	//tag_t *ref = NULL;

	//char * refName = NULL;

	//char *name = NULL;

	//checkiFail(AE_find_dataset2("asd", &dataset));

	//checkiFail(AE_ask_dataset_named_refs(dataset, &n_found, &ref));

	//for (int i = 0; i < n_found; i++)

	//{
	//	//checkiFail(AOM_refresh(dataset, true));

	//	//checkiFail(AOM_refresh(ref[0], 1));
	//	//checkiFail(AE_find_dataset_named_ref2(dataset, 0, &refName, &referenceType, &refObj));
	//	//
	//	//checkiFail(AE_remove_dataset_named_ref2(dataset, refName));
	//	///*AE_replace_dataset_named_ref2(dataset,refObj,"pavan",referenceType,refObj);*/
	//	////AOM_set_value_string(ref[i], "original_file_name",in);
	//	//checkiFail(AOM_save_without_extensions(ref[i]));
	//	//checkiFail(AOM_refresh(dataset, false));
	//	//checkiFail(AOM_refresh(ref[0], 0));
	//	AOM_refresh(dataset, true);
	//	checkiFail(AE_find_dataset_named_ref2(dataset, 0, &refName, &referenceType, &refObj));
	//	checkiFail(AE_remove_dataset_named_ref2(dataset, refName));
	//	AOM_save_without_extensions(dataset);
	//	AOM_refresh(dataset, false);

	//}

	//cout << n_found << endl;

	//return 0;
	tag_t dataset = NULLTAG;
	AE_reference_type_t referenceType;
	tag_t refObj = NULLTAG;
	int n_found;
	tag_t *ref = NULL;
	char * refName = NULL;
	char *name = NULL;

	checkiFail(AE_find_dataset2("ppf", &dataset));

	checkiFail(AE_ask_dataset_named_refs(dataset, &n_found, &ref));
	/*for (int i = 0; i < n_found; i++)
	{*/
		AOM_refresh(dataset, true);
		checkiFail(AE_find_dataset_named_ref2(dataset, 0,& refName, &referenceType, &refObj));
		checkiFail(AE_remove_dataset_named_ref2(dataset, &refName[0]));
		AOM_save_without_extensions(dataset);
		AOM_refresh(dataset, false);
	//}

	cout << n_found << endl;

	return 0;

}

