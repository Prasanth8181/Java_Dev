#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include"Header.h"

using namespace std;


int LatestRevision()
{

	// Initialize variables
	tag_t tItem = NULLTAG, tRev = NULLTAG;
	char* cName = NULL;
	char* cRevID = NULL;

	// Find the item with ID "000476"
	checkiFail(ITEM_find_item("000476", &tItem));

	// Check if the item tag is not NULLTAG
	if (tItem != NULLTAG) {
		// Get the latest revision of the item
		checkiFail(ITEM_ask_latest_rev(tItem, &tRev));

		// Check if the revision tag is not NULLTAG
		if (tRev != NULLTAG) {
			// Get the name of the revision
			checkiFail(ITEM_ask_rev_name2(tRev, &cName));

			// Get the revision ID
			checkiFail(ITEM_ask_rev_id2(tRev, &cRevID));

			// Print the name and revision ID
			cout << cName << " " << cRevID << endl;

			// Free the memory allocated for the name and revision ID
			MEM_free(cName);
			MEM_free(cRevID);
		}
		else {
			cout << "Error: Latest revision not found or revision tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}