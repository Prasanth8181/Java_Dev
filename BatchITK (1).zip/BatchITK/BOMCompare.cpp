#include <tccore/item.h>
#include <ps/ps.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <string>
#include <iostream>
#include "Header.h"

using namespace std;

int BOMCompare() {
	tag_t tWindow1 = NULLTAG, tTopI1 = NULLTAG, tTopIR1 = NULLTAG, tTopI2 = NULLTAG, tTopIR2 = NULLTAG;
	tag_t tBomLine1 = NULLTAG, tBomLine2 = NULLTAG, *child = NULL, tWindow2 = NULLTAG, *tReportItems = NULL;
	int iCount1 = 0, iCount2 = 0, iLength = 0;
	char **cLines = nullptr;
	const char *ctopI1 = ITK_ask_cli_argument("-topI1=");
	const char *ctopIR1 = ITK_ask_cli_argument("-topIR1=");
	const char *ctopI2 = ITK_ask_cli_argument("-topI2=");
	const char *ctopIR2 = ITK_ask_cli_argument("-topIR2=");

	// Find the items and their revisions
	checkiFail(ITEM_find_item(ctopI1, &tTopI1));
	checkiFail(ITEM_find_item(ctopI2, &tTopI2));
	checkiFail(ITEM_find_rev(ctopI1, ctopIR1, &tTopIR1));
	checkiFail(ITEM_find_rev(ctopI2, ctopIR2, &tTopIR2));

	if (tTopI1 != NULLTAG && tTopIR1 != NULLTAG && tTopI2 != NULLTAG && tTopIR2 != NULLTAG) {
		// Create BOM windows
		checkiFail(BOM_create_window(&tWindow1));
		checkiFail(BOM_create_window(&tWindow2));

		if (tWindow1 != NULLTAG && tWindow2 != NULLTAG) {
			// Set top lines for BOM windows
			checkiFail(BOM_set_window_top_line(tWindow1, tTopI1, tTopIR1, NULLTAG, &tBomLine1));
			checkiFail(BOM_set_window_top_line(tWindow2, tTopI2, tTopIR2, NULLTAG, &tBomLine2));

			if (tBomLine1 != NULLTAG && tBomLine2 != NULLTAG) {
				// Get all child lines for both BOM lines
				checkiFail(BOM_line_ask_all_child_lines(tBomLine1, &iCount1, &child));
				checkiFail(BOM_line_ask_all_child_lines(tBomLine2, &iCount2, &child));

				// Compare BOM lines
				checkiFail(BOM_compare(tBomLine1, tBomLine2, 2, 4));
				checkiFail(BOM_compare_report(NULLTAG, &iLength, &cLines, &tReportItems));

				// Print comparison report
				for (int i = 0; i < iLength; i++) {
					cout << cLines[i] << endl;
				}

				// Save and close BOM windows
				checkiFail(BOM_save_window(tWindow1));
				checkiFail(BOM_close_window(tWindow1));
				checkiFail(BOM_save_window(tWindow2));
				checkiFail(BOM_close_window(tWindow2));

				// Free allocated memory
				MEM_free(cLines);
				MEM_free(tReportItems);
			}
		}
	}
	return 0;
}
