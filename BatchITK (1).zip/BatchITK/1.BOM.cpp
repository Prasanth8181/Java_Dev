#include <tccore/item.h>
#include <ps/ps.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <fstream>
#include <string>
#include <iostream>
#include"Header.h"
using namespace std;

int BOM() {
	tag_t tTopI = NULLTAG, tTopIR = NULLTAG, tBomView = NULLTAG, tBvr = NULLTAG, tWindow = NULLTAG, tBomLine = NULLTAG;
	tag_t tChild1I = NULLTAG, tChild1IR = NULLTAG, tNew1BomLine = NULLTAG;
	ifstream inFile("input.txt");
	string rev, line, Item;
	char* cItem = nullptr, *crev = nullptr, *cItem1 = nullptr, *crev1 = nullptr;

	// Read the first line from the input file
	getline(inFile, line);
	size_t hyphenPos = line.find('-');
	if (hyphenPos != string::npos) {
		Item = line.substr(0, hyphenPos);
		rev = line[hyphenPos + 2];
		cItem = new char[Item.length() + 1];
		strcpy(cItem, Item.c_str());
		crev = new char[2];
		strcpy(crev, rev.c_str());

		// Find the item and its revision
		checkiFail(ITEM_find_item(cItem, &tTopI));
		cout << cItem << endl;
		checkiFail(ITEM_find_rev(cItem, crev, &tTopIR));
		cout << crev << endl;

		// Create BOM view and BVR
		checkiFail(PS_create_bom_view(NULLTAG, NULL, NULL, tTopI, &tBomView));
		checkiFail(AOM_save_without_extensions(tBomView));
		checkiFail(AOM_save_without_extensions(tTopI));
		checkiFail(PS_create_bvr(tBomView, NULL, NULL, false, tTopIR, &tBvr));
		checkiFail(AOM_save_without_extensions(tBvr));
		checkiFail(AOM_save_without_extensions(tTopIR));

		// Create BOM window and set top line
		checkiFail(BOM_create_window(&tWindow));
		checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
		checkiFail(AOM_save_without_extensions(tBomLine));

		// Process the rest of the lines in the input file
		while (getline(inFile, line)) {
			size_t hyphenPos = line.find('-');
			if (hyphenPos != string::npos) {
				Item = line.substr(0, hyphenPos);
				rev = line[hyphenPos + 2];
				cItem1 = new char[Item.length() + 1];
				strcpy(cItem1, Item.c_str());
				crev1 = new char[2];
				strcpy(crev1, rev.c_str());

				// Find the child item and its revision
				checkiFail(ITEM_find_item(cItem1, &tChild1I));
				checkiFail(ITEM_find_rev(cItem1, crev1, &tChild1IR));

				// Add the child item to the BOM line
				checkiFail(BOM_line_add(tBomLine, tChild1I, tChild1IR, NULLTAG, &tNew1BomLine));
				checkiFail(AOM_save_without_extensions(tNew1BomLine));
			}
		}

		// Save and close the BOM window
		checkiFail(BOM_save_window(tWindow));
		checkiFail(BOM_close_window(tWindow));

		// Free allocated memory
		MEM_free(cItem);
		MEM_free(crev);
		MEM_free(cItem1);
		MEM_free(crev1);

		return 0;
	}
	return -1;
}
