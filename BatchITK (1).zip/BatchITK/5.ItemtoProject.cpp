#include"Header.h"
#include<tccore/project.h>
#include<tccore/item.h>
#include<tccore/aom.h>
#include<iostream>

using namespace std;

int projAssignObject()
{

	// Initialize variables
	tag_t tProject = NULLTAG;
	tag_t tItem = NULLTAG;

	// Find the project with the name "ITK"
	checkiFail(PROJ_find("ITK", &tProject));

	// Check if the project tag is not NULLTAG
	if (tProject != NULLTAG) {
		cout << "Project tag: " << tProject << endl;

		// Find the item with ID "000501"
		checkiFail(ITEM_find_item("000499", &tItem));

		// Check if the item tag is not NULLTAG
		if (tItem != NULLTAG) {
			cout << "Item tag: " << tItem << endl;

			// Refresh the item
			AOM_refresh(tItem, true);

			// Assign the item to the project
			checkiFail(PROJ_assign_objects(1, &tProject, 1, &tItem));

			cout << "Item assigned to project: " << tItem << endl;

			// Save the item without extensions
			AOM_save_without_extensions(tItem);

			// Refresh the item again
			AOM_refresh(tItem, false);
		}
		else {
			cout << "Error: Item not found or item tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Project not found or project tag is NULLTAG." << endl;
	}

	return 0;
}
//#include"Header.h"
//#include <tccore/project.h>
//#include <tccore/item.h>
//#include <tccore/aom.h>
//#include <iostream>
//
//using namespace std;
//
//int projAssignObject() {
//	tag_t tProject;
//	tag_t tItem;
//	int status;
//
//	status = PROJ_find("KA", &tProject);
//	if (status != ITK_ok) {
//		cout << "Error in PROJ_find: " << status << endl;
//		return status;
//	}
//	cout << "Project tag: " << tProject << endl;
//
//	status = ITEM_find_item("000469", &tItem);
//	if (status != ITK_ok) {
//		cout << "Error in ITEM_find_rev: " << status << endl;
//		return status;
//	}
//	cout << "Item tag: " << tItem << endl;
//
//	status = AOM_refresh(tItem, true);
//	if (status != ITK_ok) {
//		cout << "Error in AOM_refresh: " << status << endl;
//		return status;
//	}
//
//	status = PROJ_assign_objects(1, &tProject, 1, &tItem);
//	if (status != ITK_ok) {
//		cout << "Error in PROJ_assign_objects: " << status << endl;
//		return status;
//	}
//	cout << "Assigned item to project." << endl;
//
//	status = AOM_save_without_extensions(tItem);
//	if (status != ITK_ok) {
//		cout << "Error in AOM_save_without_extensions: " << status << endl;
//		return status;
//	}
//
//	status = AOM_refresh(tItem, false);
//	if (status != ITK_ok) {
//		cout << "Error in AOM_refresh: " << status << endl;
//		return status;
//	}
//
//	return ITK_ok;
//}