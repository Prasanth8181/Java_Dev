#include <iostream>
#include <tcinit/tcinit.h>
#include<tc/emh.h>

using namespace std;

int ITK_user_main(int argc, char* argv[])
{ 
	int ifail = 0;
	char* Message = NULL;
	
	ifail = ITK_auto_login();
	
	if (ifail == 0)
	{
		cout << "Login success" << endl;
	}
	else
	{
		EMH_ask_error_text(ifail, &Message);
		cout << "\n" << Message;
	}

	return 0;
}