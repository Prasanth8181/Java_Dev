#include<sa/user.h>
#include <iostream>
#include<tccore/aom.h>
#include"Header.h"
int inactiveUser() {
	tag_t user;
	//int    user_status;          /**< (I) The user status. Valid values are <ul><li>0: active</li><li>1: inactive</li></ul> */
	//	int    license_level;        /**< (I) The license level. Valid values are <ul><li>0: author</li><li>1: consumer</li><li>2: occasional author</li></ul> */
	//	const char *license_bundle;  /**< (I) The license bundle.  This should be a valid bundle name or null. */
		//int    purchase;        /**< (O) Number of purchased licenses */
		//int    used;                /**< (O) Number of used licenses */
		//int    purchased_bundles; /**< (O) Number of purchased bundles */
		//int    used_bundles;
		//int    purchased;           /**< (O) Number of purchased licenses */
		//int    used;               /**< (O) Number of used licenses */
		//int    purchased_bundles;   /**< (O) Number of purchased bundles */
		//int    used_bundles;
	

	checkiFail(SA_find_user2("izn", &user));
	cout << user;
	cout << "1";
	checkiFail(AOM_refresh(user, 1));
	cout << "2";
	//SA_set_user_license_status(user,1,0,NULL,&purchase,&used,&purchased_bundles,&used_bundles);
	checkiFail(SA_set_user_status(user, 0));
	/*SA_set_user_license_status_with_server(user, 1, 0, NULL, NULL, &purchased, &used, &purchased_bundles, &used_bundles);*/
	checkiFail(AOM_save_without_extensions(user));
	checkiFail(AOM_refresh(user, 0));
	return 0;
}