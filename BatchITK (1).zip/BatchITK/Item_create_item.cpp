//create item
#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include"Header.h"

using namespace std;


int CreateItem()
{
	tag_t tItem = NULLTAG;
	tag_t tRev = NULLTAG;



	if (tItem != NULLTAG && tRev != NULLTAG) {
		checkiFail(ITEM_create_item("000599 ", "ITKCreate", NULL, NULL, &tItem, &tRev));
		checkiFail(ITEM_save_item(tItem));
	}
	else {
		cout << "Error: Item or Revision tag is NULLTAG." << endl;
	}

	return 0;
	

}









//int ITK_user_main(int argc, char* argv[])
//{
//	int ifail = 0;
//	char* Message = NULL;
//
//	tag_t item = NULL;
//	tag_t rev = NULL;
//
//	ifail = ITK_auto_login();
//
//	if (ifail == 0)
//	{
//		cout << "Login success" << endl;
//	}
//	else
//	{
//		EMH_ask_error_text(ifail, &Message);
//		cout << "\n" << Message;
//	}
//
//	ITEM_create_item("000555", "ITKCreate", NULL, NULL, &item, &rev);
//
//	ITEM_save_item(item);
//
//	return 0;
//}