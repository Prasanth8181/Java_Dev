#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include"Header.h"



using namespace std;

int create_dataset()
{
	int iFail = 0;
	tag_t tPdftype = NULL;
	tag_t tDat = NULL;
	loginCLI();

	iFail=AE_find_datasettype2("PDF", &tPdftype);//dataset type
	checkiFail(iFail);
	
	iFail = AE_create_dataset_with_id(tPdftype, "PawanK", NULL, NULL, NULL, &tDat);//create dataset
	checkiFail(iFail);

	iFail = AE_save_myself(tDat);//save dataset
	checkiFail(iFail);
	
	return 0;
}
