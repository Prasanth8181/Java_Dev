#include "Header.h"
using namespace std;

int ITK_user_main(int argc, char* argv[])
{
	loginCLI();
	//change_ownership("000178", "infodba", "dba");
	//createInactiveUser();
	//CreateAttachFolder();
	//create_dataset();
	//CreateItem();
	//ItemAttachHomeFolder();
	//AllUsers();
	//where_referenced();//
	//where_used();
	//allprops();
	//SecondaryObjects();
	//FormItemUpdate();
	//projAssignMember();
	//queryDbaUsers();
	//SecondaryObjectslistPDFdel();
	//iDelete_datsets();
	//queryDbaItems();
	//Preference_valueObj_Desc();
	//SendMail();
	//preferencebycomma();
	//ArrayPropType();
	//BOM();
	//LOVselect();
	//inactiveUser();
	//ObjectdescReleased();
	//projAssignObject();
	//datasetwithNamedRef();
	//DeleteNamedRef();
	//DelNamedRefofDataset();//**
	//ItemRevisionsStatus();
	//globalalternate();
	//localsubstitute();
	//ObjectdescwithoutDate();
	//LatestRevision();
	//DeleteUserMailBox();
	//PackUnpack();
	//SplitOccurence();
	//InsertLevel();
	//BOMCompare();
	//BaseLine();
	//multiBOM();
	//iCreate_BOM();
	//ExportIRtoXML();
	//OccurrenceEffectivity();
	//RevisionEffectivity();
	//printBOM("000475", "A");
	ApplyRevRule();
	return 0;
}