#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include"Header.h"
#include<tccore/aom_prop.h>
#include<tccore/aom.h>
#include<tccore/releasestatus.h>

using namespace std;


int ItemRevisionsStatus()
{

	// Initialize variables
	int iCount = 0;
	tag_t tItem = NULLTAG;
	tag_t* tItemRevs = NULL;
	tag_t tRelease = NULLTAG;

	// Find the item with ID "000777"
	checkiFail(ITEM_find_item("000499", &tItem));

	// Check if the item tag is not NULLTAG
	if (tItem != NULLTAG) {
		// List all revisions of the item
		checkiFail(ITEM_list_all_revs(tItem, &iCount, &tItemRevs));

		// Check if the item revisions were successfully listed
		if (tItemRevs != NULL) {
			// Create a custom release status
			checkiFail(RELSTAT_create_release_status("CustomStatus", &tRelease));

			// Check if the release status was successfully created
			if (tRelease != NULLTAG) {
				// Add the release status to all item revisions
				checkiFail(RELSTAT_add_release_status(tRelease, iCount, tItemRevs, true));

				// Iterate through the item revisions and save each one
				for (int i = 0; i < iCount; i++) {
					AOM_save_without_extensions(tItemRevs[i]);
				}
			}
			else {
				cout << "Error: Failed to create release status." << endl;
			}

			// Free the memory allocated for item revisions
			MEM_free(tItemRevs);
		}
		else {
			cout << "Error: Failed to list item revisions or item revisions are NULL." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;


}