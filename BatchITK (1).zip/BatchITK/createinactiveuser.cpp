#include <stdio.h>
#include <iostream> // cout
#include <tcinit/tcinit.h> //auto login
#include <sa/user.h> //create user
#include <tccore/aom.h> // save
#include <sa/group.h> // take group
#include"Header.h"

using namespace std;

int createInactiveUser()
{
	int iFail = 0;
	tag_t tUser = NULL, tGroup = NULL,tRole = NULL;

	//iFail = SA_create_user_with_license_information("win", "win", "win", 1, NULL, NULL, 1, &user);
	iFail = SA_create_user2("rin", "rin", "rin", &tUser);
	checkiFail(iFail);


	iFail = SA_find_role2("DBA", &tRole);
	checkiFail(iFail);

	iFail=SA_find_group("dba", &tGroup);
	checkiFail(iFail);

	iFail=SA_set_group_default_role(tGroup, tRole);
	checkiFail(iFail);

	iFail=SA_set_user_login_group(tUser, tGroup);
	checkiFail(iFail);
	

	iFail=SA_set_os_user_name2(tUser, "WindowsOS");
	checkiFail(iFail);

	iFail = AOM_save_without_extensions(tUser);
	checkiFail(iFail);

	return iFail;

}