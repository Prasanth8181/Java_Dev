#include "Header.h"
#include <tc/envelope.h>
#include <sa/user.h>
#include<tccore/workspaceobject.h>
#include <tc/folder.h>
#include<tccore/grm.h>
#include<tccore/aom_prop.h>
#include<tccore/aom.h>
#include<iostream>
using namespace std;
int DeleteUserMailBox()
{
	// Initialize variables
	tag_t tEnvelope = NULLTAG;
	tag_t tUser = NULLTAG;
	int iHits = 0, iNum = 0;
	tag_t* tList = NULL;
	tag_t tFolder = NULLTAG;
	tag_t* tValues = NULL;

	// Find the user with the username "izn"
	checkiFail(SA_find_user2("izn", &tUser));

	// Check if the user tag is not NULLTAG
	if (tUser != NULLTAG) {
		// Get the user's mailbox folder
		checkiFail(SA_ask_user_mailbox(tUser, &tFolder));

		// Check if the folder tag is not NULLTAG
		if (tFolder != NULLTAG) {
			// Get the contents of the folder
			checkiFail(AOM_ask_value_tags(tFolder, "contents", &iNum, &tValues));

			// Iterate through the contents and delete each item from the folder
			for (int i = 0; i < iNum; i++) {
				checkiFail(AOM_delete_from_parent(tValues[i], tFolder));
			}
		}
		else {
			cout << "Error: User mailbox folder is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: User not found or user tag is NULLTAG." << endl;
	}

	return 0;
}