#include <iostream>
#include<tccore/tctype.h>
#include <tcinit/tcinit.h>
#include<tccore/aom.h>
#include<tccore/aomprop.h>


using namespace std;

int ITK_user_main(int argc, char* argv[])
{
	int ifail;
	tag_t FormType = NULL;
	tag_t create_input = NULL;
	tag_t bo = NULL;

	ifail = ITK_auto_login();
	//TCTYPE_ask_type("Item Master", &FormType);

	TCTYPE_find_type("Item Master", "Form", &FormType);

	TCTYPE_construct_create_input(FormType, &create_input);

	
	AOM_UIF_set_value(tCreate_input, "object_name", "ITK_Document3");//How to add name to the Item Master.


	TCTYPE_create_object(create_input, &bo);

	AOM_save_without_extensions(bo);


	return 0;
}