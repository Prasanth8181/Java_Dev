#include <stdio.h>
#include <tcinit/tcinit.h> //auto login
#include <tccore/item.h> // item find item ...save?
#include <tccore/aom_prop.h> // set property
#include <tccore/aom.h>  // checkout
#include <tc/preferences.h> // preference value

using namespace std;

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;

	char *cValue = NULL;


	tag_t tItemRev = NULL;

	iFail = ITK_auto_login();

	PREF_ask_char_value("TC_config_rule_name", 0, &cValue);

	ITEM_find_rev("000440", "A", &tItemRev);
	AOM_refresh(tItemRev, 0);

	//AOM_UIF_set_value(tItemRev, "object_desc",cValue);

	AOM_set_value_string(tItemRev, "object_desc", cValue);

	//USER INTERFACE
	// get tYPED reference property ..object type / object string ...not using uIF..

	AOM_save_without_extensions(tItemRev);//other than item_save_item and tctype.. common for dataset and item.->(aom_save_without_extensions)

	AOM_refresh(tItemRev, 1);

	return iFail;

}