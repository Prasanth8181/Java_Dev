#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <string>


using namespace std;

int datasetwithNamedRef()

{
	int ifail;
	tag_t dat = NULLTAG;
	int n_found;
	tag_t *ref = NULLTAG;
	char *name = NULL;

	AE_find_dataset2("PDF", &dat);
	AE_ask_dataset_named_refs(dat, &n_found, &ref);  
	for (int i = 0; i < n_found; i++)

	{
		AOM_ask_name(ref[i], &name);
		cout << name << endl;
	}
	cout << n_found << endl;
	return 0;

}


