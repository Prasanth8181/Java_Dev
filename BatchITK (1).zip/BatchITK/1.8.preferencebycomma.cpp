#include "Header.h"
#include <iostream>
#include <tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tc/preferences.h>

using namespace std;

int preferencebycomma() {
	// Initialize variables
	tag_t tRev = NULLTAG;
	char* cValue = nullptr;

	// Ask for the custom preference value
	checkiFail(PREF_ask_char_value("custompref", 0, &cValue));
	cout << cValue << endl;

	// Tokenize the preference value to get individual values
	char* cPrefValues = strtok(cValue, ",");
	char* val1 = cPrefValues;
	cout << val1 << endl;
	cPrefValues = strtok(NULL, ",");
	char* val2 = cPrefValues;
	cout << val2 << endl;

	// Find the item revision with ID "000471" and revision "A"
	checkiFail(ITEM_find_rev("000471", "A", &tRev));

	// Check if the item revision tag is not NULLTAG
	if (tRev != NULLTAG) {
		// Refresh the item revision
		checkiFail(AOM_refresh(tRev, 1));

		// Set the custom properties with the tokenized values
		checkiFail(AOM_UIF_set_value(tRev, "a2customprop1", val1));
		checkiFail(AOM_UIF_set_value(tRev, "a2customprop2", val2));

		// Save the item revision without extensions
		checkiFail(AOM_save_without_extensions(tRev));

		// Refresh the item revision again
		checkiFail(AOM_refresh(tRev, 0));
	}
	else {
		cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
	}

	// Free allocated memory
	MEM_free(cValue);

	return 0;
}
