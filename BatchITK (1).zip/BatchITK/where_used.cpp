#include <tccore/aom.h>
#include <tccore/workspaceobject.h>
#include "Header.h"
#include <fstream>
#include <ps/ps.h>
#include <iostream>

using namespace std;

int where_used() {
	int tHits = 0;
	tag_t* tList = NULLTAG;
	int iParents = 0;
	int* iLevels = nullptr;
	tag_t* tParents = nullptr;
	char* cName = nullptr;

	// Find items with the name "frame"
	checkiFail(WSOM_find2("frame", &tHits, &tList));

	// Check if the list is not empty and the first item is not NULLTAG
	if (tHits > 0 && tList[0] != NULLTAG) {
		// Find all parents of the first item in the list
		checkiFail(PS_where_used_all(tList[0], -1, &iParents, &iLevels, &tParents));

		// Iterate through the parents and print their names
		for (int i = 0; i < iParents; i++) {
			checkiFail(AOM_ask_name(tParents[i], &cName));
			if (cName != nullptr) {
				cout << cName << endl;
				MEM_free(cName);
			}
		}

		// Free allocated memory
		MEM_free(tParents);
		MEM_free(iLevels);
	}
	else {
		cout << "Error: No items found or first item is NULLTAG." << endl;
	}

	// Free allocated memory
	MEM_free(tList);

	return 0;
}
