#include <iostream>
#include<stdio.h>
#include <tcinit/tcinit.h>//login using TC_init_module
#include"Header.h"
using namespace std;

#define PRINT_HELP {  \
cout << "\n"; \
cout << "usage: Utility used to login Teamcenter following arguments: \n" << endl; \
cout << "\t\t -u = [user name] Name of the Teamcenter user \n" << endl; \
cout << "\t\t -p = [password] Password of the Teamcenter user \n" << endl; \
cout << "\t\t -g = [group name] group of the Teamcenter user \n" << endl; \
}

int loginCLI(){
{
	int iFail = 0;
	char* cMessage = NULL;

	if ((ITK_ask_cli_argument("-h") != NULL))
	{
		PRINT_HELP;
		exit(0);
	}
	const char* cUsername = ITK_ask_cli_argument("-u=");
	const char* cPassword = ITK_ask_cli_argument("-p=");
	const char* cGroup = ITK_ask_cli_argument("-g=");

	iFail = TC_init_module(cUsername, cPassword, cGroup);

	checkiFail(iFail);

	return 0;
}
}