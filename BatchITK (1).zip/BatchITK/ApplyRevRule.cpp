#include <tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include <fclasses/tc_date.h>
#include <tccore/releasestatus.h>
#include "Header.h"
#include<cfm/cfm.h>
#include<bom/bom.h>

using namespace std;

int ApplyRevRule() {
	
	int iCount = 0;
	char *cName=NULL;
	tag_t tEnd = NULLTAG, tNewRule=NULL, tWindow=NULLTAG,tEndR=NULLTAG, tBom=NULLTAG, tConfig = NULLTAG, *tChildren=NULLTAG;
	const char *cEnd = ITK_ask_cli_argument("-end=");
	checkiFail(ITEM_find_item(cEnd, &tEnd));
	checkiFail(ITEM_find_rev(cEnd, "A", &tEndR));
	//const char *cFind = ITK_ask_cli_argument("-find=");
	
	
	checkiFail(CFM_rule_create("NewRevRule", "Desc", &tNewRule));
	checkiFail(CFM_rule_set_unit(tNewRule,5));
	checkiFail(CFM_rule_set_end_item(tNewRule, tEnd));
	checkiFail(AOM_save_without_extensions(tNewRule));
	checkiFail(BOM_create_window(&tWindow));
	checkiFail(BOM_set_window_top_line(tWindow, tEnd, tEndR, NULLTAG, &tBom));
	checkiFail(AOM_save_without_extensions(tWindow));
	checkiFail(AOM_save_without_extensions(tBom));
	checkiFail(BOM_set_window_config_rule(tWindow,tConfig));
	checkiFail(BOM_save_window(tWindow));
	//checkiFail(BOM_close_window(tWindow));
	//checkiFail(BOM_line_ask_all_child_lines(tBom, &iCount, &tChildren));
	//cout << iCount << endl;
//	for (int i = 0; i < iCount; i++)
//	{
//		//AOM_ask_value_string(tChildren[i], "bl_item_item_id", &cName);
//		
////		cout << cName << endl;
//		AOM_ask_value_string(tChildren[i], "bl_indented_title", &cName);
//		cout << cName << endl;
//	}o
	cout << "print";
	printBOM("000482", "A");

	// Find the item revision
	return 0;
}

//#include<tccore/item.h>
//#include <tccore/aom_prop.h>
//#include <tccore/aom.h>
//#include <tcinit/tcinit.h>
//#include <iostream>
//#include <tccore/item.h>
//#include <fclasses/tc_date.h>
//#include <tccore/releasestatus.h>
//#include"Header.h"
//using namespace std;
//int RevisionEffectivity()
//{
//	int iFail = 0, iNum=0, iStartEnd[] = { 1,9 };
//	
//	tag_t tFind = NULLTAG, *tStatuss=NULL, tEnd = NULLTAG, tEff=NULLTAG,*tEffs=NULL;
//	const char *cFind = ITK_ask_cli_argument("-find=");
//	const char *cEnd = ITK_ask_cli_argument("-end=");
//
//	
//
//	checkiFail(ITEM_find_rev(cFind,"A" ,&tFind));
//	//checkiFail(ITEM_find_item(cEnd,&tEnd));
//	if (tFind != NULLTAG) {
//		checkiFail(WSOM_ask_release_status_list(tFind, &iNum, &tStatuss));
//		cout << iNum << endl;
//		
//		//checkiFail(WSOM_effectivity_create(tStatuss[0], tEnd, &tEff));
//		//checkiFail(WSOM_eff_set_unit_range(tStatuss[0], tEff, "1-9", true));
//		//checkiFail(WSOM_eff_set_date_range(tStatuss[0], tEff, "01-Nov-2024 00:00 to 30-Nov-2024 00:00", true));
//		//checkiFail(AOM_save_without_extensions(tEff));
//		checkiFail(WSOM_status_ask_effectivities(tStatuss[0],&iNum,&tEffs));
//
//		checkiFail(WSOM_status_remove_effectivity(tStatuss[0], tEffs[0]));
//		checkiFail(AOM_save_without_extensions(tEffs[0]));
//	}
//	return 0;
//}
////checkiFail(RELSTAT_set_unit_effectivity(tStatuss[0],1,9));
//		//checkiFail(WSOM_eff_create_with_unit_text(tStatuss[0], tEnd,"1-9", &tEff));