#include <tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include "Header.h"

using namespace std;

int globalalternate() {
	tag_t tItem1 = NULLTAG, tItem2 = NULLTAG;
	tag_t tFind = NULLTAG;
	const char *cFind = ITK_ask_cli_argument("-find=");
	const char *cSub1 = ITK_ask_cli_argument("-a1=");
	const char *cSub2 = ITK_ask_cli_argument("-a2=");

	// Find the items
	checkiFail(ITEM_find_item(cFind, &tFind));
	checkiFail(ITEM_find_item(cSub1, &tItem1));
	checkiFail(ITEM_find_item(cSub2, &tItem2));

	if (tFind != NULLTAG && tItem1 != NULLTAG && tItem2 != NULLTAG) {
		tag_t tArrItems[] = { tItem1, tItem2 };

		// Add related global alternates
		checkiFail(ITEM_add_related_global_alternates(tFind, 2, tArrItems));

		if (tArrItems != NULL) {
			// Prefer the first global alternate
			checkiFail(ITEM_prefer_global_alternate(tFind, tArrItems[0]));
		}
	}

	return 0;
}
//#include<tccore/item.h>
//#include <tccore/aom_prop.h>
//#include <tccore/aom.h>
//#include <tcinit/tcinit.h>
//#include <iostream>
//#include <tccore/item.h>
//#include"Header.h"
//using namespace std;
//int globalalternate()
//{
//	int iFail = 0;
//	tag_t  tItem1 = NULLTAG, tItem2=NULLTAG;
//	tag_t tFind = NULLTAG, tAddObj=NULLTAG;
//	const char *cFind = ITK_ask_cli_argument("-find=");
//	const char *cSub1 = ITK_ask_cli_argument("-a1=");
//	const char *cSub2 = ITK_ask_cli_argument("-a2=");
//	checkiFail(ITEM_find_item(cFind, &tFind));
//	checkiFail(ITEM_find_item(cSub1, &tItem1));
//	checkiFail(ITEM_find_item(cSub2, &tItem2));
//	if (tFind!=NULLTAG&&tItem1!=NULLTAG && tItem2!=NULLTAG){
//		tag_t tArrItems[] = { tItem1,tItem2 };
//		checkiFail(ITEM_add_related_global_alternates(tFind, 2, tArrItems));
//		if (tArrItems != NULL) {
//			checkiFail(ITEM_prefer_global_alternate(tFind, tArrItems[0]));
//		}
//	}
//	return 0;
//}