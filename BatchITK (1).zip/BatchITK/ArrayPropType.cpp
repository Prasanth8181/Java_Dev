#include <iostream>
#include"Header.h"
#include<tccore/item.h>
#include<tccore/grm.h>
#include<tccore/aom.h>
#include<pom/pom/pom.h>//pom
#include<tccore/aom_prop.h>//del from parent

using namespace std;

int ArrayPropType()
{
	// Initialize variables
	tag_t tClassID = NULLTAG;
	tag_t tAttributeId = NULLTAG;
	char** cName = NULL;
	int* iTypes = 0;
	int* iMaxLength = 0;
	int* iLength = 0;
	int* iDesc = 0;
	int* iAttrFail = 0;
	tag_t* tRefclass = NULL;

	// Get the class ID for the class "A2Color"
	checkiFail(POM_class_id_of_class("A2Color", &tClassID));

	// Check if the class ID is not NULLTAG
	if (tClassID != NULLTAG) {
		// Get the attribute ID for the attribute "a2merge" in the class "A2Color"
		checkiFail(POM_attr_id_of_attr("a2merge", "A2Color", &tAttributeId));

		// Check if the attribute ID is not NULLTAG
		if (tAttributeId != NULLTAG) {
			// Describe the attributes of the class
			checkiFail(POM_describe_attrs(tClassID, 1, &tAttributeId, &cName, &iTypes, &iMaxLength, &tRefclass, &iLength, &iDesc, &iAttrFail));

			// Check if the attribute is an array
			if (iLength[0] < 1) {
				cout << "Array" << endl;

				// Check if the attribute type is string
				if (iTypes[0] == 2008) {
					cout << "String" << endl;
				}
			}
			else {
				cout << "Not an Array" << endl;
			}

			// Free the memory allocated for attribute descriptions
			MEM_free(cName);
			MEM_free(iTypes);
			MEM_free(iMaxLength);
			MEM_free(iLength);
			MEM_free(iDesc);
			MEM_free(iAttrFail);
			MEM_free(tRefclass);
		}
		else {
			cout << "Error: Attribute ID is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Class ID is NULLTAG." << endl;
	}

	return 0;
}

