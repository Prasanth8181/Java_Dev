#include "Header.h"
#include <tc/envelope.h>
#include <sa/user.h>
#include<tccore/workspaceobject.h>
#include <tc/folder.h>
#include<tccore/item.h>
#include<iostream>




using namespace std;

int SendMail()
{
	// Initialize variables
	tag_t Envelope = NULLTAG;
	tag_t user = NULLTAG;
	tag_t Recevier = NULLTAG;
	tag_t item = NULLTAG;
	tag_t rev = NULLTAG;

	// Create an item with ID "000791", name "item1", type "Item", and revision "A"
	checkiFail(ITEM_create_item("000791", "item1", "Item", "A", &item, &rev));

	// Save the created item
	checkiFail(ITEM_save_item(item));

	// Create an envelope with subject "ITK" and message "check"
	checkiFail(MAIL_create_envelope("ITK", "check", &Envelope));

	// Find the user with username "izn"
	checkiFail(SA_find_user2("izn", &user));

	// Find the user with username "infodba"
	checkiFail(SA_find_user2("infodba", &Recevier));

	// Check if the envelope and users are not NULLTAG
	if (Envelope != NULLTAG && user != NULLTAG && Recevier != NULLTAG) {
		// Add the receiver to the envelope
		MAIL_add_envelope_receiver(Envelope, Recevier);

		// Add the user as a CC receiver to the envelope
		MAIL_add_envelope_cc_receiver(Envelope, user);

		// Insert the item into the envelope
		checkiFail(FL_insert(Envelope, item, 1));

		// Send the envelope
		MAIL_send_envelope(Envelope);
	}
	else {
		cout << "Error: Envelope or user tags are NULLTAG." << endl;
	}

	// Free allocated memory (if any)
	// MEM_free(user); // Uncomment if memory needs to be freed
	// MEM_free(Recevier); // Uncomment if memory needs to be freed

	return 0;

}