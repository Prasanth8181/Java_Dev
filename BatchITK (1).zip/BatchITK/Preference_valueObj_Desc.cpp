#include <iostream>
#include"Header.h"
#include<tccore/item.h>

#include<tccore/aom.h>

#include<tccore/aom_prop.h>//del from parent
#include<tc/preferences.h>

using namespace std;

int Preference_valueObj_Desc()
{
	// Initialize variables
	tag_t tRev = NULLTAG;
	char* cvalue = NULL;

	// Ask for the value of the preference "TC_config_rule_name"
	checkiFail(PREF_ask_char_value("TC_config_rule_name", 0, &cvalue));

	// Check if the preference value is not NULL
	if (cvalue != NULL) {
		// Find the item revision with ID "000468" and revision "A"
		checkiFail(ITEM_find_rev("000501", "A", &tRev));

		// Check if the item revision tag is not NULLTAG
		if (tRev != NULLTAG) {
			// Refresh the item revision
			AOM_refresh(tRev, 1);

			// Set the object description of the item revision to the preference value
			checkiFail(AOM_UIF_set_value(tRev, "object_desc", cvalue));

			// Save the item revision without extensions
			AOM_save_without_extensions(tRev);

			// Refresh the item revision again
			AOM_refresh(tRev, 0);
		}
		else {
			cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
		}

		// Free the memory allocated for the preference value
		MEM_free(cvalue);
	}
	else {
		cout << "Error: Preference value is NULL." << endl;
	}

	return 0;
}

