#include<stdio.h>
#include <tccore/aom.h>//set ownership and save without extensions
#include <tccore/item.h>//find item
#include <sa/user.h>//find user
#include <sa/group.h>//find group
#include"Header.h"
#include <iostream>
using namespace std;
int change_ownership(const char *Item_id, const char *user1, const char *group1) {
	tag_t tObject = NULLTAG, tUser = NULLTAG, tGroup = NULLTAG;

	// Find the item
	checkiFail(ITEM_find_item(Item_id, &tObject));

	// Find the user
	checkiFail(SA_find_user2(user1, &tUser));
	cout << "found user " << user1 << endl;

	// Find the group
	checkiFail(SA_find_group(group1, &tGroup));

	if (tObject != NULLTAG && tUser != NULLTAG && tGroup != NULLTAG) {
		// Set ownership
		checkiFail(AOM_set_ownership(tObject, tUser, tGroup));

		// Save without extensions
		checkiFail(AOM_save_without_extensions(tObject));
	}
	else {
		cout << "Error: One or more tags are NULLTAG." << endl;
	}

	return 0;
}

