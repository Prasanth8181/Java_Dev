#include"Header.h"
#include<tccore/item.h>
#include<pie/pie.h>

int ExportIRtoXML()

{

	tag_t tSession_tag = NULLTAG;

	int iNum_trModes;

	tag_t* tTrModes = NULL;

	tag_t tItem = NULLTAG;

	checkiFail(ITEM_find_item("000479", &tItem));

	checkiFail(PIE_create_session(&tSession_tag));

	//checkiFail(PIE_find_transfer_mode2("ExpTransMode", "", &iNum_trModes, &tTrModes));

	//checkiFail(PIE_session_set_transfer_mode(tSession_tag, tTrModes[0]));

	checkiFail(PIE_session_set_file(tSession_tag, "D:/v/test1.xml"));

	checkiFail(PIE_session_export_objects(tSession_tag, 1, &tItem));

	return 0;

}
