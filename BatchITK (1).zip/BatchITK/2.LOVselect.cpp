#include <iostream>
#include"Header.h"
#include<tccore/item.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>//aom_ask_lov
#include<lov/lov.h>
//#include<tc/preferences.h>

using namespace std;

int LOVselect()
{
	// Initialize variables
	tag_t tObj = NULLTAG;
	tag_t tLov = NULLTAG;
	LOV_usage_t lUsage;
	int iValues = 0;
	logical* lNull = nullptr;
	logical* lEmpty = nullptr;
	char** cValue = nullptr;
	int iNum_values = 0;
	char** cVValues = nullptr;

	// Find the item revision with ID "000471" and revision "A"
	checkiFail(ITEM_find_rev("000471", "A", &tObj));

	// Check if the item tag is not NULLTAG
	if (tObj != NULLTAG) {
		// Ask for the LOV (List of Values) associated with the custom property "a2customprop1"
		checkiFail(AOM_ask_lov(tObj, "a2customprop1", &tLov));

		// Check if the LOV tag is not NULLTAG
		if (tLov != NULLTAG) {
			// Ask for the display values of the LOV
			checkiFail(LOV_ask_disp_values(tLov, &lUsage, &iValues, &lNull, &lEmpty, &cValue));

			// Print the usage, number of values, and the second value
			cout << lUsage << endl;
			cout << iValues << endl;
			if (iValues > 1) {
				cout << cValue[1] << endl;
			}

			// Refresh the item
			AOM_refresh(tObj, 1);

			// Set the custom property "a2customprop1" to the second value in the LOV
			checkiFail(AOM_set_value_string(tObj, "a2customprop1", cValue[1]));

			// Save the item without extensions
			AOM_save_without_extensions(tObj);

			// Refresh the item again
			AOM_refresh(tObj, 0);
		}
		else {
			cout << "Error: LOV tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}

