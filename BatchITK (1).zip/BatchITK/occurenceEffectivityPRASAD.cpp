#include<iostream>
#include<string>
#include<fstream>
#include<tc/emh.h>
#include<tcinit/tcinit.h>
#include<tccore/item.h>
#include<bom/bom.h>
#include<tccore/aom_prop.h>
#include<tccore/releasestatus.h>
#include<tccore/workspaceobject.h>
#include<tccore/aom.h>

using namespace std;

#define Date "01-Aug-2023 17:00 to 30-Sep-2025 19:00"

//For the syslog file
string path = "C:\\Users\\T50455\\Desktop\\syslog\\dateEffectivity.log";
fstream outfile(path);

//A method to  check if a tag is null

//Main
int ITK_user_main(int argc, char* argv[])
{
	tag_t tRev = NULLTAG;
	int count = 0;
	tag_t *tReleaseStatus = NULL;
	tag_t tEffectivity = NULLTAG;
	tag_t tItem = NULLTAG;
	//Login
	Login();


	//Get the item revision
	tRev = getrev();
	cout << "\nGot the revision";
	outfile << "\nGot the revision";

	//Get the release status
	check(WSOM_ask_release_status_list(tRev, &count, &tReleaseStatus), "\nError while getting the status");
	cout << "\nGot the release status";
	outfile << "\nGot the release status";

	//Get the end item
	cout << "\nFor getting the end item";
	outfile << "\nFor getting the end item";
	tItem = getitem();
	cout << "\nGot the end item";
	outfile << "\nGot the end item";

	//Create date effectivity
	/*check(WSOM_eff_create_with_date_text(tReleaseStatus[0], tItem, Date, &tEffectivity), "\nError creating the date effectivity");
	cout << "\nDate Effectivity created";
	outfile << "\nDate effectivity created";
*/

	check(WSOM_effectivity_create(tReleaseStatus[0], tItem, &tEffectivity), "\nError getting the effectivity");
	cout << "\nEffectivity created";
	outfile << "\nEffectivity created";

	check(WSOM_eff_set_date_range(tReleaseStatus[0], tEffectivity, Date, true), "\nError setting the date");
	cout << "\nThe date is set";
	outfile << "\nThe date is set";


	//Save
	check(AOM_save_without_extensions(tEffectivity), "\nError saving");
	cout << "\nSaved";
	outfile << "\nSaved";



	return 0;
}