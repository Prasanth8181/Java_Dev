#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include"Header.h"
using namespace std;
int printBOM(const char *ctopI, const char *ctopIR)
{
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tSubI = NULLTAG, tSubIR = NULLTAG, *child = NULL, tOut = NULLTAG;
	int count = 0;
	char *childName;
	/*const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");*/
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
	if (tTopI != NULLTAG && tTopIR != NULLTAG ) {
		checkiFail(BOM_create_window(&tWindow));
		if (tWindow != NULLTAG) {
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
			if (tBomLine != NULLTAG) {
				getChilds(tBomLine);
			}
			BOM_save_window(tWindow);
			BOM_close_window(tWindow);
		}
	}
	return 0;
}
int getChilds(tag_t tBomLine) {
	int count;
	char *childName;
	tag_t *child = NULL;
	checkiFail(BOM_line_ask_all_child_lines(tBomLine, &count, &child));
	for (int i = 0; i < count; i++) {
		checkiFail(AOM_ask_value_string(child[i], "bl_indented_title", &childName));

		cout << childName << endl;
		
		cout << "        ";
		getChilds(child[i]);
		
	}
	return 0;
	cout << "       " << endl;
}
