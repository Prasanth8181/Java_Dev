#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include"Header.h"

using namespace std;
int BaseLine()
{
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tBaseLineRev = NULLTAG;
	char *cChildName = NULL;
	//tag_t tRev;
	const char* desc="BaselineDesc";
	const char* rel_proc_name="TC Default Baseline Process";
	const char* jobName="Baseline_000475-old2_A.001";
	const char* jobDescription="JobDesc";
	tag_t  new_rev_tag = NULL;
	int deepCopiedObjCount;
	tag_t* deepCopiedObjs;
	
	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
	cout << "inside";
	//checkiFail(BOM_create_baseline(NULLTAG, "A.001", "Desc", "TCx Default Baseline Process","Baseline_000473-new_A.001","JobDesc",&tBaseLineRev));
	checkiFail(ITEM_baseline_rev(tTopIR, "A.001", desc, rel_proc_name, jobName, jobDescription, &new_rev_tag, &deepCopiedObjCount, &deepCopiedObjs));
	checkiFail(AOM_save_without_extensions(new_rev_tag));
	return 0;
}