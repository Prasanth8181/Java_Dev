#include <tccore/item.h>
#include <ps/ps.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <string>
#include <iostream>
#include "Header.h"

using namespace std;

int PackUnpack() {
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, *child = NULL;
	int iCount = 0;
	char *cChildName = NULL;
	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");

	// Find the item and its revision
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));

	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
		// Create BOM window
		checkiFail(BOM_create_window(&tWindow));

		if (tWindow != NULLTAG) {
			// Set top line for BOM window
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
			checkiFail(AOM_save_without_extensions(tWindow));

			if (tBomLine != NULLTAG) {
				checkiFail(AOM_save_without_extensions(tBomLine));

				// Get all child lines for the BOM line
				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
				checkiFail(AOM_save_without_extensions(tWindow));
				checkiFail(AOM_save_without_extensions(tBomLine));

				// Pack each child line
				for (int i = 0; i < iCount; i++) {
					checkiFail(BOM_line_pack(child[i]));
					checkiFail(AOM_save_without_extensions(tWindow));
					checkiFail(AOM_save_without_extensions(tBomLine));
				}

				// Get all child lines again after packing
				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));

				// Print the indented title of each child line
				for (int i = 0; i < iCount; i++) {
					checkiFail(AOM_ask_value_string(child[i], "bl_indented_title", &cChildName));
					if (cChildName != NULL) {
						cout << cChildName << endl;
						MEM_free(cChildName);
					}
				}

				// Save and close the BOM window
				checkiFail(BOM_save_window(tWindow));
				checkiFail(BOM_close_window(tWindow));

				// Free allocated memory
				MEM_free(child);
			}
		}
	}
	return 0;
}

//#include<tccore/item.h>
//#include<ps/ps.h>
//#include<tccore/aom.h>
//#include<tccore/aom_prop.h>
//#include <tcinit/tcinit.h>
//#include <bom/bom.h>
//#include<tccore/item.h>
//#include<string>
//#include <iostream>
//#include"Header.h"
//
//using namespace std;
//int PackUnpack()
//{
//	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tSubI = NULLTAG, tSubIR = NULLTAG, *child = NULL, tOut= NULLTAG;
//	int iCount=0;
//	char *cChildName = NULL;
//	const char *ctopI = ITK_ask_cli_argument("-topI=");
//	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
//	checkiFail(ITEM_find_item(ctopI, &tTopI));
//	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
//	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
//		checkiFail(BOM_create_window(&tWindow));
//		if (tWindow!=NULLTAG){
//			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//			checkiFail(AOM_save_without_extensions(tWindow));
//			if (tBomLine != NULLTAG) {
//				checkiFail(AOM_save_without_extensions(tBomLine));
//				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
//				checkiFail(AOM_save_without_extensions(tWindow));
//				checkiFail(AOM_save_without_extensions(tBomLine));
//				for (int i = 0; i < iCount; i++) {
//					checkiFail(BOM_line_pack(child[i]));
//					checkiFail(AOM_save_without_extensions(tWindow));
//					checkiFail(AOM_save_without_extensions(tBomLine));
//				}
//				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
//				for (int i = 0; i < iCount; i++) {
//					checkiFail(AOM_ask_value_string(child[i], "bl_indented_title", &cChildName));
//					cout << cChildName << endl;
//				}
//				checkiFail(BOM_save_window(tWindow));
//				checkiFail(BOM_close_window(tWindow));
//			}	
//		}
//	}
//	return 0;
//}