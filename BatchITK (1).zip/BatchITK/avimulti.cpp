#include<iostream>
#include<string>
#include<fstream>
#include<tc/emh.h>
#include<tcinit/tcinit.h>
#include<tccore/item.h>
#include<bom/bom.h>
#include<tccore/aom_prop.h>
#include<tccore/releasestatus.h>
#include<tccore/workspaceobject.h>
#include<tccore/aom.h>

using namespace std;

#define Date "01-Aug-2023 17:00 to 30-Sep-2025 19:00"

//For the syslog file
string path = "C:\\Users\\T50455\\Desktop\\syslog\\dateEffectivity.log";
fstream outfile(path);


//A check function to check for error after each condition
void check(int fail, const char *stmt)
{
	char *error = NULL;
	if (fail != ITK_ok) {
		printf(stmt);
		outfile << "\n" << stmt;
		EMH_ask_error_text(fail, &error);
		exit(0);
	}
}
//A method to  check if a tag is null
bool isNullTag(tag_t tag)
{
	if (tag == NULLTAG) {
		cout << "\nThe tag is NULL";
		exit(0);
		return true;
	}
	else {
		return false;
	}
}
//A method to get the item
tag_t getrev()
{
	string id;
	string revid;
	cout << "\nEnter the search id: ";
	cin >> id;
	cout << "\nEnter the revision id: ";
	cin >> revid;
	tag_t tRev = NULLTAG;
	check(ITEM_find_rev(id.c_str(), revid.c_str(), &tRev), "\nError getting the child rev");
	isNullTag(tRev); //checking if the item is NULL
	return tRev;
}

tag_t getitem()
{
	string id;
	cout << "\nEnter the search id: ";
	cin >> id;
	tag_t tItem = NULLTAG;
	check(ITEM_find_item(id.c_str(), &tItem), "\nError getting the child rev");
	isNullTag(tItem); //checking if the item is NULL
	return tItem;
}

//Function to Login

void Login()
{

	//Login
	char* cName = ITK_ask_cli_argument("-u=");
	char* cPassword = ITK_ask_cli_argument("-p=");
	char* cGroup = ITK_ask_cli_argument("-g=");

	if (ITK_ask_cli_argument("-h"))
	{
		std::cout << "\n -u=user_id";
		std::cout << "\n -p=user_password";
		std::cout << "\n -g=user_group";
		std::cout << "\n -h or help = for arguments";
	}
	//check if the values for user, password and group is properly entered or not
	if (cName != NULL) {
		if (cPassword != NULL)
		{
			if (cGroup != NULL)
			{

			}
			else {
				cout << "\nDidn't enter the group...exiting...";
				exit(0);
			}
		}
		else {
			cout << "\nDidn't enter the password...exiting...";
			exit(0);
		}
	}
	else {
		cout << "\nDidn't enter the user...exiting...";
		exit(0);
	}

	check(ITK_init_module(cName, cPassword, cGroup), "\nError while logging in");
	std::cout << "\nlogin succesful\n";
	outfile << "\nLogin succcessful\n";

}


//Main
int ITK_user_main(int argc, char* argv[])
{
	tag_t tRev = NULLTAG;
	int count = 0;
	tag_t *tReleaseStatus = NULL;
	tag_t tEffectivity = NULLTAG;
	tag_t tItem = NULLTAG;
	//Login
	Login();


	//Get the item revision
	tRev = getrev();
	cout << "\nGot the revision";
	outfile << "\nGot the revision";

	//Get the release status
	check(WSOM_ask_release_status_list(tRev, &count, &tReleaseStatus), "\nError while getting the status");
	cout << "\nGot the release status";
	outfile << "\nGot the release status";

	//Get the end item
	cout << "\nFor getting the end item";
	outfile << "\nFor getting the end item";
	tItem = getitem();
	cout << "\nGot the end item";
	outfile << "\nGot the end item";

	//Create date effectivity
	/*check(WSOM_eff_create_with_date_text(tReleaseStatus[0], tItem, Date, &tEffectivity), "\nError creating the date effectivity");
	cout << "\nDate Effectivity created";
	outfile << "\nDate effectivity created";
*/

	check(WSOM_effectivity_create(tReleaseStatus[0], tItem, &tEffectivity), "\nError getting the effectivity");
	cout << "\nEffectivity created";
	outfile << "\nEffectivity created";

	check(WSOM_eff_set_date_range(tReleaseStatus[0], tEffectivity, Date, true), "\nError setting the date");
	cout << "\nThe date is set";
	outfile << "\nThe date is set";


	//Save
	check(AOM_save_without_extensions(tEffectivity), "\nError saving");
	cout << "\nSaved";
	outfile << "\nSaved";



	return 0;
}