#include <tccore/item.h>
#include <ps/ps.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <string>
#include <iostream>
#include <fclasses/tc_date.h>
#include "Header.h"

using namespace std;

int OccurrenceEffectivity() {
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tOccurence = NULLTAG, *child = NULL;
	int iCount = 0;
	logical is_valid;
	char *cChildName = NULL;
	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
	const char *cFind = ITK_ask_cli_argument("-find=");
	const char *cStartDate = "01-Nov-2024 00:00:59";
	const char *cEndDate = "30-Nov-2024 00:00:59";
	date_t dDates[2];

	// Convert date strings to date_t
	checkiFail(DATE_string_to_date_t((char*)cStartDate, &is_valid, &dDates[0]));
	checkiFail(DATE_string_to_date_t((char*)cEndDate, &is_valid, &dDates[1]));

	// Find the item and its revision
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));

	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
		// Create BOM window
		checkiFail(BOM_create_window(&tWindow));

		if (tWindow != NULLTAG) {
			// Set top line for BOM window
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));

			if (tBomLine != NULLTAG) {
				// Get all child lines for the BOM line
				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
				cout << iCount << endl;

				for (int i = 0; i < iCount; i++) {
					checkiFail(AOM_ask_value_string(child[i], "bl_item_item_id", &cChildName));

					if (strcmp(cFind, cChildName) == 0) {
						cout << "va" << endl;

						// Create occurrence effectivity with date range
						checkiFail(BOM_create_occurrence_effectivity(child[i], "1080", tTopI, tTopIR, NULL, 2, dDates, EFFECTIVITY_closed, false, &tOccurence));
						checkiFail(BOM_create_occurrence_effectivity(child[i], "108", tTopI, tTopIR, "1-9", 0, NULL, EFFECTIVITY_closed, false, &tOccurence));
					}

					checkiFail(AOM_save_without_extensions(tBomLine));
					checkiFail(AOM_save_without_extensions(tWindow));
				}

				// Save and close the BOM window
				checkiFail(BOM_save_window(tWindow));
				checkiFail(BOM_close_window(tWindow));

				// Free allocated memory
				MEM_free(child);
				MEM_free(cChildName);
			}
		}
	}
	return 0;
}

//#include<tccore/item.h>
//#include<ps/ps.h>
//#include<tccore/aom.h>
//#include<tccore/aom_prop.h>
//#include <tcinit/tcinit.h>
//#include <bom/bom.h>
//#include<tccore/item.h>
//#include<string>
//#include <iostream>
//#include<fclasses/tc_date.h>
//#include"Header.h"
//
//using namespace std;
//int OccurrenceEffectivity()
//{
//	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tOccurence = NULLTAG, *child = NULL, tOut = NULLTAG;
//	int iCount = 0;
//	logical is_valid;
//	char *cChildName = NULL, *cQuantity;
//	const char *ctopI = ITK_ask_cli_argument("-topI=");
//	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
//	const char *cFind = ITK_ask_cli_argument("-find=");
//	const char *cStartDate ="01-Nov-2024 00:00:59";
//	const char *cEndDate ="30-Nov-2024 00:00:59";
//	date_t dDates[2];
//	DATE_string_to_date_t((char*)cStartDate,&is_valid,&dDates[0]);
//	DATE_string_to_date_t((char*)cEndDate,&is_valid,&dDates[1]);
//	checkiFail(ITEM_find_item(ctopI, &tTopI));
//	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
//	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
//		checkiFail(BOM_create_window(&tWindow));
//		if (tWindow != NULLTAG) {
//			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//			if (tBomLine != NULLTAG) {
//				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &child));
//				cout << iCount << endl;
//				for (int i = 0; i < iCount; i++) {
//					checkiFail(AOM_ask_value_string(child[i], "bl_item_item_id", &cChildName));
//					if (strcmp(cFind, cChildName) == 0) {
//						cout << "va" << endl;
//						
//						checkiFail( BOM_create_occurrence_effectivity(child[i], "1080", tTopI, tTopIR, NULL, 2, dDates, EFFECTIVITY_closed, false, &tOccurence));
//						checkiFail( BOM_create_occurrence_effectivity(child[i], "108", tTopI, tTopIR, "1-9", 0, NULL, EFFECTIVITY_closed, false, &tOccurence));
//						//checkiFail(AOM_save_without_extensions(tOccurence));
//					}
//
//					checkiFail(AOM_save_without_extensions(tBomLine));
//					checkiFail(AOM_save_without_extensions(tWindow));
//				}
//				checkiFail(BOM_save_window(tWindow));
//				checkiFail(BOM_close_window(tWindow));
//			}
//		}
//	}
//	return 0;
//}