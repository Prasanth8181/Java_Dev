//#include"Header.h"
//#include<tccore/project.h>
//#include<sa/user.h>
//
//using namespace std;
//
//int projAssignMember()
//{
//	tag_t tProject,tUser1,tAdmin,tUser2;
//	PROJ_find("5",&tProject);
//
//	SA_find_user2("pawan", &tUser1);
//	tag_t tMembers[1] = { tUser1 };
//	
//	SA_find_user2("infodba", &tAdmin);
//	tag_t tAdmins[1] = { tAdmin };
//
//	SA_find_user2("harsha1", &tUser2);
//	tag_t tPuser[1] = { tUser2 };
//
//	PROJ_assign_team_members(tProject,1,tMembers,1,tAdmins,1, tPuser);
//	
//
//	return 0;
//}
#include "Header.h" // Include the custom header file
#include <tccore/project.h> // Include the project core header file
#include <sa/user.h> // Include the user service header file
#include<iostream>
#include<tc/emh.h>

using namespace std; // Use the standard namespace


int projAssignMember() // Function to assign members to a project
{
	// Initialize variables
	tag_t tUser = NULLTAG;
	int iMemCount = 1, iPrivUserCount = 1, iAdminCount = 1;
	tag_t tProject1 = NULLTAG;
	char* errMsg = nullptr;
	int ifail = 0;
	tag_t tProjAdmin = NULLTAG;

	// Find the user with username "izn"
	checkiFail(SA_find_user2("izn", &tUser));
	cout << "1" << endl;

	// Check if the user tag is not NULLTAG
	if (tUser != NULLTAG) {
		tag_t tMembers[] = { tUser };

		// Find the user with username "infodba"
		checkiFail(SA_find_user2("infodba", &tProjAdmin));
		tag_t listOfAdmins[] = { tProjAdmin };
		cout << "2" << endl;

		// Check if the project admin tag is not NULLTAG
		if (tProjAdmin != NULLTAG) {
			tag_t tPrivUsers[] = { tUser };

			// Find the project with the name "TC"
			checkiFail(PROJ_find("TC", &tProject1));
			cout << "3" << endl;

			// Check if the project tag is not NULLTAG
			if (tProject1 != NULLTAG) {
				// Assign the team to the project
				checkiFail(PROJ_assign_team(tProject1, iMemCount, tMembers, tProjAdmin, iPrivUserCount, tPrivUsers));

				// Ask for error text if any
				EMH_ask_error_text(ifail, &errMsg);
				cout << errMsg;
				cout << "4" << endl;

				// Free the memory allocated for error message
				MEM_free(errMsg);
			}
			else {
				cout << "Error: Project not found or project tag is NULLTAG." << endl;
			}
		}
		else {
			cout << "Error: Project admin not found or project admin tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: User not found or user tag is NULLTAG." << endl;
	}

	return 0;
}
	//tag_t tProject, tUser1, tAdmin, tUser2; // Declare tag variables for project and users

	//// Find the project with ID "5" and store the result in tProject
	//if (checkiFail(PROJ_find("5", &tProject)))
	//{
	//	// Find the user "pawan" and store the result in tUser1
	//	if (checkiFail(SA_find_user2("pawan", &tUser1)))
	//	{
	//		tag_t tMembers[1] = { tUser1 }; // Create an array with tUser1 as a member

	//		// Find the user "infodba" and store the result in tAdmin
	//		if (checkiFail(SA_find_user2("infodba", &tAdmin)))
	//		{
	//			tag_t tAdmins[1] = { tAdmin }; // Create an array with tAdmin as an admin

	//			// Find the user "harsha1" and store the result in tUser2
	//			if (checkiFail(SA_find_user2("harsha1", &tUser2)))
	//			{
	//				tag_t tPuser[1] = { tUser2 }; // Create an array with tUser2 as a project user

	//				// Assign team members, admins, and project users to the project
	//				checkiFail(PROJ_assign_team_members(tProject, 1, tMembers, 1, tAdmins, 1, tPuser));
	//			}
	//		}
	//	}
	//}

	//return 0; // Return 0 to indicate successful execution

