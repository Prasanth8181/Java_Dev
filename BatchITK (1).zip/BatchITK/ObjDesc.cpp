#include"Header.h"
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tccore/item.h>
#include <iostream>
#include <tccore/workspaceobject.h>
using namespace std;
int ObjectdescwithoutDate()
{
	tag_t item = NULLTAG;
	ITEM_find_rev("000462", "A", &item);
	AOM_lock(item);
	AOM_refresh(item, 1);
	
	AOM_set_value_string(item, "object_desc", "Released");
	
	AOM_save_without_extensions(item);
	AOM_refresh(item, 0);
	AOM_unlock(item);
	return 0;
}