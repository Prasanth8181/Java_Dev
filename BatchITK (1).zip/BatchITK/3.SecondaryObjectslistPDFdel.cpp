#include <iostream>
#include "Header.h"
#include <tccore/item.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>

using namespace std;

int SecondaryObjectslistPDFdel() {
	tag_t tRev = NULLTAG;
	int iCount = 0;
	tag_t* tSecondary_list = NULL;
	char* cName = NULL;
	char* value = NULL;

	// Find the item revision
	checkiFail(ITEM_find_rev("000457", "A", &tRev));

	if (tRev != NULLTAG) {
		// List secondary objects only
		checkiFail(GRM_list_secondary_objects_only(tRev, NULLTAG, &iCount, &tSecondary_list));

		for (int i = 0; i < iCount; i++) {
			checkiFail(AOM_ask_name(tSecondary_list[i], &cName));
			if (cName != NULL) {
				cout << cName << endl;
				MEM_free(cName);
			}
		}

		for (int i = 0; i < iCount; i++) {
			checkiFail(AOM_ask_value_string(tSecondary_list[i], "object_type", &value));
			if (value != NULL && strcmp(value, "PDF") == 0) {
				checkiFail(AOM_delete_from_parent(tSecondary_list[i], tRev));
				cout << "inside if" << endl;
				MEM_free(value);
			}
		}

		// Free allocated memory
		MEM_free(tSecondary_list);
	}
	else {
		cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
	}

	return 0;
}
