#include<sa/user.h>
#include<tc/folder.h>

int newstuffinsert(const char *user_id,tag_t tWorkspaceobj) {
	tag_t user;
	tag_t folder;
	SA_find_user2(user_id, &user);

	SA_ask_user_newstuff_folder(user, &folder);
	FL_insert(folder, tWorkspaceobj, 1);
	return folder;
}