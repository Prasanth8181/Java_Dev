#include<qry/qry.h>
#include"Header.h"
#include<tccore/item.h>
#include<tccore/grm.h>
#include<tccore/aom_prop.h>
#include<iostream>

using namespace std;

int queryDbaItems()
{
	tag_t qry;
	QRY_find2("DbaItems", &qry);
	int n_entries;
	char **entries;
	char **values;
	char *value;

	QRY_find_user_entries(qry, &n_entries, &entries, &values);
	int n_found;
	tag_t *results;
	QRY_execute(qry, n_entries, entries, values, &n_found, &results);
	for (int i = 0; i < n_found; i++) {
		AOM_ask_value_string(results[i], "object_name", &value);

		cout << value << endl;
	}
	return 0;
}
