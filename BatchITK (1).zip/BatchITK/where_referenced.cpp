#include <iostream>
#include <tccore/aom.h>
#include <tccore/workspaceobject.h>
#include "Header.h"
#include <fstream>

using namespace std;

int where_referenced() {
	int iHits = 0;
	tag_t* tList = NULL;

	// Find items with the name "exp"
	checkiFail(WSOM_find2("exp", &iHits, &tList));

	// Initialize variables
	int iReferences = 0;
	int* iLevels = nullptr;
	tag_t* tReferences = nullptr;
	char** cRelations = nullptr;
	char* cName = nullptr;

	// Check if the list is not empty and the first item is not NULLTAG
	if (iHits > 0 && tList[0] != NULLTAG) {
		// Find all references of the first item in the list
		checkiFail(WSOM_where_referenced2(tList[0], -1, &iReferences, &iLevels, &tReferences, &cRelations));

		// Iterate through the references and print their names
		for (int i = 0; i < iReferences; i++) {
			checkiFail(AOM_ask_name(tReferences[i], &cName));
			if (cName != nullptr) {
				cout << cName << endl;
				MEM_free(cName);
			}
		}

		// Free allocated memory
		MEM_free(tReferences);
		MEM_free(iLevels);
		MEM_free(cRelations);
	}
	else {
		cout << "Error: No items found or first item is NULLTAG." << endl;
	}

	// Free allocated memory
	MEM_free(tList);

	return 0;
}

//#include <iostream>
//#include<tccore/aom.h>
//#include <tccore/workspaceobject.h>//where ref
//#include"Header.h"
//#include<fstream>
////#include<tccore/aom_prop.h>
//using namespace std;
//int where_referenced() {
//	int iHits = 0;
//	tag_t* tList = NULL;
//
//	checkiFail(WSOM_find2("exp", &iHits, &tList));
//	// Find all references of the first item in the list
//
//	// Initialize variables
//	int iReferences = 0;
//	int* iLevels = 0;
//	tag_t* tReferences = NULL;
//	char** cRelations = NULL;
//	char* cName = NULL;
//
//	// Check if the list is not empty and the first item is not NULLTAG
//	if (iHits > 0 && tList[0] != NULLTAG) {
//		// Find items with the name "item212"
//		checkiFail(WSOM_where_referenced2(tList[0], -1, &iReferences, &iLevels, &tReferences, &cRelations));
//
//		// Iterate through the references and print their names
//		for (int i = 0; i < iReferences; i++) {
//			AOM_ask_name(tReferences[i], &cName);
//			cout << cName << endl;
//		}
//	}
//	else {
//		cout << "Error: No items found or first item is NULLTAG." << endl;
//	}
//
//	return 0;
//}