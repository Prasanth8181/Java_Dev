
#include<tc/tc_startup.h>

using namespace std;
int loginCLI();
int checkiFail(int iFail);
int change_ownership(const char *Item_id, const char*user1, const char*group1);
int createInactiveUser();
int CreateAttachFolder();

int create_dataset();
int CreateItem();
int allprops();	
int ItemAttachHomeFolder();
int AllUsers();
int where_referenced();
int where_used();
int SecondaryObjectslistPDFdel();
int newstuffinsert(const char* user_id, tag_t tWorkspaceobj);
int FormItemUpdate();
int projAssignMember();
//int iDelete_datsets();
int queryDbaUsers();
int queryDbaItems();
int Preference_valueObj_Desc();
int SendMail();
int preferencebycomma();
int ArrayPropType();

int BOM();
int LOVselect();
int inactiveUser();
int ObjectdescReleased();
int projAssignObject();
int datasetwithNamedRef();
int DeleteNamedRef();
int DelNamedRefofDataset();
int ItemRevisionsStatus();
int globalalternate();
int localsubstitute();
int ObjectdescwithoutDate();
int LatestRevision();
int DeleteUserMailBox();
int PackUnpack();
int SplitOccurence();
int InsertLevel();
int BOMCompare();
int BaseLine();
tag_t add(tag_t tBomLine, tag_t tChild1I, tag_t tChild1IR);
int multiBOM();
int iCreate_BOM();
int ExportIRtoXML();
int OccurrenceEffectivity();
int RevisionEffectivity();
int printBOM(const char *ctopI, const char *ctopIR);
int getChilds(tag_t tBomLine);
int ApplyRevRule();