#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tcinit/tcinit.h>
#include<bom/bom.h>
#include<tccore/item.h>
#include<string>
#include<iostream>
#include"TCHeader.h"

using namespace std;


int BaseLine() {
	tag_t tWindow = NULLTAG;
	tag_t tTopI = NULLTAG;
	tag_t tTopIR = NULLTAG;
	tag_t tBomLine = NULLTAG;
	tag_t tBaseLineRev = NULLTAG;
	tag_t new_rev_tag = NULLTAG;
	int deepCopiedObjCount;
	tag_t* deepCopiedObjs = NULL;
	char *cChildName = NULL;

	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");

	// Find the item and its revision
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));

	// Check if tTopI and tTopIR are not NULLTAG
	if (tTopI != NULLTAG && tTopIR != NULLTAG) {
		cout << "inside";

		// Create a baseline revision
		checkiFail(ITEM_baseline_rev(tTopIR, "A.001", "Description", "TC Default Baseline Process", "Baseline_000488-NewItem_A.001", "jobDescription", &new_rev_tag, &deepCopiedObjCount, &deepCopiedObjs));

		// Check if new_rev_tag is not NULLTAG
		if (new_rev_tag != NULLTAG) {
			// Save the new revision without extensions
			AOM_save_without_extensions(new_rev_tag);
		}
		else {
			// Handle the error case where new_rev_tag is NULLTAG
			cout <<"Error: new_rev_tag is NULLTAG"<< endl;
			return -1;
		}
	}
	else {
		// Handle the error case where tTopI or tTopIR is NULLTAG
		cout<< "Error: tTopI or tTopIR is NULLTAG"<< endl ;
		return -1;
	}

	return 0;
}





































//int BaseLine()
//
//{
//
//	tag_t tWindow = NULLTAG;
//	tag_t tTopI = NULLTAG;
//	tag_t tTopIR = NULLTAG;
//	tag_t tBomLine = NULLTAG;
//	tag_t tBaseLineRev = NULLTAG;
//
//	char *cChildName = NULL;
//
//	//const char* BaselineDesc;
//
//	//const char* TC Default Baseline Process;
//
//	//const char* Baseline_000449 - ppp_A.001;
//
//	//const char* jobDescription;
//
//	tag_t  new_rev_tag = NULLTAG;
//
//	int deepCopiedObjCount;
//
//	tag_t* deepCopiedObjs = NULL;
//
//	const char *ctopI = ITK_ask_cli_argument("-topI=");
//
//	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
//
//	checkiFail(ITEM_find_item(ctopI, &tTopI));
//
//	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
//
//	cout << "inside";
//
//	//checkiFail(BOM_create_baseline();
//
//	checkiFail(ITEM_baseline_rev(tTopIR,"A.001", "Description", "TC Default Baseline Process", "Baseline_000488-NewItem_A.001","jobDescription", &new_rev_tag, &deepCopiedObjCount, &deepCopiedObjs));
//
//	AOM_save_without_extensions(new_rev_tag);
//
//	return 0;
//
//}
