#include"TCHeader.h"
#include<iostream>
#include<tcinit/tcinit.h>
#include<tccore/item.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<epm/epm_task_template_itk.h>
#include<epm/epm.h>
#include<epm/signoff.h>
#include<sa/user.h>
#include<sa/sa.h>

using namespace std;

int ReviewTask() {
	tag_t tProcesstemplate = NULLTAG;
	tag_t tProcess = NULLTAG;
	tag_t tRev = NULLTAG;
	int n, m;
	tag_t *tTask_list = NULL;
	tag_t *tTask_lists = NULL;
	tag_t tUser = NULLTAG;
	char *tVal;
	char *cName = NULL;
	int iMem_num, iSn;
	tag_t *tList = NULL;
	tag_t *tMem_list = NULL;

	
	checkiFail(ITEM_find_rev("000569", "A", &tRev)); // Find the revision of the item with ID
	checkiFail(EPM_find_process_template("ReviewTask", &tProcesstemplate)); // Find the process template

	// Check if tUser, tRev, tProcess, and tProcesstemplate are not NULLTAG
	if (tRev != NULLTAG && tProcesstemplate != NULLTAG) {
		const int att_list[] = { 1 };
		checkiFail(EPM_create_process("workflow", "workflow", tProcesstemplate, 1, &tRev, att_list, &tProcess)); // Create a process using the found template and revision

		if (tProcess != NULLTAG) {
			checkiFail(EPM_ask_tasks(tProcess, EPM_started, &n, &tTask_list)); // Get the list of started tasks in the process
			cout << n << "\n";

			for (int i = 0; i < n; i++) {
				EPM_ask_name2(tTask_list[i], &tVal); // Loop through each task and print its name
				cout << tVal << endl;
			}

			checkiFail(EPM_ask_sub_tasks(tTask_list[1], &m, &tTask_lists)); // Get the list of sub-tasks for the second task in the list
			cout << "No of Sub tasks:" << m << endl;

			for (int i = 0; i < m; i++) { // Loop through each sub-task
				AOM_ask_value_string(tTask_lists[i], "object_name", &tVal);
				cout << tVal << endl;

				if (strcmp("select-signoff-team", tVal) == 0) { // If the sub-task is "select-signoff-team"
					checkiFail(SA_find_user2("pavan", &tUser)); // Find the user "pavan" and their group members
					checkiFail(SA_find_groupmember_by_user(tUser, &iMem_num, &tMem_list));
					checkiFail(EPM_create_adhoc_signoff(tTask_lists[i], tUser, &iSn, &tList)); // Create an ad-hoc signoff for the user
					cout << iSn << endl;

					for (int j = 0; j < iSn; j++) { // Loop through each signoff and get its name
						AOM_ask_name(tList[j], &cName);
					}

					checkiFail(EPM_set_adhoc_signoff_selection_done(tTask_lists[i], TRUE)); // Mark the signoff selection as done and trigger the complete action
					checkiFail(EPM_trigger_action(tTask_lists[i], EPM_complete_action, "done"));
				}
				else if (strcmp("perform-signoffs", tVal) == 0) { // If the sub-task is "perform-signoffs"
					checkiFail(EPM_set_signoff_decision(tList[0], EPM_approve_decision, "itk")); // Set the signoff decision to approve and trigger the complete action
					checkiFail(EPM_trigger_action(tTask_lists[i], EPM_complete_action, "done"));
				}
			}
		}
	}

	return 0;
}

















































//
//int ReviewTask()
//
//{
//
//	tag_t tProcesstemplate = NULLTAG;
//
//	tag_t tProcess = NULLTAG;
//
//	tag_t tRev = NULLTAG;
//
//	int n, m;
//
//	tag_t *tTask_list=NULL; tag_t *tTask_lists=NULL;
//
//	tag_t tUser = NULLTAG;
//
//	char *tVal;
//
//	char*cName = NULL;
//
//	int iMem_num, iSn;
//
//	tag_t *tList = NULL;
//
//	tag_t *tMem_list=NULL;
//
//	//checkiFail(ITK_auto_login());
//
//	checkiFail(ITEM_find_rev("000569", "A", &tRev)); //Find the revision of the item with ID
//
//	checkiFail(EPM_find_process_template("ReviewTask", &tProcesstemplate));  // Find the process template
//
//	//const tag_t rev_list[] = { rev };
//
//	const int att_list[] = { 1 };
//
//	checkiFail(EPM_create_process("workflow", "wrokflow", tProcesstemplate, 1, &tRev, att_list, &tProcess)); // Create a process using the found template and revision
//
//	checkiFail(EPM_ask_tasks(tProcess, EPM_started, &n, &tTask_list));  // Get the list of started tasks in the process
//
//	cout << n << "\n";
//
//	for (int i = 0; i < n; i++) {
//
//		//AOM_ask_value_string(task_list[i], "object_name", &val);
//
//		EPM_ask_name2(tTask_list[i], &tVal);  // Loop through each task and print its name
//
//		cout << tVal << endl;
//
//		//cout << val;
//
//	}
//
//	checkiFail(EPM_ask_sub_tasks(tTask_list[1], &m, &tTask_lists));  // Get the list of sub-tasks for the second task in the list
//
//	cout << "No of Sub tasks:" << m << endl;
//
//	for (int i = 0; i < m; i++) {   // Loop through each sub-task
//
//		AOM_ask_value_string(tTask_lists[i], "object_name", &tVal);
//
//		cout << tVal << endl;
//
//		if (strcmp("select-signoff-team", tVal) == 0) {   // If the sub-task is "select-signoff-team"
//
//			checkiFail(SA_find_user2("pavan", &tUser));   // Find the user "izn" and their group members
//
//			checkiFail(SA_find_groupmember_by_user(tUser, &iMem_num, &tMem_list));
//
//			checkiFail(EPM_create_adhoc_signoff(tTask_lists[i], tUser, &iSn, &tList));  // Create an ad-hoc signoff for the user
//
//			cout << iSn << endl;
//
//			// Loop through each signoff and get its name
//			for (int i = 0; i < iSn; i++) 
//
//			{
//
//				AOM_ask_name(tList[i], &cName);
//
//			}
//
//			// Mark the signoff selection as done and trigger the complete action
//			checkiFail(EPM_set_adhoc_signoff_selection_done(tTask_lists[i], TRUE));
//
//			checkiFail(EPM_trigger_action(tTask_lists[i], EPM_complete_action, "done"));
//
//		}
//
//		// If the sub-task is "perform-signoffs"
//		else if (strcmp("perform-signoffs", tVal) == 0) {
//
//			// Set the signoff decision to approve and trigger the complete action
//			checkiFail(EPM_set_signoff_decision(tList[0], EPM_approve_decision, "itk"));
//
//			checkiFail(EPM_trigger_action(tTask_lists[i], EPM_complete_action, "done"));
//
//		}
//
//	}
//
//	return 0;
//
//}
