#include<sa/user.h>
#include<iostream>
#include<tccore/aom.h>
#include"TCHeader.h"

int makeuserinactive() {
	tag_t tUser = NULLTAG;

	checkiFail(SA_find_user2("izn", &tUser));

	if (tUser != NULLTAG) {
		cout<<"User not found or invalid user tag"<<endl;
		return -1; // Return an error code or handle as needed
	}

	AOM_refresh(tUser, 1);
	checkiFail(SA_set_user_status(tUser, 0));
	AOM_save_without_extensions(tUser);
	AOM_refresh(tUser, 0);

	return 0;
}































//int makeuserinactive() {
//
//	tag_t user = NULLTAG;
//
//	checkiFail(SA_find_user2("izn", &user));
//	AOM_refresh(user, 1);
//	checkiFail(SA_set_user_status(user, 0));
//	AOM_save_without_extensions(user);
//	AOM_refresh(user, 0);
//
//	return 0;
//
//}
