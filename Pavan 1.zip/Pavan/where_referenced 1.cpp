//Printing all the references of an ItemRevision where it is referred.

#include "TCHeader.h"

int where_referenced() {
	int iHits = 0;
	tag_t* tList = NULL;

	checkiFail(WSOM_find2("exp", &iHits, &tList));
	// Find all references of the first item in the list

	// Initialize variables
	int iReferences = 0;
	int* iLevels = 0;
	tag_t* tReferences = NULL;
	char** cRelations = NULL;
	char* cName = NULL;

	// Check if the list is not empty and the first item is not NULLTAG
	if (iHits > 0 && tList[0] != NULLTAG) {
		// Find items with the name "exp"
		
		checkiFail(WSOM_where_referenced2(tList[0], -1, &iReferences, &iLevels, &tReferences, &cRelations));

		// Iterate through the references and print their names
		for (int i = 0; i < iReferences; i++) {
			AOM_ask_name(tReferences[i], &cName);
			cout << cName << endl;
		}
	}
	else {
		cout << "Error: No items found or first item is NULLTAG." << endl;
	}

	return 0;
}





































//int where_referenced() {
//	int hits;
//	tag_t* list;
//	checkiFail(WSOM_find2("item212", &hits,&list));
//	int n_references;
//	int *levels;
//	tag_t *references;
//	char** relations;
//	char *name;
//	checkiFail(WSOM_where_referenced2(list[0],-1,&n_references,&levels,&references,&relations));
//	for (int i = 0; i < n_references; i++) {
//		AOM_ask_name(references[i], &name);
//		cout << name<<endl;
//	}
//	return 0;
//}