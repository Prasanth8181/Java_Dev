#include<iostream>
#include<tccore/tctype.h>
#include<tcinit/tcinit.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<sa/user.h>
#include<tccore/item.h>
#include<tc/folder.h>
#include"TCHeader.h"





using namespace std;


tag_t createObject(const char* typeName, const char* objectName, const char* objectDesc) {
	tag_t type = NULLTAG;
	tag_t create_input = NULLTAG;
	tag_t bo = NULLTAG;

	TCTYPE_ask_type(typeName, &type);
	TCTYPE_construct_create_input(type, &create_input);
	AOM_UIF_set_value(create_input, "object_name", objectName);
	AOM_UIF_set_value(create_input, "object_desc", objectDesc);
	TCTYPE_create_object(create_input, &bo);

	return bo;
}



int CreateFormItemUpdate1() {
	tag_t form = createObject("Item Master", "FormTest123DOUBLE", "FormDescTest");
	tag_t item = createObject("Item", "ItemTest12FormTest123DOUBLE", "ItemDescTest");
	tag_t Document= createObject("Document", "Document112FormTest123DOUBLE", "Document1112345");

	tag_t user;
	tag_t folder;
	SA_find_user2("pavan", &user);
	SA_ask_user_newstuff_folder(user, &folder);

	FL_insert(folder, form, 1);
	AOM_save_without_extensions(form);

	FL_insert(folder, item, 1);
	ITEM_save_item(item);
	AOM_save_without_extensions(folder);

	FL_insert(folder, Document, 1);
	AOM_save_without_extensions(Document);
	AOM_save_without_extensions(folder);
	return 0;
}

