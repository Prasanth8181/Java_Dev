#include<tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include <tccore/item.h>
#include <fclasses/tc_date.h>
#include <tccore/releasestatus.h>
#include"TCHeader.h"

using namespace std;


int RevisionDateEffectivity() {
	int iFail = 0, iNum = 0;
	tag_t tFind = NULLTAG, *tStatuss = NULL, tTOPI = NULLTAG, tEff = NULLTAG;

	// Get command line arguments
	const char *cFind = ITK_ask_cli_argument("-find=");
	const char *cTOPI = ITK_ask_cli_argument("-TOPI=");

	// Find the item revision
	checkiFail(ITEM_find_rev(cFind, "A", &tFind));
	// Check if tFind is valid
	if (tFind == NULLTAG) {
		cerr << "Error: Item revision not found." << endl;
		return 1;
	}

	// Find the item
	checkiFail(ITEM_find_item(cTOPI, &tTOPI));
	// Check if tTOPI is valid
	if (tTOPI == NULLTAG) {
		cerr << "Error: Item not found." << endl;
		return 1;
	}

	// Get the release status list of the item revision
	checkiFail(WSOM_ask_release_status_list(tFind, &iNum, &tStatuss));
	cout << iNum << endl;

	// Create effectivity for the release status and item
	checkiFail(WSOM_effectivity_create(tStatuss[0], tTOPI, &tEff));
	// Check if tEff is valid
	if (tEff == NULLTAG) {
		cerr << "Error: Failed to create effectivity." << endl;
		MEM_free(tStatuss);
		return 1;
	}

	// Set the date range for the effectivity
	checkiFail(WSOM_eff_set_date_range(tStatuss[0], tEff, "01-Nov-2024 00:00 to 10-Nov-2024 00:00", true));
	// Save the effectivity without extensions
	checkiFail(AOM_save_without_extensions(tEff));

	// Free the memory allocated for tStatuss
	MEM_free(tStatuss);

	return 0;
}








































//
//int  RevisionDateEffectivity()
//
//{
//
//	int iFail = 0, iNum = 0;
//
//	tag_t tFind = NULLTAG, *tStatuss = NULL, tTOPI = NULLTAG, tEff = NULLTAG, *tEffs = NULL;
//
//	const char *cFind = ITK_ask_cli_argument("-find=");
//
//	const char *cTOPI = ITK_ask_cli_argument("-TOPI=");
//
//
//
//	checkiFail(ITEM_find_rev(cFind, "A", &tFind));
//
//	checkiFail(ITEM_find_item(cTOPI, &tTOPI));
//
//	if (tFind != NULLTAG) {
//
//		checkiFail(WSOM_ask_release_status_list(tFind, &iNum, &tStatuss));
//
//		cout << iNum << endl;
//
//		checkiFail(WSOM_effectivity_create(tStatuss[0], tTOPI, &tEff));
//
//		checkiFail(WSOM_eff_set_date_range(tStatuss[0], tEff, "01-Nov-2024 00:00 to 30-Nov-2024 00:00", true));
//
//		checkiFail(AOM_save_without_extensions(tEff));
//
//		
//	}
//
//	return 0;
//
//}
//
