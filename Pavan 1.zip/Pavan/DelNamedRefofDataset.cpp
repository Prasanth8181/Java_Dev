#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <string>
#include"TCHeader.h"


using namespace std;


int DelNamedRefofDataset() {
	tag_t tDataset = NULLTAG;
	AE_reference_type_t aReferenceType;
	tag_t tRefObj = NULLTAG;
	int iFound;
	tag_t *tRef = NULL;
	char *cRefName = NULL;
	char *cName = NULL;

	// Find the dataset with type "pdf"
	checkiFail(AE_find_dataset2("pdf", &tDataset));

	// Check if tDataset is not NULLTAG
	if (tDataset != NULLTAG) {
		// Get the named references of the dataset
		checkiFail(AE_ask_dataset_named_refs(tDataset, &iFound, &tRef));

		for (int i = 0; i < iFound; i++) {
			AOM_refresh(tDataset, true);

			// Find the named reference of the dataset
			checkiFail(AE_find_dataset_named_ref2(tDataset, 0, &cRefName, &aReferenceType, &tRefObj));

			// Check if tRefObj is not NULLTAG
			if (tRefObj != NULLTAG) {
				// Remove the named reference from the dataset
				checkiFail(AE_remove_dataset_named_ref2(tDataset, cRefName));

				// Save the dataset without extensions
				checkiFail(AOM_save_without_extensions(tDataset));

				// Refresh the dataset
				AOM_refresh(tDataset, false);
			}
			else {
				// Handle the error case where tRefObj is NULLTAG
				cout<<"Error: tRefObj is NULLTAG"<<endl;
			}
		}
	}
	else {
		// Handle the error case where tDataset is NULLTAG
		cout<<"Error: tDataset is NULLTAG"<<endl;
		return -1;
	}

	cout << iFound << endl;

	return 0;
}


























//int DelNamedRefofDataset()
//{
//
//
//	tag_t tDataset = NULLTAG;
//	AE_reference_type_t aReferenceType;
//	tag_t tRefObj = NULLTAG;
//	int iFound;
//	tag_t *tRef = NULL;
//	char * cRefName = NULL;
//	char *cName = NULL;
//
//	checkiFail(AE_find_dataset2("pdf", &tDataset));
//
//	checkiFail(AE_ask_dataset_named_refs(tDataset, &iFound, &tRef));
//	for (int i = 0; i < iFound; i++)
//	{
//		AOM_refresh(tDataset,true);
//		checkiFail(AE_find_dataset_named_ref2(tDataset,0,&cRefName,&aReferenceType,&tRefObj));
//		checkiFail(AE_remove_dataset_named_ref2(tDataset, cRefName));
//		AOM_save_without_extensions(tDataset);
//		AOM_refresh(tDataset, false);
//		
//	}
//
//	cout << iFound << endl;
//
//	return 0;
//}
//


