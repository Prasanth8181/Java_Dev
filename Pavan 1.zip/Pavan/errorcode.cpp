#include <tc/emh.h>//Emh_ask_error_text
#include<stdio.h>
#include<iostream>//cout endl

using namespace std;
int checkiFail(int iFail) {
	char *cMessage;
	if (iFail == 0)
	{
		//cout << "success" << endl;
	}
	else
	{
		EMH_ask_error_text(iFail, &cMessage);
		cout << "\n" << cMessage;
	}
	return 0;
}