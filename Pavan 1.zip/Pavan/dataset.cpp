#include<iostream>
#include<tc/tc_startup.h>
#include<tcinit/tcinit.h>
#include<tc/emh.h>
#include<tccore/item.h>
#include<sa/user.h>
#include<tc/folder.h>
#include<tccore/aom.h>


using namespace std;

int ITK_user_main(int argc, char*argv[])

{

	int iFail = 0;

	char *message = NULL;

	tag_t item, rev, user, Home_Folder;

	/*char*user_id = ITK_ask_cli_argument("-u=");  // tc_startup

	char*password = ITK_ask_cli_argument("-p=");

	char*group = ITK_ask_cli_argument("-g=");

	iFail = ITK_init_module(user_id, password, group);*///tcinit

	/*iFail = ITK_init_module("infodba", "infodba", "dba");*/

	iFail = ITK_auto_login();//tcinit

	if (iFail == ITK_ok)

	{

		cout << "Login sucessfully \n";

		

	}

	else

	{

		EMH_ask_error_text(iFail, &message); //tc- emh

		cout << message;

	}

	return 0;

}
