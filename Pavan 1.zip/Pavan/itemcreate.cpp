//#include<iostream>
//#include<tc/tc_startup.h>
//#include<tcinit/tcinit.h>
//#include<tc/emh.h>
//#include<tccore/item.h>
#include"TCHeader.h"


using namespace std;

int ItemCreate()
{
	tag_t tItem = NULLTAG;
	tag_t tRev = NULLTAG;

	checkiFail(ITEM_create_item("000777", "item1", "Item", "A", &tItem, &tRev));

	if (tItem != NULLTAG && tRev != NULLTAG) {
		
		checkiFail(ITEM_save_item(tItem));
	}
	else {
		cout << "Error: Item or Revision tag is NULLTAG." << endl;
	}

	return 0;
}



















//
//int ItemCreate()
//{
//	
//	tag_t tItem = NULLTAG;
//	tag_t tRev=NULLTAG;
//
//	ITEM_create_item("000739", "item1", "Item", "A" , &tItem, &tRev);
//	ITEM_save_item(tItem);
//		
//	
//	return 0;
//}
