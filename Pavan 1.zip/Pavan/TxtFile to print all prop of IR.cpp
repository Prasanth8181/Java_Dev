//Making a Text file to print all properties of ItemRevision.

//#include <iostream>
//#include<tccore/aom.h>
//#include <tccore/workspaceobject.h>
//#include<tccore/item.h>
//#include<fstream>
//#include<tccore\aom_prop.h>//ask_prop_names,aom_ask_displayable_values
#include"TCHeader.h"



int PrintallpropsofIR() {
	int iFail = 0;
	tag_t tObject = NULLTAG;
	int iCount = 0;
	char** cNames = NULL;

	// Find the item with ID "000790"
	ITKCALL(checkiFail(ITEM_find_item("000471", &tObject)));

	// Check if the item tag is not NULLTAG
	if (tObject != NULLTAG) {
		// Ask for the property names of the item
		checkiFail(AOM_ask_prop_names(tObject, &iCount, &cNames));

		// Open a file to write the properties
		ofstream outFile("properties1.txt");

		int num_values = 0;
		char** values = nullptr;

		// Iterate through the property names
		for (int i = 0; i < iCount; i++) {
			outFile << cNames[i] << " -   ";

			// Ask for the displayable values of each property
			checkiFail(AOM_ask_displayable_values(tObject, cNames[i], &num_values, &values));

			// Iterate through the values and write them to the file
			for (int j = 0; j < num_values; j++) {
				outFile << values[j] << "          ";
			}
			outFile << " " << endl;

			// Free the memory allocated for values
			MEM_free(values);
		}

		// Close the file
		outFile.close();

		// Free the memory allocated for property names
		MEM_free(cNames);
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}

















































//int PrintallpropsofIR() {
//
//	int iFail = 0;
//
//	tag_t tObject;
//
//	int iCount;
//
//	char **cNames;
//
//	checkiFail(ITEM_find_item("000790", &tObject));
//
//	checkiFail(AOM_ask_prop_names(tObject, &iCount, &cNames));
//
//	ofstream outFile("properties.txt");
//
//	int num_values;
//
//	char **values;
//
//	for (int i = 0; i < iCount; i++) {
//
//		outFile << cNames[i];
//
//		outFile << " -   ";
//
//		checkiFail(AOM_ask_displayable_values(tObject, cNames[i], &num_values, &values));
//
//		for (int j = 0; j < num_values; j++) {
//
//			outFile << values[j];
//
//			outFile << "          ";
//		}
//		outFile << " " << endl;
//	}
//	return 0;
//
//}
