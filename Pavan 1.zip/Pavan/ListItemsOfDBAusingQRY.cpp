#include"TCHeader.h"
#include<qry/qry.h>
#include <fclasses/tc_string.h>


using namespace std;

int ItemsofDBA() {
	tag_t tQuery = NULLTAG;
	int iEntries = 0;
	char** cEntries = NULL;
	char** cValues = NULL;
	int iFound = 0;
	tag_t* tResults = NULL;
	char* cName = NULL;

	const char *group = ITK_ask_cli_argument("-group=");
	checkiFail(QRY_find2("1_DBA_Group", &tQuery));

	if (tQuery != NULLTAG) {
		checkiFail(QRY_find_user_entries(tQuery, &iEntries, &cEntries, &cValues));
		strncpy(cValues[0], group, strlen(group) + 1);
		checkiFail(QRY_execute(tQuery, iEntries, cEntries, cValues, &iFound, &tResults));

		for (int i = 0; i < iFound; i++) {
			checkiFail(AOM_ask_name(tResults[i], &cName));
			cout << cName << endl;
			MEM_free(cName);  // Free the allocated memory for cName
		}

		// Free allocated memory for cEntries and cValues
		for (int i = 0; i < iEntries; i++) {
			MEM_free(cEntries[i]);
			MEM_free(cValues[i]);
		}
		MEM_free(cEntries);
		MEM_free(cValues);
		MEM_free(tResults);
	}
	else {
		cout << "Query not found." << endl;
	}

	return 0;
}
































//
//int ItemsofDBA()
//{
//
//
//	tag_t  tQuery = NULLTAG;
//	int iEntries = 0;
//	char** cEntries = NULL;
//	char** cValues = NULL;
//	int iFound = 0;
//	tag_t* tResults = NULL;
//	char* cName = NULL;
//
//	const char *group = ITK_ask_cli_argument("-group=");
//	checkiFail(QRY_find2("1_DBA_Group",&tQuery));
//	checkiFail(QRY_find_user_entries(tQuery,&iEntries,&cEntries,&cValues));
//	tc_strcpy(cValues[0], group);
//	checkiFail(QRY_execute(tQuery, iEntries, cEntries, cValues,&iFound,&tResults));
//	
//	
//	for (int i = 0; i < iFound; i++) {
//
//		AOM_ask_name(tResults[i],&cName);
//		
//		cout << cName << endl;
//	}
//	
//	return 0;
//}