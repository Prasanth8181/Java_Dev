#include"TCHeader.h"

using namespace std;

int ITK_user_main(int argc, char* argv[]) {
	login();
	/*ItemAttachHomeFolder();*/
	//ownership();
	/*create_dataset();*/
	// ItemCreate();
	//where_referenced();
	// users();
	//ItemCreateAttachFolder();
	 //PrintallpropsofIR();
	//WhereUsed();
	//SecondaryObjects();
	// CreateFormItemUpdate();
	//projAssignMembers();
	//DeleteSecondaryObjects();
	 //ItemsofDBA();
	//ReadValueofPrefandUpdateobjDescofIR();
	// UpdatecustomIRLov();
//	SendaMail();
   //createBom();
  // propArryanItemprintitsAttributeType();
   //  UpdateLov();
	//CreateUserandPerson();
	//InactiveUser();
	//createBomusingfile();
	// updateReleaseStatusObjdesc();
	//makeuserinactive();
     //projAssignObject();
	//DatasetWithNamedRef();
	//DelNamedRefofDataset();
	//RenameofNamedRefofDataset();
	//SetCustomStatusForIR();
	 //UserMailBoxDelete();
	//PrintLatestRevision();
	// localsubstitute();
	// GlobalAlternate();
	//Packitems();
	//UnPackitems();
	//SpiltOccurence();
	// InsertLevel();
	//InsertLeveLArray();
	// ExportItemRevision();
	// BaseLine();
	// ExportIRtoXML();
    //DeleteSecondaryObjectsWithSpecificRelation();
	//BomCompare();
	//MultiBOMUsingFile();
	//OccurrenceUnitEffectivity();
	// OccurrenceDateEffectivity();
	//RevisionUnitEffectivity();
	CreateFormItemUpdate1();
     // RevisionDateEffectivity();
	//ApplyingRevisionRule();
	// RemoveEffectivity();
	// PrintLatestRelesedIR();
	 //ReviseItemRevision();
   //  PrintAllDataSetWIthUser();
	//InitiateAWrkFlw();
	//ReviewTask();
	 //ItemBaseLineRev();
	return 0;
}