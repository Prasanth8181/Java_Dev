#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include<tc\folder.h>
#include<tccore/aom.h>
#include<tccore/tctype.h>
#include "TCHeader.h"
using namespace std;



int ItemCreateAttachFolder() {
	tag_t tNewFolder = NULLTAG;
	tag_t tItem = NULLTAG;
	tag_t tRev = NULLTAG;

	// Create a new folder
	checkiFail(FL_create2("Folder1", "Desc", &tNewFolder));
	cout << "Folder created successfully\n";

	// Check if the folder was created successfully
	if (tNewFolder != NULLTAG) {
		// Create a new item
		checkiFail(ITEM_create_item("000720", "item2", "Item", "A", &tItem, &tRev));
		cout << "Item created successfully\n";

		// Check if the item and revision were created successfully
		if (tItem != NULLTAG && tRev != NULLTAG) {
			// Save the item
			checkiFail(ITEM_save_item(tItem));

			// Attach the item to the folder
			checkiFail(FL_insert(tNewFolder, tItem, 999));
			cout << "Folder attached to item successfully\n";

			// Save the folder without extensions
			checkiFail(AOM_save_without_extensions(tNewFolder));
		}
		else {
			cout << "Item or revision creation failed.\n";
		}
	}
	else {
		cout << "Folder creation failed.\n";
	}

	

	return 0;
}




























//int ItemCreateAttachFolder()
//{
//	
//
//	tag_t tNewFolder = NULLTAG;
//	tag_t tItem = NULLTAG; 
//	tag_t tRev = NULLTAG;
//
//	checkiFail(FL_create2("Folder1", "Desc", &tNewFolder));
//	cout << "Folder created sucessfully \n";
//	
//	checkiFail(ITEM_create_item("000720", "item2", "Item", "A", &tItem, &tRev));
//	cout << "item created sucessfully \n";
//
//	ITEM_save_item(tItem);
//
//	checkiFail((FL_insert(tNewFolder, tItem, 999));
//	 cout << "Folder Attach to Item sucessfully \n";
//	
//	AOM_save_without_extensions(tNewFolder);
//
//	return 0;
//}