#include<iostream>
#include<tccore/tctype.h>
#include<tcinit/tcinit.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<sa/user.h>
#include<tccore/item.h>
#include<tc/folder.h>
#include"TCHeader.h"



using namespace std;

tag_t createObject12(const char* typeName, const char* objectName, const char* objectDesc) {
	tag_t tType = NULLTAG;
	tag_t tCreate_input = NULLTAG;
	tag_t tBo = NULLTAG;

	// Ask for the type
	TCTYPE_ask_type(typeName, &tType);

	// Check if type is not NULLTAG
	if (tType != NULLTAG) {
		// Construct create input
		TCTYPE_construct_create_input(tType, &tCreate_input);

		// Check if create_input is not NULLTAG
		if (tCreate_input != NULLTAG) {
			// Set values for the object
			AOM_UIF_set_value(tCreate_input, "object_name", objectName);
			AOM_UIF_set_value(tCreate_input, "object_desc", objectDesc);

			// Create the object
			TCTYPE_create_object(tCreate_input, &tBo);

			// Check if bo is NULLTAG
			if (tBo == NULLTAG) {
				cout<<"Error: Failed to create object"<<endl;
			}
		}
		else {
			cout<<"Error: create_input is NULLTAG"<<endl;
		}
	}
	else {
		cout<<"Error: type is NULLTAG"<<endl;
	}

	return tBo;
}

int CreateFormItemUpdate123() {
	tag_t form = createObject("Item Master", "FormTest12", "FormDescTest");
	tag_t item = createObject("Item", "ItemTest12", "ItemDescTest");

	// Check if form and item are not NULLTAG
	if (form != NULLTAG && item != NULLTAG) {
		tag_t user;
		tag_t folder;

		// Find the user "pavan"
		SA_find_user2("pavan", &user);

		// Ask for the user's newstuff folder
		SA_ask_user_newstuff_folder(user, &folder);

		// Insert form into the folder
		FL_insert(folder, form, 1);
		AOM_save_without_extensions(form);

		// Insert item into the folder
		FL_insert(folder, item, 1);
		ITEM_save_item(item);
		AOM_save_without_extensions(folder);
	}
	else {
		cout<<"Error: form or item is NULLTAG"<<endl;
		return -1;
	}

	return 0;
}



































//using namespace std;
//
//
//tag_t createObject(const char* typeName, const char* objectName, const char* objectDesc) {
//	tag_t type = NULLTAG;
//	tag_t create_input = NULLTAG;
//	tag_t bo = NULLTAG;
//
//	TCTYPE_ask_type(typeName, &type);
//	TCTYPE_construct_create_input(type, &create_input);
//	AOM_UIF_set_value(create_input, "object_name", objectName);
//	AOM_UIF_set_value(create_input, "object_desc", objectDesc);
//	TCTYPE_create_object(create_input, &bo);
//	return bo;
//}
//
//
//
//int CreateFormItemUpdate() {
//	tag_t form = createObject("Item Master", "FormTest12", "FormDescTest");
//	tag_t item = createObject("Item", "ItemTest12", "ItemDescTest");
//
//	tag_t user;
//	tag_t folder;
//	SA_find_user2("pavan", &user);
//	SA_ask_user_newstuff_folder(user, &folder);
//
//	FL_insert(folder, form, 1);
//	AOM_save_without_extensions(form);
//
//	FL_insert(folder, item, 1);
//	ITEM_save_item(item);
//	AOM_save_without_extensions(folder);
//
//	return 0;
//}
//











































////#include<iostream>
////#include<tccore/tctype.h>
////#include<tcinit/tcinit.h>
////#include<tccore/aom.h>
////#include<tccore/aom_prop.h>
////#include<sa\user.h>
////#include<tccore/item.h>
////#include<tc/folder.h>
//#include"TCHeader.h"
//
//using namespace std;
//
//int CreateFormItemUpdate()
//
//{
//
//	tag_t FormType = NULL;
//	tag_t create_input = NULL;
//	tag_t bo = NULL;
//
//	TCTYPE_ask_type("Item Master", &FormType);
//	TCTYPE_construct_create_input(FormType, &create_input);
//	AOM_UIF_set_value(create_input, "object_name", "FormTest");//How to add name to the Item Master.
//	AOM_UIF_set_value(create_input, "object_desc", "FormDescTest");
//	TCTYPE_create_object(create_input, &bo);
//
//
//	tag_t user;
//	tag_t folder;
//	SA_find_user2("pavan", &user);
//	SA_ask_user_newstuff_folder(user, &folder);
//	FL_insert(folder, bo, 1);
//	AOM_save_without_extensions(bo);
//
//
//	tag_t tCreate_input = NULL;
//	tag_t tType = NULL;
//	tag_t tBo = NULL;
//	TCTYPE_ask_type("Item", &tType);
//	TCTYPE_construct_create_input(tType, &tCreate_input);
//
//	AOM_UIF_set_value(tCreate_input, "object_name", "ItemTest");
//	AOM_UIF_set_value(tCreate_input, "object_desc", "ItemDescTest");
//	TCTYPE_create_object(tCreate_input, &tBo);
//
//
//	FL_insert(folder, tBo, 1);
//	ITEM_save_item(tBo);
//	AOM_save_without_extensions(folder);
//
//
//	return 0;
//
//}
