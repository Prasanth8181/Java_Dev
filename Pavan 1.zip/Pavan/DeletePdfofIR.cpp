//#include <iostream>
//#include<tccore/item.h>
//#include<tccore/grm.h>
//#include<tccore/aom.h>
#include"TCHeader.h"

using namespace std;


int DeleteSecondaryObjects() {
	tag_t tRev = NULLTAG;
	int icount = 0;
	tag_t* tSecondary_list = NULL;
	char *cType = NULL;

	// Find the revision with ID "000467" and revision "A"
	checkiFail(ITEM_find_rev("000467", "A", &tRev));

	// Check if tRev is not NULLTAG
	if (tRev != NULLTAG) {
		// List secondary objects of the revision
		checkiFail(GRM_list_secondary_objects_only(tRev, NULLTAG, &icount, &tSecondary_list));

		for (int i = 0; i < icount; i++) {
			// Get the object type of the secondary object
			checkiFail(AOM_ask_value_string(tSecondary_list[i], "object_type", &cType));

			// Check if the object type is "PDF"
			if (strcmp(cType, "PDF") == 0) {
				// Delete the secondary object from the parent
				checkiFail(AOM_delete_from_parent(tSecondary_list[i], tRev));
			}
		}

	}
	else {
		// Handle the error case where tRev is NULLTAG
		cout<<"Error: tRev is NULLTAG"<<endl;
		return -1;
	}

	cout << icount << endl;

	return 0;
}





























//int DeleteSecondaryObjects()
//
//{
//	
//	tag_t tRev = NULLTAG;
//	
//	int icount = 0;
//	tag_t* tSecondary_list = NULL;
//
//	char *cType = NULL;
//
//	ITEM_find_rev("000467", "A", &tRev);
//	GRM_list_secondary_objects_only(tRev, NULLTAG, &icount, &tSecondary_list);
//	for (int i = 0; i < icount; i++)
//	{
//		AOM_ask_value_string(tSecondary_list[i], "object_type", &cType);
//		if (strcmp(cType, "PDF") == 0)
//		{
//			
//			AOM_delete_from_parent(tSecondary_list[i], tRev);
//
//		}
//		return 0;
//	}
// }