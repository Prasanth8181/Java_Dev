#include <iostream>
#include <bom/bom.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include<string>
#include <tccore/item.h>
#include"TCHeader.h"

using namespace std;

int InsertLevel() {
	//tag_t tDataset = NULLTAG;
	tag_t tWindow = NULLTAG;
	tag_t tTopI = NULLTAG;
	tag_t tTopIR = NULLTAG;
	tag_t tBomLine = NULLTAG;
	tag_t *tChild = NULL;
	tag_t tItemRev = NULLTAG;

	int iCount;

	// Find the item with ID "000522"
	checkiFail(ITEM_find_item("000535", &tTopI));

	// Check if the item tag is not NULLTAG
	if (tTopI != NULLTAG) {
		// Find the item revision with ID "000522" and revision "A"
		checkiFail(ITEM_find_rev("000535", "A", &tTopIR));

		// Check if the item revision tag is not NULLTAG
		if (tTopIR != NULLTAG) {
			// Find the item revision with ID "000534" and revision "A"
			checkiFail(ITEM_find_rev("000339", "A", &tItemRev));

			// Check if the item revision tag is not NULLTAG
			if (tItemRev != NULLTAG) {
				// Create a BOM window
				checkiFail(BOM_create_window(&tWindow));

				// Check if the BOM window tag is not NULLTAG
				if (tWindow != NULLTAG) {
					// Set the top line of the BOM window
					checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));

					// Check if the BOM line tag is not NULLTAG
					if (tBomLine != NULLTAG) {
						// Ask for all child lines of the BOM line
						checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &tChild));

						// Print the count of child lines
						std::cout << iCount << std::endl << std::endl;

						// Insert a new level in the BOM
						checkiFail(BOM_line_insert_level(2, &tChild[0], tItemRev, NULL));

						// Save the changes without extensions
						AOM_save_without_extensions(tChild[1]);

						// Save the BOM window
						BOM_save_window(tWindow);

						// Close the BOM window
						BOM_close_window(tWindow);

						// Free the memory allocated for the child lines
						MEM_free(tChild);
					}
					else {
						std::cout << "Error: BOM line is NULLTAG." << std::endl;
					}
				}
				else {
					std::cout << "Error: BOM window is NULLTAG." << std::endl;
				}
			}
			else {
				std::cout << "Error: Item revision '000534' not found or item revision tag is NULLTAG." << std::endl;
			}
		}
		else {
			std::cout << "Error: Item revision '000522' not found or item revision tag is NULLTAG." << std::endl;
		}
	}
	else {
		std::cout << "Error: Item '000522' not found or item tag is NULLTAG." << std::endl;
	}

	return 0;
}







































//int InsertLevel()
//
//{
//	tag_t tDataset = NULLTAG;
//	tag_t tWindow = NULLTAG;
//	tag_t tTopI = NULLTAG;
//	tag_t tTopIR = NULLTAG;
//	tag_t tBomLine = NULLTAG;
//	tag_t *tChild = NULLTAG;
//	tag_t tItemRev = NULLTAG;
//	
//	int  iCount;
//
//	
//
//	checkiFail(ITEM_find_item("000522", &tTopI));
//
//	checkiFail(ITEM_find_rev("000522", "A", &tTopIR));
//
//
//	checkiFail(ITEM_find_rev("000534", "A", &tItemRev));
//
//	checkiFail(BOM_create_window(&tWindow));
//
//	checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//
//
//	checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &tChild));
//
//	cout << iCount << endl << endl;
//
//	
//	checkiFail(BOM_line_insert_level(2, &tChild[0], tItemRev, NULL));
//
//	AOM_save_without_extensions(tChild[1]);
//
//	BOM_save_window(tWindow);
//
//	BOM_close_window(tWindow);
//
//
//	return 0;
//
//}
//
//
//
//
//
//
///*tItemRev4[0] = tChild[0];
//	tItemRev4[1] = tChild[3];*/
//
//
//
//	//tag_t tItemRev4[2];
//













































//int InsertLevel()
//
//{
//	tag_t tDataset = NULLTAG; 
//	tag_t tWindow = NULLTAG;
//	tag_t tTopI = NULLTAG;
//	tag_t tTopIR = NULLTAG;
//	tag_t tBomLine = NULLTAG;
//	tag_t *tChild = NULLTAG;
//	tag_t tItemRev=NULLTAG;
//	tag_t tItemRev4[2];
//	int  iCount;
//	
//	//char *cName;
//
//	checkiFail(ITEM_find_item("000522", &tTopI));
//
//	checkiFail(ITEM_find_rev("000522", "A", &tTopIR));
//
//
//	checkiFail(ITEM_find_rev("000534", "A", &tItemRev));
//
//	checkiFail(BOM_create_window(&tWindow));
//
//	checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//
//
//	checkiFail(BOM_line_ask_all_child_lines(tBomLine, &iCount, &tChild));
//
//	cout << iCount << endl << endl;
//
//	tItemRev4[0] = tChild[0];
//	tItemRev4[1] = tChild[3];
//	checkiFail(BOM_line_insert_level(2, tItemRev4, tItemRev, NULL));
//
//	AOM_save_without_extensions(tChild[1]);
//
//	BOM_save_window(tWindow);
//
//	BOM_close_window(tWindow);
//
//
//	return 0;
//
//}
