#include"TCHeader.h"
//#include<Bom/bom.h>
//#include<ps/ps.h>
#include<string>
#include<fstream>


using namespace std;

int createBomusingfile() {
	tag_t tItem1 = NULLTAG;
	tag_t tItemRev1 = NULLTAG;
	tag_t tBomview = NULLTAG;
	tag_t tBvr = NULLTAG;
	tag_t tTopBomLine = NULLTAG;
	tag_t tItem2 = NULLTAG;
	tag_t tItemRev2 = NULLTAG;
	tag_t tNewLine1 = NULLTAG;
	tag_t tNewLine2 = NULLTAG;
	string line, Item, rev, Item2, rev2;
	char *cItem = NULL;
	char *crev = NULL;
	char *cItem2 = NULL;
	char *crev2 = NULL;
	ifstream inFile("input.txt");

	getline(inFile, line);
	size_t hypenpos = line.find("-");
	cout << hypenpos << endl;
	if (hypenpos != string::npos) {
		Item = line.substr(0, hypenpos);
		cItem = new char[Item.length() + 1];
		cout << Item.length();
		strcpy(cItem, Item.c_str());
		rev = line.substr(hypenpos + 2);
		crev = new char[rev.length() + 1];
		strcpy(crev, rev.c_str());
	}

	ITEM_find_item(cItem, &tItem1);
	ITEM_find_rev(cItem, crev, &tItemRev1);

	// Check if tItem1 and tItemRev1 are not NULLTAG
	if (tItem1 != NULLTAG && tItemRev1 != NULLTAG) {
		PS_create_bom_view(NULLTAG, NULL, NULL, tItem1, &tBomview);
		AOM_save_without_extensions(tBomview);
		AOM_save_without_extensions(tItem1);

		PS_create_bvr(tBomview, NULL, NULL, false, tItemRev1, &tBvr);
		AOM_save_without_extensions(tBvr);
		AOM_save_without_extensions(tItemRev1);

		BOM_create_window(&tBomview);
		AOM_save_without_extensions(tBomview);

		BOM_set_window_top_line(tBomview, tItem1, tItemRev1, NULLTAG, &tTopBomLine);
		AOM_save_without_extensions(tTopBomLine);

		// Check if tBomview, tBvr, and tTopBomLine are not NULLTAG
		if (tBomview != NULLTAG && tBvr != NULLTAG && tTopBomLine != NULLTAG) {
			while (getline(inFile, line)) {
				size_t hypenpos = line.find("-");
				cout << hypenpos << endl;
				if (hypenpos != string::npos) {
					Item2 = line.substr(0, hypenpos);
					cItem2 = new char[Item2.length() + 1];
					cout << line.length();
					strcpy(cItem2, Item2.c_str());
					rev2 = line.substr(hypenpos + 2);
					crev2 = new char[rev2.length() + 1];
					strcpy(crev2, rev2.c_str());
					ITEM_find_item(cItem2, &tItem2);
					ITEM_find_rev(cItem2, crev2, &tItemRev2);

					// Check if tItem2 and tItemRev2 are not NULLTAG
					if (tItem2 != NULLTAG && tItemRev2 != NULLTAG) {
						BOM_line_add(tTopBomLine, tItem2, tItemRev2, NULLTAG, &tNewLine2);

						// Check if tNewLine2 is not NULLTAG
						if (tNewLine2 != NULLTAG) {
							AOM_save_without_extensions(tNewLine2);
						}
						else {
							cout<<"Error: tNewLine2 is NULLTAG"<<endl;
							return -1;
						}
					}
					else {
						cout << "Error: tItem2 or tItemRev2 is NULLTAG" << endl;
						return -1;
					}
				}
			}

			BOM_save_window(tBomview);
			BOM_close_window(tBomview);
		}
		else {
			cout<<"Error: tBomview, tBvr, or tTopBomLine is NULLTAG\n"<<endl;
			return -1;
		}
	}
	else {
		cout<<"Error: tItem1 or tItemRev1 is NULLTAG"<<endl;
		return -1;
	}

	return 0;
}







































//int createBomusingfile()
//
//{
//	tag_t tItem1 = NULLTAG;  
//	tag_t tItemRev1 = NULLTAG;
//	tag_t tBomview = NULLTAG;
//	tag_t	tBvr = NULLTAG;
//	tag_t	tTopBomLine = NULLTAG;
//	tag_t	tItem2 = NULLTAG;
//	tag_t tItemRev2 = NULLTAG;
//	tag_t tNewLine1 = NULLTAG;
//	tag_t tNewLine2 = NULLTAG;
//	string line,Item,rev, Item2, rev2 ;
//	char *cItem = NULL;
//	char*crev = NULL;
//	char *cItem2 = NULL;
//	char *crev2=NULL;
//	ifstream inFile("input.txt");
//	getline(inFile, line);
//	size_t hypenpos = line.find("-");
//	cout << hypenpos << endl;
//	if (hypenpos != string::npos) {
//		Item = line.substr(0, hypenpos);
//		cItem = new char[line.length()+1];
//		cout << Item.length();
//		strcpy(cItem, Item.c_str());
//		rev = line.substr(hypenpos + 2);
//		crev = new char[2];
//		strcpy(crev, rev.c_str());
//	}
//	ITEM_find_item(cItem, &tItem1);
//	ITEM_find_rev(cItem,crev, &tItemRev1);
//	
//
//	PS_create_bom_view(NULLTAG, NULL, NULL, tItem1, &tBomview);
//	AOM_save_without_extensions(tBomview);
//	AOM_save_without_extensions(tItem1);
//
//	PS_create_bvr(tBomview, NULL, NULL, false, tItemRev1, &tBvr);
//	AOM_save_without_extensions(tBvr);
//	AOM_save_without_extensions(tItemRev1);
//
//	BOM_create_window(&tBomview);
//	AOM_save_without_extensions(tBomview);
//
//	BOM_set_window_top_line(tBomview, tItem1, tItemRev1, NULLTAG, &tTopBomLine);
//	AOM_save_without_extensions(tTopBomLine);
//
//	while (getline(inFile, line)) {
//		size_t hypenpos = line.find("-");
//		cout << hypenpos << endl;
//		if (hypenpos != string::npos) {
//			Item2= line.substr(0, hypenpos);
//			cItem2 = new char[line.length() + 1];
//			cout << line.length();
//			strcpy(cItem2, Item2.c_str());
//			rev2 = line.substr(hypenpos + 2);
//			crev2 = new char[2];
//			strcpy(crev2, rev2.c_str());
//			ITEM_find_item(cItem2, &tItem2);
//			ITEM_find_rev(cItem2, crev2, &tItemRev2);
//			BOM_line_add(tTopBomLine, tItem2, tItemRev2, NULLTAG, &tNewLine2);
//			AOM_save_without_extensions(tNewLine2);
//
//		}
//
//	}
//
//	BOM_save_window(tBomview);
//	BOM_close_window(tBomview);
//
//
//	return 0;
//
//}