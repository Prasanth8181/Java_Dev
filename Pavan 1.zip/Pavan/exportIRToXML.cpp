#include"TCHeader.h"
#include<pie/pie.h>


int ExportIRtoXML() {
	tag_t tSession_tag = NULLTAG;
	int iNum_trModes;
	tag_t* tTrModes = NULL;
	tag_t tItem = NULLTAG;

	checkiFail(ITEM_find_item("000488", &tItem));
	checkiFail(PIE_create_session(&tSession_tag));

	// Check if tItem and tSession_tag are not NULLTAG
	if (tItem != NULLTAG && tSession_tag != NULLTAG) {
		// checkiFail(PIE_find_transfer_mode2("ExpTransMode", "", &iNum_trModes, &tTrModes));
		// checkiFail(PIE_session_set_transfer_mode(tSession_tag, tTrModes[0]));
		checkiFail(PIE_session_set_file(tSession_tag, "D:/v/test1.xml"));
		checkiFail(PIE_session_export_objects(tSession_tag, 1, &tItem));
	}
	else {
		// Handle the error case where tItem or tSession_tag is NULLTAG
		cout<<"Error: tItem or tSession_tag is NULLTAG"<<endl;
		return -1;
	}

	return 0;
}























//int ExportIRtoXML()
//{
//	tag_t tSession_tag = NULLTAG;
//	int iNum_trModes;
//	tag_t* tTrModes = NULL;
//	tag_t tItem = NULLTAG;
//
//	checkiFail(ITEM_find_item("000488", &tItem));
//	checkiFail(PIE_create_session(&tSession_tag));
//
//	//checkiFail(PIE_find_transfer_mode2("ExpTransMode", "", &iNum_trModes, &tTrModes));
//
//	//checkiFail(PIE_session_set_transfer_mode(tSession_tag, tTrModes[0]));
//
//	checkiFail(PIE_session_set_file(tSession_tag, "D:/v/test1.xml"));
//
//	checkiFail(PIE_session_export_objects(tSession_tag,1,&tItem));
//
//	return 0;
//}