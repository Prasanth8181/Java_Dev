//list of secondary objects to the item revision.

//#include <iostream>
//#include<tccore/item.h>
//#include<tccore/grm.h>
//#include<tccore/aom.h>
#include"TCHeader.h"

using namespace std;


int SecondaryObjects()
{
	// Initialize variables
	tag_t tRev = NULLTAG;
	int icount = 0;
	tag_t* secondary_list = NULL;
	char* name = NULL;

	// Find the item revision with ID "000463" and revision "A"
	checkiFail(ITEM_find_rev("000463", "A", &tRev));

	// Check if the item revision tag is not NULLTAG
	if (tRev != NULLTAG) {
		// List secondary objects only for the item revision
		checkiFail(GRM_list_secondary_objects_only(tRev, NULLTAG, &icount, &secondary_list));

		// Iterate through the secondary objects and print their names
		for (int i = 0; i < icount; i++) {
			AOM_ask_name(secondary_list[i], &name);
			cout << name << endl;
			MEM_free(name); // Free the memory allocated for the name
		}

		// Free the memory allocated for the secondary list
		MEM_free(secondary_list);
	}
	else {
		cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
	}

	return 0;
}































//int SecondaryObjects()
//
//{
//	tag_t tRev = NULLTAG;
//	checkiFail(ITEM_find_rev("000463", "A", &tRev));
//	int icount;
//	tag_t* secondary_list = NULL;
//	char* name;
//	checkiFail(GRM_list_secondary_objects_only(tRev, NULLTAG, &icount, &secondary_list));
//	for (int i = 0; i < icount; i++)
//	{
//		AOM_ask_name(secondary_list[i], &name);
//		cout << name << endl;
//	}
//	return 0;
//}
//
