//Updating LOV value to the custom property.

#include"TCHeader.h"
#include<tc/preferences.h>
#include<lov/lov.h>

int UpdateLov()
{

	// Initialize variables
	tag_t tObj = NULLTAG;
	tag_t tLov = NULLTAG;
	LOV_usage_t lUsage;
	int iValues = 0;
	logical* lNull = nullptr;
	logical* lEmpty = nullptr;
	char** cValue = NULL;
	int iNum_values = 0;
	char** cVValues = NULL ;

	// Find the item revision with ID "000471" and revision "A"
	checkiFail(ITEM_find_rev("000471", "A", &tObj));

	// Check if the item tag is not NULLTAG
	if (tObj != NULLTAG) {
		// Ask for the LOV (List of Values) associated with the custom property "a2customprop1"
		checkiFail(AOM_ask_lov(tObj, "a2customprop1", &tLov));

		// Check if the LOV tag is not NULLTAG
		if (tLov != NULLTAG) {
			// Ask for the display values of the LOV
			checkiFail(LOV_ask_disp_values(tLov, &lUsage, &iValues, &lNull, &lEmpty, &cValue));

			// Print the usage, number of values, and the second value
			cout << lUsage << endl;
			cout << iValues << endl;
			if (iValues > 1) {
				cout << cValue[1] << endl;
			}

			// Refresh the item
			AOM_refresh(tObj, 1);

			// Set the custom property "a2customprop1" to the second value in the LOV
			checkiFail(AOM_set_value_string(tObj, "a2customprop1", cValue[1]));

			// Save the item without extensions
			AOM_save_without_extensions(tObj);

			// Refresh the item again
			AOM_refresh(tObj, 0);
		}
		else {
			cout << "Error: LOV tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}

















































//int UpdateLov()
//{
//
//	tag_t obj = NULLTAG; 
//	tag_t Lov = NULLTAG;
//
//	LOV_usage_t usage;
//	int n_values;
//	logical* is_null, *is_empty;
//	char** value;
//	int Num_values = 0;;
//	char** values=NULL;
//	
//
//	ITEM_find_rev("000471", "A", &obj);
//
//	AOM_ask_lov(obj, "a2customprop1", &Lov);
//	LOV_ask_disp_values(Lov, &usage, &n_values, &is_null, &is_empty, &value);
//	
//
//	cout << usage << endl;
//	cout << n_values << endl;
//	cout << value[1] << endl;
//	AOM_refresh(obj, 1);
//	AOM_set_value_string(obj, "a2customprop1", value[1]);
//	AOM_save_without_extensions(obj);
//	AOM_refresh(obj, 0);
//
//	return 0;
//}