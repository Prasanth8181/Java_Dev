#include"TCHeader.h"
#include<tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include <tccore/item.h>
#include <fclasses/tc_date.h>
#include <tccore/releasestatus.h>


using namespace std;

int RevisionUnitEffectivity()
{
	// Initialize variables
	int iFail = 0, iNum = 0;
	tag_t tFind = NULLTAG;
	tag_t* tStatuss = NULL;
	tag_t tEnd = NULLTAG;
	tag_t tEff = NULLTAG;

	// Get command line arguments
	const char* cTopI = ITK_ask_cli_argument("-TopI=");
	const char* cFind = ITK_ask_cli_argument("-find=");

	// Find the top item
	checkiFail(ITEM_find_item(cTopI, &tEnd));

	// Check if the top item tag is not NULLTAG
	if (tEnd != NULLTAG) {
		// Find the item revision
		checkiFail(ITEM_find_rev(cFind, "A", &tFind));

		// Check if the item revision tag is not NULLTAG
		if (tFind != NULLTAG) {
			// Ask for the release status list of the item revision
			checkiFail(WSOM_ask_release_status_list(tFind, &iNum, &tStatuss));

			// Print the number of release statuses
			cout << iNum << endl;

			// Create an effectivity for the release status
			checkiFail(WSOM_effectivity_create(tStatuss[0], tEnd, &tEff));

			// Set the unit range for the effectivity
			checkiFail(WSOM_eff_set_unit_range(tStatuss[0], tEff, "5-9", true));

			// Save the effectivity without extensions
			checkiFail(AOM_save_without_extensions(tEff));

			// Free the memory allocated for the release status list
			MEM_free(tStatuss);
		}
		else {
			cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Top item not found or top item tag is NULLTAG." << endl;
	}

	return 0;
}






































//
//int RevisionUnitEffectivity()
//
//{
//
//	int iFail = 0, iNum = 0;
//
//	tag_t tFind = NULLTAG;
//	tag_t *tStatuss = NULL;
//	tag_t tEnd = NULLTAG;
//	tag_t tEff = NULLTAG;
//	
//
//	const char *cTopI = ITK_ask_cli_argument("-TopI=");
//	const char *cFind = ITK_ask_cli_argument("-find=");
//
//	
//
//	checkiFail(ITEM_find_item(cTopI, &tEnd));
//	checkiFail(ITEM_find_rev(cFind, "A", &tFind));
//	
//
//	if (tFind != NULLTAG) {
//
//		checkiFail(WSOM_ask_release_status_list(tFind, &iNum, &tStatuss));
//
//		cout << iNum << endl;
//
//		checkiFail(WSOM_effectivity_create(tStatuss[0], tEnd, &tEff));
//
//		checkiFail(WSOM_eff_set_unit_range(tStatuss[0], tEff, "5-9", true));
//
//		checkiFail(AOM_save_without_extensions(tEff));
//		
//
//	}
//
//	return 0;
//
//}
