//Printing all the references of an ItemRevision where it is utilized in an Assembly

#include"TCHeader.h"
#include<ps/ps.h>




int WhereUsed()
{
	int tHits = 0;
	tag_t* tList = NULLTAG;

	// Find items with the name "frame"
	WSOM_find2("frame", &tHits, &tList);

	// Initialize variables
	//tag_t tTarget = NULLTAG;
	//int iN_levels = NULLTAG;
	int iParents = 0;
	int* iLevels = 0;
	tag_t* tParents = NULL;
	char* cName;

	// Check if the list is not empty and the first item is not NULLTAG
	if (tHits > 0 && tList[0] != NULLTAG) {
		// Find all parents of the first item in the list
		checkiFail(PS_where_used_all(tList[0], -1, &iParents, &iLevels, &tParents));

		// Iterate through the parents and print their names
		for (int i = 0; i < iParents; i++) {
			checkiFail(AOM_ask_name(tParents[i], &cName));
			cout << cName << endl;
		}
	}
	else {
		cout << "Error: No items found or first item is NULLTAG." << endl;
	}

	return 0;
}










































//int WhereUsed()
//{
//
//	int hits;
//	tag_t* list;
//	WSOM_find2("frame", &hits, &list);
//
//	tag_t target = NULLTAG;
//	int n_levels = NULLTAG;
//	 int n_parents;
//	 int* levels;
//	 tag_t* parents;
//	 char* name;
//
//	 PS_where_used_all(list[0], -1, &n_parents, &levels,&parents);
//	 for (int i = 0; i < n_parents; i++) {
//		 AOM_ask_name(parents[i], &name);
//		 cout << name << endl;
//	 }
//	 return 0;
//}