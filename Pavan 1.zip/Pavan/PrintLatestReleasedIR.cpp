#include"TCHeader.h"
#include<tccore/item.h>
#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include<tccore/aom_prop.h>
#include<pom/pom/pom.h>
#include<fclasses/tc_date.h>
#include<fclasses/tc_string.h>

using namespace std;

int PrintLatestRelesedIR() {

	// Initialize variables

	tag_t tItem = NULLTAG, tRev = NULLTAG, *tValue = NULLTAG, *tRevs = NULLTAG, tLat = NULLTAG;

	char *cName = NULL;

	char* cRevID = NULL, *cLat = NULL, *cCurr = NULL;

	int iNum = 0, iAnswer = 0;

	int iRevs = 0;

	date_t dCurrent = { 0 }, dLatest = { 0 };

	// Find the item with ID "000478"

	checkiFail(ITEM_find_item("000478", &tItem));


	// Check if the item tag is not NULLTAG

	if (tItem != NULLTAG) {

		checkiFail(ITEM_list_all_revs(tItem, &iRevs, &tRevs));

		for (int i = 0; i < iRevs; i++) {

			checkiFail(AOM_ask_value_tags(tRevs[i], "release_status_list", &iNum, &tValue));

			// Check if there are any release statuses

			if (iNum > 0) {


				// Set the object description to "Released"

				checkiFail(AOM_ask_value_date(tRevs[i], "date_released", &dCurrent));

				checkiFail(POM_compare_dates(dCurrent, dLatest, &iAnswer));

				if (iAnswer == 1) {

					tLat = tRevs[i];

				}

			}

		}

	}

	else {

		cout << "Error: Item not found or item tag is NULLTAG." << endl;

	}

	AOM_ask_value_string(tLat, "item_revision_id", &cLat);

	cout << cLat << endl;

	return 0;

}




