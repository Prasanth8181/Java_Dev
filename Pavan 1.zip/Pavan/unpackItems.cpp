#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include"TCHeader.h"


int UnPackitems()
{
	// Initialize variables
	tag_t tWindow = NULLTAG;
	tag_t tTopI = NULLTAG;
	tag_t tTopIR = NULLTAG;
	tag_t tBomLine = NULLTAG;
	tag_t* child = NULL;
	int count = 0;
	char* childName = NULL;

	// Find the item with ID "000181"
	checkiFail(ITEM_find_item("000181", &tTopI));

	// Check if the item tag is not NULLTAG
	if (tTopI != NULLTAG) {
		// Find the item revision with ID "000181" and revision "A"
		checkiFail(ITEM_find_rev("000181", "A", &tTopIR));

		// Check if the item revision tag is not NULLTAG
		if (tTopIR != NULLTAG) {
			// Create a BOM window
			checkiFail(BOM_create_window(&tWindow));

			// Set the top line of the BOM window
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));

			// Ask for all child lines of the BOM line
			checkiFail(BOM_line_ask_all_child_lines(tBomLine, &count, &child));

			// Unpack each child line
			for (int i = 0; i < count; i++) {
				checkiFail(BOM_line_unpack(child[2]));
			}

			// Print the name of each child line
			for (int i = 0; i < count; i++) {
				checkiFail(AOM_ask_value_string(child[2], "bl_indented_title", &childName));
				cout << childName << endl;
				MEM_free(childName); // Free the memory allocated for the child name
			}

			// Save the BOM window
			BOM_save_window(tWindow);

			// Close the BOM window
			BOM_close_window(tWindow);

			// Free the memory allocated for the child lines
			MEM_free(child);
		}
		else {
			cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}




































//int UnPackitems()
//
//{
//
//	tag_t tWindow = NULLTAG;
//	tag_t tTopI = NULLTAG;
//	tag_t tTopIR = NULLTAG;
//	tag_t tBomLine = NULLTAG;
//	tag_t tSubI = NULLTAG;
//	tag_t tSubIR = NULLTAG;
//	tag_t *child = NULLTAG;
//	tag_t tOut = NULLTAG;
//
//	int count;
//
//	char *childName = NULL;
//
//	checkiFail(ITEM_find_item("000181", &tTopI));
//
//	checkiFail(ITEM_find_rev("000181", "A", &tTopIR));
//
//	checkiFail(BOM_create_window(&tWindow));
//
//	checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//
//	checkiFail(BOM_line_ask_all_child_lines(tBomLine, &count, &child));
//
//	for (int i = 0; i < count; i++) {
//
//		checkiFail(BOM_line_unpack(child[2]));
//	}
//	for (int i = 0; i < count; i++) {
//
//		checkiFail(AOM_ask_value_string(child[2], "bl_indented_title", &childName));
//
//		cout << childName << endl;
//	}
//	BOM_save_window(tWindow);
//
//	BOM_close_window(tWindow);
//
//	return 0;
//
//}