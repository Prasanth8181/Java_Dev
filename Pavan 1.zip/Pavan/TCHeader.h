#include<stdio.h>
#include<conio.h>
#include<iostream>
#include<tc/tc_startup.h>
#include<tcinit/tcinit.h>
#include<tc/emh.h>
#include<tccore/item.h>
#include<sa/user.h>
#include <sa/group.h>
#include<tc/folder.h>
#include<tccore/aom.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include<fstream>
#include<tccore\aom_prop.h>
#include<tccore/grm.h>
#include<tccore/tctype.h>
#include<tc/folder.h>
#include <tccore/project.h> 
#include<tc/envelope.h>
#include<Bom/bom.h>
#include<ps/ps.h>




using namespace std;

int checkiFail(int iFail);
int ItemAttachHomeFolder();
int login();
int ownership();
int create_dataset();
int ItemCreate();
int where_referenced();
int users();
int ItemCreateAttachFolder();
int PrintallpropsofIR();
int WhereUsed();
int SecondaryObjects();
int CreateFormItemUpdate();
int projAssignMembers();
int DeleteSecondaryObjects();
int ItemsofDBA();
int ReadValueofPrefandUpdateobjDescofIR();
int UpdatecustomIRLov();
int SendaMail();
int createBom();
int propArryanItemprintitsAttributeType();
int UpdateLov();
 int CreateUserandPerson();
 int InactiveUser();
 int createBomusingfile();
 int updateReleaseStatusObjdesc();
 int makeuserinactive();
  int projAssignObject();
  int DatasetWithNamedRef();
  int DelNamedRefofDataset();
  int RenameofNamedRefofDataset();
  int SetCustomStatusForIR();
  int UserMailBoxDelete();
  int PrintLatestRevision();
  int localsubstitute();
  int GlobalAlternate();
  int Packitems();
  int UnPackitems();
  int SpiltOccurence();
  int InsertLevel();
  int InsertLeveLArray();
 // int ExportItemRevision();
  int BaseLine();
  int ExportIRtoXML();
  int DeleteSecondaryObjectsWithSpecificRelation();
  int BomCompare();
  int MultiBOMUsingFile();
  int OccurrenceUnitEffectivity();
  int OccurrenceDateEffectivity();
  int RevisionUnitEffectivity();
  int RevisionDateEffectivity();
  int ApplyingRevisionRule();
  int RemoveEffectivity();
  int PrintLatestRelesedIR();
  int ReviseItemRevision();
  int PrintAllDataSetWIthUser();
  int InitiateAWrkFlw();
  int ReviewTask();
  int ItemBaseLineRev();
  int CreateFormItemUpdate1();