//#include<iostream>
//#include<tc/tc_startup.h>
//#include<tcinit/tcinit.h>
//#include<tc/emh.h>
//#include<tccore/item.h>
#include"TCHeader.h"


using namespace std;

int ReviseItemRevision()
{
	tag_t tItem = NULLTAG;
	tag_t tRev = NULLTAG;
	tag_t tNewRev = NULLTAG; 
	tag_t *tDeepCopiedObjects = NULL;
	int cCount = 0;

	ITEM_deepcopy_info_t user_options[1];
	user_options[0].action= 9; // Option to copy datasets

	checkiFail(ITEM_find_item("000511", &tItem));

	checkiFail(ITEM_find_rev("000511", "A", &tRev));

	if (tItem != NULLTAG && tRev != NULLTAG) {

		checkiFail(ITEM_copy_rev(tRev,NULL,&tNewRev));
		//checkiFail(ITEM_copy_rev_using(tRev, NULL, 0, user_options,&tNewRev,&cCount,&tDeepCopiedObjects));
		checkiFail(ITEM_save_item(tRev));
	}
	else {
		cout << "Error: Item or Revision tag is NULLTAG." << endl;
	}

	return 0;
}


