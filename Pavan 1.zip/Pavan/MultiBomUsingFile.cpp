#include "TCHeader.h"
#include <tccore/item.h>
#include <ps/ps.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

//tag_t add(tag_t tBomLine, tag_t tChild1I, tag_t tChild1IR);


int MultiBOMUsingFile() {
	tag_t tTopI = NULLTAG, tTopIR = NULLTAG, tBomView = NULLTAG, tBvr = NULLTAG, tWindow = NULLTAG, tBomLine = NULLTAG;
	tag_t tChild1I, tChild1IR, tTag[4] = { NULLTAG, NULLTAG, NULLTAG, NULLTAG }, tNew1BomLine = NULLTAG;

	ifstream inFile("MultiBom.txt");
	string rev, line, Item, level;
	int levelInt = 0;
	char* cItem, *crev, *cItem1, *crev1;

	getline(inFile, line);
	size_t fhyphenPos = line.find('-');
	size_t shyphenPos = line.find('-', fhyphenPos + 1);

	if (fhyphenPos != string::npos) {
		level = line[0];
		levelInt = stoi(level);

		if (shyphenPos != string::npos) {
			Item = line.substr(fhyphenPos + 2, shyphenPos - fhyphenPos - 2);
			rev = line[shyphenPos + 2];
			cItem = new char[Item.length() + 1];
			strcpy(cItem, Item.c_str());
			crev = new char[rev.length() + 1];
			strcpy(crev, rev.c_str());

			ITEM_find_item(cItem, &tTopI);
			ITEM_find_rev(cItem, crev, &tTopIR);

			// Check if tTopI and tTopIR are not NULLTAG
			if (tTopI != NULLTAG && tTopIR != NULLTAG) {
				PS_create_bom_view(NULLTAG, NULL, NULL, tTopI, &tBomView);
				AOM_save_without_extensions(tBomView);
				AOM_save_without_extensions(tTopI);

				PS_create_bvr(tBomView, NULL, NULL, false, tTopIR, &tBvr);
				AOM_save_without_extensions(tBvr);
				AOM_save_without_extensions(tTopIR);

				BOM_create_window(&tWindow);
				BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine);
				tTag[0] = tBomLine;
				AOM_save_without_extensions(tBomLine);

				// Check if tBomView, tBvr, tWindow, and tBomLine are not NULLTAG
				if (tBomView != NULLTAG && tBvr != NULLTAG && tWindow != NULLTAG && tBomLine != NULLTAG) {
					while (getline(inFile, line)) {
						fhyphenPos = line.find('-');
						shyphenPos = line.find('-', fhyphenPos + 1);

						if (fhyphenPos != string::npos) {
							if (shyphenPos != string::npos) {
								level = line[0];
								levelInt = stoi(level);

								Item = line.substr(fhyphenPos + 2, shyphenPos - fhyphenPos - 2);
								rev = line[shyphenPos + 2];
								cItem1 = new char[Item.length() + 1];
								strcpy(cItem1, Item.c_str());
								crev1 = new char[rev.length() + 1];
								strcpy(crev1, rev.c_str());

								ITEM_find_item(cItem1, &tChild1I);
								ITEM_find_rev(cItem1, crev1, &tChild1IR);

								// Check if tChild1I and tChild1IR are not NULLTAG
								if (tChild1I != NULLTAG && tChild1IR != NULLTAG) {
									BOM_line_add(tTag[levelInt - 1], tChild1I, tChild1IR, NULLTAG, &tNew1BomLine);

									// Check if tNew1BomLine is not NULLTAG
									if (tNew1BomLine != NULLTAG) {
										tTag[levelInt] = tNew1BomLine;
										AOM_save_without_extensions(tTag[levelInt]);
									}
									else {
										cout << "Error: tNew1BomLine is NULLTAG" << endl;
										return -1;
									}
								}
								else {
									cout << "Error: tChild1I or tChild1IR is NULLTAG" << endl;
									return -1;
								}
							}
						}
					}

					for (int i = 0; i < 4; i++) {
						cout << tTag[i] << endl;
					}

					BOM_save_window(tWindow);
					BOM_close_window(tWindow);
				}
				else {
					cout << "Error: tBomView, tBvr, tWindow, or tBomLine is NULLTAG" << endl;
					return -1;
				}
			}
			else {
				cout << "Error: tTopI or tTopIR is NULLTAG" << endl;
				return -1;
			}
		}
	}

	return -1;
}





























































//
//
//
//
//
//
//int MultiBOMUsingFile() {
//	tag_t tTopI = NULLTAG, tTopIR = NULLTAG, tBomView = NULLTAG, tBvr = NULLTAG, tWindow = NULLTAG, tBomLine = NULLTAG;
//
//	
//
//	tag_t tChild1I, tChild1IR, tTag[4] = { NULLTAG, NULLTAG, NULLTAG, NULLTAG }, tNew1BomLine = NULLTAG;
//
//	ifstream inFile("MultiBom.txt");
//
//	string rev, line, Item, level;
//
//	int levelInt = 0;
//
//	char* cItem, *crev, *cItem1, *crev1;
//
//	getline(inFile, line);
//
//	size_t fhyphenPos = line.find('-');
//
//	size_t shyphenPos = line.find('-', fhyphenPos + 1);
//
//	if (fhyphenPos != string::npos) {
//
//		level = line[0];
//
//		levelInt = stoi(level);
//
//		if (shyphenPos != string::npos) {
//
//			Item = line.substr(fhyphenPos + 2, shyphenPos - fhyphenPos - 2);
//
//			rev = line[shyphenPos + 2];
//
//			cItem = new char[Item.length() + 1];
//
//			strcpy(cItem, Item.c_str());
//
//			crev = new char[2];
//
//			strcpy(crev, rev.c_str());
//
//			ITEM_find_item(cItem, &tTopI);
//
//			ITEM_find_rev(cItem, crev, &tTopIR);
//
//			PS_create_bom_view(NULLTAG, NULL, NULL, tTopI, &tBomView);
//
//			AOM_save_without_extensions(tBomView);
//
//			AOM_save_without_extensions(tTopI);
//
//			PS_create_bvr(tBomView, NULL, NULL, false, tTopIR, &tBvr);
//
//			AOM_save_without_extensions(tBvr);
//
//			AOM_save_without_extensions(tTopIR);
//
//			BOM_create_window(&tWindow);
//
//			BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine);
//
//			tTag[0] = tBomLine;
//
//			AOM_save_without_extensions(tBomLine);
//
//			while (getline(inFile, line)) {
//
//				fhyphenPos = line.find('-');
//
//				shyphenPos = line.find('-', fhyphenPos + 1);
//
//				if (fhyphenPos != string::npos) {
//
//					if (shyphenPos != string::npos) {
//
//						level = line[0];
//
//						levelInt = stoi(level);
//
//						cout << level << endl;
//
//						cout << levelInt << endl;
//
//						Item = line.substr(fhyphenPos + 2, shyphenPos - fhyphenPos - 2);
//
//						rev = line[shyphenPos + 2];
//
//						cItem1 = new char[Item.length() + 1];
//
//						strcpy(cItem1, Item.c_str());
//
//						crev1 = new char[2];
//
//						strcpy(crev1, rev.c_str());
//
//						cout << Item << endl;
//
//						cout << rev << endl;
//
//						ITEM_find_item(cItem1, &tChild1I);
//
//						ITEM_find_rev(cItem1, crev1, &tChild1IR);
//
//						PS_create_bom_view(NULLTAG, NULL, NULL, tChild1I, &tBomView);
//
//						AOM_save_without_extensions(tBomView);
//
//						AOM_save_without_extensions(tTopI);
//
//						PS_create_bvr(tBomView, NULL, NULL, false, tChild1IR, &tBvr);
//
//						AOM_save_without_extensions(tBvr);
//
//						BOM_line_add(tTag[levelInt - 1], tChild1I, tChild1IR, NULLTAG, &tNew1BomLine);
//
//						tTag[levelInt] = tNew1BomLine;
//
//						AOM_save_without_extensions(tTag[levelInt]);
//
//
//					}
//
//				}
//
//			}
//
//			for (int i = 0; i < 4; i++) {
//
//				cout << tTag[i] << endl;
//
//			}
//
//			BOM_save_window(tWindow);
//
//			BOM_close_window(tWindow);
//
//			return 0;
//
//		}
//
//	}
//
//	return -1;
//
//}
//
//
