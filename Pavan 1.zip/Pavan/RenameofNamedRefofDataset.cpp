//Changing Name of a named reference as the name of that dataset.

#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include<tcinit/tcinit.h>
#include <tccore/aom.h>
#include <string>
#include<tccore/aom_prop.h>
#include"TCHeader.h"



using namespace std;

int RenameofNamedRefofDataset()
{
	// Initialize variables
	tag_t tDataset = NULLTAG;
	AE_reference_type_t aReferenceType;
	tag_t tRefObj = NULLTAG;
	int iFound = 0;
	tag_t* tRef = NULL;
	char* cRefName = NULL;
	char* cName = NULL;

	// Find the dataset with the name "test1"
	checkiFail(AE_find_dataset2("pdf55", &tDataset));

	// Check if the dataset tag is not NULLTAG
	if (tDataset != NULLTAG && tRefObj!=NULLTAG) {
		// Ask for the named references of the dataset
		checkiFail(AE_ask_dataset_named_refs(tDataset, &iFound, &tRef));

		// Iterate through the named references
		for (int i = 0; i < iFound; i++) {
			// Refresh the dataset and the reference
			AOM_refresh(tDataset, true);
			AOM_refresh(tRef[0], 1);

			// Find the named reference of the dataset
			checkiFail(AE_find_dataset_named_ref2(tDataset, 0, &cRefName, &aReferenceType, &tRefObj));

			// Set the original file name of the reference to "test1"
			checkiFail(AOM_set_value_string(tRef[i], "original_file_name", "test"));

			// Save the reference without extensions
			AOM_save_without_extensions(tRef[i]);

			// Refresh the dataset and the reference again
			AOM_refresh(tDataset, false);
			AOM_refresh(tRef[0], 0);

			// Free the memory allocated for refName
			MEM_free(cRefName);
		}

		// Free the memory allocated for the named references
		MEM_free(tRef);
	}
	else {
		cout << "Error: Dataset not found or dataset tag is NULLTAG." << endl;
	}

	cout << iFound << endl;

	return 0;
}




















//
//int RenameofNamedRefofDataset()
//
//{
//	tag_t dataset = NULLTAG;
//	AE_reference_type_t referenceType;
//	tag_t refObj = NULLTAG;
//	int n_found;
//	tag_t *ref = NULL;
//	char * refName = NULL;
//	char *name = NULL;
//
//	AE_find_dataset2("pdf55", &dataset);
//
//	AE_ask_dataset_named_refs(dataset, &n_found, &ref);
//	for (int i = 0; i < n_found; i++)
//	{
//		AOM_refresh(dataset, true);
//		AOM_refresh(ref[0], 1);
//		AE_find_dataset_named_ref2(dataset, 0, &refName, &referenceType, &refObj);
//		AOM_set_value_string(ref[i], "original_file_name", "test1");
//		AOM_save_without_extensions(ref[i]);
//		AOM_refresh(dataset, false);
//		AOM_refresh(ref[0], 0);
//
//	}
//	cout << n_found << endl;
//
//	return 0;
//
//}

