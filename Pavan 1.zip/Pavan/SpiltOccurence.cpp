#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <iostream>
#include <tccore/aom_prop.h>
#include "TCHeader.h"


using namespace std;

int SpiltOccurence()
{
	// Initialize variables
	int iCount = 0;
	char* cValue = nullptr;
	tag_t tTopI1 = NULLTAG;
	tag_t tTopIR1 = NULLTAG;
	tag_t tBomLine1 = NULLTAG;
	tag_t tWindow1 = NULLTAG;
	tag_t* tChild = nullptr;

	// Get command line arguments
	const char* item = ITK_ask_cli_argument("-item=");
	const char* TopItem = ITK_ask_cli_argument("-topitem=");
	const char* TopIR = ITK_ask_cli_argument("-topitemrev=");

	// Find the top item
	checkiFail(ITEM_find_item(TopItem, &tTopI1));

	// Check if the top item tag is not NULLTAG
	if (tTopI1 != NULLTAG) {
		// Find the top item revision
		checkiFail(ITEM_find_rev(TopItem, TopIR, &tTopIR1));

		// Check if the top item revision tag is not NULLTAG
		if (tTopIR1 != NULLTAG) {
			// Create a BOM window
			checkiFail(BOM_create_window(&tWindow1));

			// Set the top line of the BOM window
			checkiFail(BOM_set_window_top_line(tWindow1, tTopI1, tTopIR1, NULLTAG, &tBomLine1));

			// Ask for all child lines of the BOM line
			checkiFail(BOM_line_ask_all_child_lines(tBomLine1, &iCount, &tChild));

			// Iterate through the child lines
			for (int i = 0; i < iCount; i++) {
				// Get the item ID of the child line
				checkiFail(AOM_ask_value_string(tChild[i], "bl_item_item_id", &cValue));

				// Check if the item ID matches the specified item
				if (strcmp(cValue, item) == 0) {
					// Split the occurrence of the child line
					checkiFail(BOM_line_split_occurrence("2", tChild[i]));
				}

				// Free the memory allocated for the item ID
				MEM_free(cValue);
			}

			// Save the BOM line without extensions
			AOM_save_without_extensions(tBomLine1);

			// Save the BOM window
			BOM_save_window(tWindow1);

			// Close the BOM window
			BOM_close_window(tWindow1);

			// Free the memory allocated for the child lines
			MEM_free(tChild);
		}
		else {
			cout << "Error: Top item revision not found or top item revision tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Top item not found or top item tag is NULLTAG." << endl;
	}

	return 0;
}



















































//
//{
//
//    	int  iCount;
//	    char *cValue = NULL;
//	    tag_t tTopI1 = NULLTAG;
//		tag_t  tTopIR1 = NULLTAG;
//		tag_t tBomLine1 = NULLTAG;
//		tag_t tBomLine2 = NULLTAG;
//		tag_t tTopI2 = NULLTAG;
//		tag_t tTopIR2 = NULLTAG;
//		tag_t tWindow1 = NULLTAG;
//		tag_t *tChild = NULLTAG;
//
//	
//	const char *item = ITK_ask_cli_argument("-item=");
//	const char *TopItem = ITK_ask_cli_argument("-topitem=");
//	const char *TopIR = ITK_ask_cli_argument("-topitemrev=");
//
//
//	checkiFail(ITEM_find_item(TopItem, &tTopI1));
//
//	checkiFail(ITEM_find_rev(TopItem, TopIR, &tTopIR1));
//
//	checkiFail(BOM_create_window(&tWindow1));
//
//	checkiFail(BOM_set_window_top_line(tWindow1, tTopI1, tTopIR1, NULLTAG, &tBomLine1));
//
//	checkiFail(BOM_line_ask_all_child_lines(tBomLine1, &iCount, &tChild));
//
//	for (int i = 0; i < iCount; i++)
//
//	{
//
//		checkiFail(AOM_ask_value_string(tChild[i], "bl_item_item_id", &cValue));
//
//		if (strcmp(cValue, item) == 0)
//
//		{
//
//			checkiFail(BOM_line_split_occurrence("1", tChild[i]));
//
//		}
//
//	}
//	AOM_save_without_extensions(tBomLine1);
//
//	BOM_save_window(tWindow1);
//
//
//	return 0;
//
//}
//
