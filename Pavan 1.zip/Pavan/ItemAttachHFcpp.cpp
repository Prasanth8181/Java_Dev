#include<iostream>
#include<tc/tc_startup.h>
#include<tcinit/tcinit.h>
#include<tc/emh.h>
#include<tccore/item.h>
#include<sa/user.h>
#include<tc/folder.h>
#include<tccore/aom.h>
#include"TCHeader.h"


using namespace std;

int ItemAttachHomeFolder() {
	tag_t tItem = NULLTAG;
	tag_t tRev = NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHome_Folder = NULLTAG;

	checkiFail(ITEM_create_item("000790", "item1", "Item", "A", &tItem, &tRev));

	if (tItem != NULLTAG && tRev != NULLTAG) {
		checkiFail(ITEM_save_item(tItem));
		cout << "Item created" << endl;

		checkiFail(SA_find_user2("infodba", &tUser));
		if (tUser != NULLTAG) {
			checkiFail(SA_ask_user_home_folder(tUser, &tHome_Folder));
			if (tHome_Folder != NULLTAG) {
				checkiFail(FL_insert(tHome_Folder, tItem, 999));
				checkiFail(AOM_save_without_extensions(tHome_Folder));
			}
			else {
				cout << "Home folder not found." << endl;
			}
		}
		else {
			cout << "User not found." << endl;
		}
	}
	else {
		cout << "Item or revision creation failed." << endl;
	}

	return 0;
}

































//int ItemAttachHomeFolder()
//{
//
//	tag_t tItem = NULLTAG;
//	tag_t tRev = NULLTAG;
//	tag_t tUser = NULLTAG;
//	tag_t	tHome_Folder = NULLTAG;
//
//ITEM_create_item("000790", "item1", "Item", "A", &tItem, &tRev);
//
//ITEM_save_item(tItem);
//
//cout << "item created " << endl;
//
//SA_find_user2("infodba", &tUser);
//SA_ask_user_home_folder(tUser, &tHome_Folder);
//
//FL_insert(tHome_Folder, tItem, 999);
//AOM_save_without_extensions(tHome_Folder);
////AOM_save(item);
//return 0;
//}
//
//























//
//int ITK_user_main(int argc, char*argv[])
//
//{
//
//	int iFail = 0;
//
//	char *message = NULL;
//
//	tag_t item, rev, user, Home_Folder;
//
//	/*char*user_id = ITK_ask_cli_argument("-u=");  // tc_startup
//
//	char*password = ITK_ask_cli_argument("-p=");
//
//	char*group = ITK_ask_cli_argument("-g=");
//
//	iFail = ITK_init_module(user_id, password, group);*///tcinit
//
//	/*iFail = ITK_init_module("infodba", "infodba", "dba");*/
//
//	iFail = ITK_auto_login();//tcinit
//
//	if (iFail == ITK_ok)
//
//	{
//
//		cout << "Login sucessfully \n";
//
//		ITEM_create_item("000779", "item1", "Item", "A", &item, &rev);
//
//		ITEM_save_item(item);
//
//		cout << "item created " << endl;
//
//		SA_find_user2("infodba", &user);
//		SA_ask_user_home_folder(user, &Home_Folder);
//
//		FL_insert(Home_Folder, item, 999);
//		AOM_save(Home_Folder);
//		//AOM_save(item);
//	    
//
//	}
//
//	else
//
//	{
//
//		EMH_ask_error_text(iFail, &message); //tc- emh
//
//		cout << message;
//
//	}
//
//	return 0;
//
//}
