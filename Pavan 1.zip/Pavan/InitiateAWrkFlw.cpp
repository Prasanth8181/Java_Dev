#include "TCHeader.h"
#include<iostream>
#include<tcinit/tcinit.h>
#include<tccore/item.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<epm/epm_task_template_itk.h>
#include<epm/epm.h>

using namespace std;

int InitiateAWrkFlw()
{

	tag_t tNProcess = NULLTAG;

	tag_t tRev1;

	const int iTarget[1] = { 1 };

	tag_t tProcessTemplate = NULLTAG;

	int iCount = 0;

	tag_t *tTasks = NULL;

	char*cName = NULL;

	tag_t tUser = NULLTAG;

	tag_t *tMembers = NULL;

	

	checkiFail(ITEM_find_rev("000567", "A", &tRev1));

	if (tNProcess != NULLTAG && tProcessTemplate != NULLTAG && tUser != NULLTAG){

		const tag_t tRev[1] = { tRev1 };

		checkiFail(EPM_find_process_template("approved", &tProcessTemplate));

		checkiFail(EPM_create_process("WorkFlow", "", tProcessTemplate, 1, tRev, iTarget, &tNProcess));
	}

	

	return 0;

}


