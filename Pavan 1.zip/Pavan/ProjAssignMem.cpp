//Assign the Project to the members.

#include "TCHeader.h"


int projAssignMembers()
{
	// Initialize variables
	tag_t tUser = NULLTAG;
	int iMemCount = 1, iPrivUserCount = 1, iAdminCount = 1;
	tag_t tProject1 = NULLTAG;
	char* errMsg = nullptr;
	int ifail = 0;
	tag_t tProjAdmin = NULLTAG;

	// Find the user with username "izn"
	checkiFail(SA_find_user2("izn", &tUser));
	cout << "1" << endl;

	// Check if the user tag is not NULLTAG
	if (tUser != NULLTAG) {
		tag_t tMembers[] = { tUser };

		// Find the user with username "infodba"
		checkiFail(SA_find_user2("infodba", &tProjAdmin));
		tag_t listOfAdmins[] = { tProjAdmin };
		cout << "2" << endl;

		// Check if the project admin tag is not NULLTAG
		if (tProjAdmin != NULLTAG) {
			tag_t tPrivUsers[] = { tUser };

			// Find the project with the name "TC"
			checkiFail(PROJ_find("TC", &tProject1));
			cout << "3" << endl;

			// Check if the project tag is not NULLTAG
			if (tProject1 != NULLTAG) {
				// Assign the team to the project
				checkiFail(PROJ_assign_team(tProject1, iMemCount, tMembers, tProjAdmin, iPrivUserCount, tPrivUsers));

				// Ask for error text if any
				EMH_ask_error_text(ifail, &errMsg);
				cout << errMsg;
				cout << "4" << endl;

				// Free the memory allocated for error message
				MEM_free(errMsg);
			}
			else {
				cout << "Error: Project not found or project tag is NULLTAG." << endl;
			}
		}
		else {
			cout << "Error: Project admin not found or project admin tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: User not found or user tag is NULLTAG." << endl;
	}

	return 0;
}
































//
//#include<iostream>
//
//#include<tc/tc_startup.h>
//
//#include<tccore/tctype.h>
//
//#include<tcinit/tcinit.h>
//
//#include<tccore/item.h>
//
//#include<tccore/aom.h>
//
//#include<tccore/aom_prop.h>
//
//#include<sa/user.h>
//
//#include<sa/group.h>
//
//#include<tc/folder.h>
//
//#include<tccore/grm.h>
//
//#include<tccore/project.h>
//
//#include<tc/emh.h>
//
//#include<pom/pom/pom.h>
//
//using namespace std;
//
//int ITK_user_main(int   argc, char ** argv)
//
//{
//
//	int ifail = 0;
//
//	tag_t project = NULLTAG;
//
//	tag_t group_tag = NULLTAG;
//
//	int n_members = 0;
//
//	tag_t* members = NULL;
//
//	char * value = NULL;
//
//	{
//
//		ifail = ITK_init_module("infodba", "infodba", "dba");
//
//		if (ifail == ITK_ok)
//
//		{
//
//			cout << "login successfull\n";
//
//			ifail = PROJ_find("09123", &project);
//
//			if (ifail == ITK_ok && project != NULLTAG) {
//
//				cout << "project found successfull\n";
//
//				ifail = SA_find_group("izn", &group_tag);
//
//				if (ifail == ITK_ok && group_tag != NULLTAG) {
//
//					cout << "group found successfull\n";
//
//					ifail = POM_list_group_members(group_tag, &n_members, &members);
//
//					for (int i = 0; i < n_members; i++) {
//
//						ifail = AOM_ask_value_string(members[i], "user_name", &value);
//
//						if (ifail == ITK_ok && group_tag != NULLTAG) {
//
//							cout << value << "\n";
//
//							ifail = PROJ_add_members(project, n_members, &members[i]);
//
//							if (ifail == ITK_ok) {
//
//								AOM_save_without_extensions(project);
//
//							}
//
//							else
//
//							{
//
//								char* text = NULL;
//
//								EMH_ask_error_text(ifail, &text);
//
//								cout << text;
//
//							}
//
//						}
//
//						else
//
//						{
//
//							char* text = NULL;
//
//							EMH_ask_error_text(ifail, &text);
//
//							cout << text;
//
//						}
//
//					}
//
//					cout << "members added to the project successfull\n";
//
//				}
//
//				else
//
//				{
//
//					char* text = NULL;
//
//					EMH_ask_error_text(ifail, &text);
//
//					cout << text;
//
//				}
//
//			}
//
//			else
//
//			{
//
//				char* text = NULL;
//
//				EMH_ask_error_text(ifail, &text);
//
//				cout << text;
//
//			}
//
//		}
//
//		else
//
//		{
//
//			char* text = NULL;
//
//			EMH_ask_error_text(ifail, &text);
//
//			cout << text;
//
//		}
//
//
//	}
//
//
//	return 0;
//
//}
//
//
//
//
//
//

























//int projAssignMembers()
//
//{
//
//	tag_t tUser = NULLTAG;
//
//	int iMemCount = 1, iPrivUserCount = 1, iAdminCount = 1;
//
//	tag_t tProject1 = NULLTAG;
//	char *errMsg = NULL;
//	int ifail = 0;
//	tag_t tProjAdmin = NULLTAG;
//	SA_find_user2("izn", &tUser);
//	cout << "1" << endl;
//	 tag_t tMembers[] = {tUser};
//	SA_find_user2("infodba", &tProjAdmin);
//	tag_t listOfAdmins[] = { tProjAdmin };
//	cout << "2" << endl;
//	tag_t tPrivUsers[] = { tUser };
//	//const char *cProjId = ITK_ask_cli_argument("-id");
//
//	PROJ_find("TC", &tProject1);
//	cout << "3" << endl;
//	/*ifail = PROJ_assign_team_members(tProject1, iMemCount, tMembers, iAdminCount, listOfAdmins, iPrivUserCount, tPrivUsers );
//	EMH_ask_error_text(ifail,&errMsg);
//	cout << errMsg;*/
//	/*cout << "4" << endl;*/
//	PROJ_assign_team(tProject1, iMemCount, tMembers, tProjAdmin, iPrivUserCount, tPrivUsers);
//	EMH_ask_error_text(ifail, &errMsg);
//	cout << errMsg;
//	cout << "4" << endl;
//
//	return 0;
//
//}
//
