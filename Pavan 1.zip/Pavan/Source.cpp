//#include"TCHeader.h"
//
//#include<iostream>
//
//#include<tccore/item.h>
//
//#include<epm/epm.h>
//
//#include<epm/epm_task_template_itk.h>
//
//#include<sa/user.h>
//
//#include<epm/signoff.h>
//
//#include<string>
//
////int checkiFail(iFail);
//
//tag_t* tTasks = NULL;
//
//tag_t tUser = NULL;
//
//int iNum = 0;
//
//tag_t *tMembers = NULL;
//
//tag_t *tSignoff = NULL;
//
//using namespace std;
//
//int wrkflw_status() {
//
//	tag_t tItem = NULLTAG, tProcessT = NULLTAG, tNewProc = NULL, *tTasks;
//
//	int iCount = 0;
//
//	char *cName;
//
//	checkiFail(ITEM_find_rev("000567", "A", &tItem));
//
//	const int a[1] = { 1 };
//
//	const tag_t b[1] = { tItem };
//
//	checkiFail(EPM_find_process_template("ITK", &tProcessT));
//
//	checkiFail(EPM_create_process("ProcessName112", "Desc", tProcessT, 1, b, a, &tNewProc));
//
//	checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	while (iCount) {
//
//		checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//		cout << iCount << endl;
//
//		checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//		cout << cName << endl;
//
//		/*int ch = */
//
//		//getIntegerInput();
//
//		int input;
//
//		//while (true) {
//
//		cout << "Enter 0 for DoTask, 1 for Conditional Task, 2 for Review Task, -1 to Exit: ";
//
//		cin >> input;
//
//		switch (input) {
//
//		case 0:
//
//			checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//			cout << iCount << endl;
//
//			checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//			cout << cName << endl;
//
//			doTask(tTasks[1]);
//
//			break;
//
//		case 1:
//
//			checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//			cout << iCount << endl;
//
//			checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//			cout << cName << endl;
//
//			conditionTask(tTasks[1]);
//
//			break;
//
//		case 2:
//
//			checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//			cout << iCount << endl;
//
//			checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//			cout << cName << endl;
//
//			reviewTask(tTasks[2]);
//
//			checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//			cout << iCount << endl;
//
//			checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//			cout << cName << endl;
//
//			perform(tSignoff, tTasks[2]);
//
//			break;
//
//			/*case -1:
//
//				exit();
//
//				return 0;*/
//
//		default:
//
//			cout << "Invalid input. Please enter 0, 1, 2, or -1." << endl;
//
//			break;
//
//		}
//
//		//}
//
//	}
//
//	//	switch (ch) {
//
//	//	case true:
//
//	//		checkiFail(EPM_set_signoff_decision(tSignoff[0], EPM_approve_decision, "Approved"));
//
//	//		//checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_True));
//
//	//		checkiFail(EPM_trigger_action_if_privileged(tTasks[2], EPM_complete_action, "completed signoff task"));
//
//	//		break;
//
//	//	case false:
//
//	//		checkiFail(EPM_set_signoff_decision(tSignoff[0], EPM_reject_decision, "Rejected"));
//
//	//		//checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_True));
//
//	//		checkiFail(EPM_trigger_action_if_privileged(tTasks[2], EPM_complete_action, "completed signoff task"));
//
//	//		break;
//
//	//	default:
//
//	//		break;
//
//	//	}
//
//	//}
//
//	/*for (int i = 0; i < 2; i++) {
//
//		checkiFail(EPM_ask_name2(tTasks[i],&cName));
//
//		cout << cName << endl;
//
//		checkiFail(EPM_set_task_result(tTasks[i], EPM_RESULT_Completed));
//
//		checkiFail(EPM_trigger_action_if_privileged(tTasks[i], EPM_complete_action, "completed"));
//
//	}*/
//
//	/*checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;
//
//	checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;
//
//	checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_Unable_to_complete));
//
//	checkiFail(EPM_trigger_action_if_privileged(tTasks[1], EPM_complete_action, "completed"));
//
//	checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;
//
//	checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_Completed));
//
//	checkiFail(EPM_trigger_action_if_privileged(tTasks[1], EPM_complete_action, "completed"));*/
//
//	return 0;
//
//}
//
//void doTask(tag_t tTask)
//
//{
//
//	/*checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;*/
//
//	checkiFail(EPM_set_task_result(tTask, EPM_RESULT_Completed));
//
//	checkiFail(EPM_trigger_action_if_privileged(tTask, EPM_complete_action, "completed the do task"));
//
//	//check(EPM_promote_task(tTasks[3], "complete"));
//
//	cout << "\nDo done";
//
//	//outfile << "\nDo dne";
//
//}
//
//bool getBooleanInput() {
//
//	int input;
//
//	while (true) {
//
//		cout << "Enter 1 for True or 0 for False for conditional task: ";
//
//		cin >> input;
//
//		if (input == 1) {
//
//			return true;
//
//		}
//
//		else if (input == 0) {
//
//			return false;
//
//		}
//
//		else {
//
//			cout << "Invalid input. Please enter 1 or 0." << endl;
//
//		}
//
//	}
//
//}
//
////void getIntegerInput() {
//
////	
//
////}
//
////int getintegerInput() {
//
////	int input;
//
////	while (true) {
//
////		cout << "Enter 0 for DoTask, 1 for conditional task,2 for review task,-1 to exit: ";
//
////		cin >> input;
//
////		if (input == 1) {
//
////			conditionTask();
//
////			return 0;
//
////		}
//
////		else if (input == 0) {
//
////			doTask();
//
////			return 0;
//
////		}
//
////		else if (input == 2) {
//
////			reviewTask();
//
////			return 0;
//
////		}
//
////		else if (input == -1) {
//
////			exit();
//
////			return 0;
//
////		}
//
////		else {
//
////			cout << "Invalid input. Please enter 1 or 0." << endl;
//
////		}
//
////	}
//
////}
//
//void conditionTask(tag_t tTask)
//
//{
//
//	/*checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;*/
//
//	bool ch = getBooleanInput();
//
//	switch (ch) {
//
//	case true:
//
//		checkiFail(EPM_set_task_result(tTask, EPM_RESULT_True));
//
//		checkiFail(EPM_trigger_action_if_privileged(tTask, EPM_complete_action, "completed"));
//
//		break;
//
//	case false:
//
//		checkiFail(EPM_set_task_result(tTask, EPM_RESULT_False));
//
//		checkiFail(EPM_trigger_action_if_privileged(tTask, EPM_complete_action, "completed"));
//
//		break;
//
//	default:
//
//		break;
//
//	}
//
//	/* tag_t *tTasks = NULL;
//
//	checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_Completed));
//
//	checkiFail(EPM_trigger_action_if_privileged(tTasks[1], EPM_complete_action, "completed the do task"));*/
//
//	//check(EPM_promote_task(tTasks[3], "complete"));
//
//	cout << "\nconditional task done";
//
//	//outfile << "\nDo dne";
//
//}
//
//int reviewTask(tag_t tTask)
//
//{
//
//	/*checkiFail(EPM_ask_tasks(tNewProc, EPM_started, &iCount, &tTasks));
//
//	cout << iCount << endl;
//
//	checkiFail(EPM_ask_name2(tTasks[1], &cName));
//
//	cout << cName << endl;*/
//
//	cout << "\nEnter the user id: ";
//
//	string user = "izn";
//
//	//getline(cin, user);
//
//	checkiFail(SA_find_user2(user.c_str(), &tUser));
//
//	checkiFail(SA_find_groupmember_by_user(tUser, &iNum, &tMembers));
//
//	checkiFail(EPM_create_adhoc_signoff(tTask, tMembers[1], &iNum, &tSignoff));
//
//	checkiFail(EPM_set_adhoc_signoff_selection_done(tTask, TRUE));
//
//	checkiFail(EPM_trigger_action(tTask, EPM_complete_action, "completed the select reviewers task"));
//
//	cout << "\nsignoff member selection done";
//
//	/*perform(tSignoff);*/
//
//	/* tag_t *tTasks = NULL;
//
//	checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_Completed));
//
//	checkiFail(EPM_trigger_action_if_privileged(tTasks[1], EPM_complete_action, "completed the do task"));*/
//
//	//check(EPM_promote_task(tTasks[3], "complete"));
//
//	cout << "\nreview task done";
//
//	//outfile << "\nDo dne";
//
//	return 0;
//
//}
//
//int perform(tag_t *tSignoff, tag_t tTask) {
//
//	bool ch = getBooleanInput();
//
//	switch (ch) {
//
//	case true:
//
//		//checkiFail(EPM_set_signoff_decision(tSignoff[0], EPM_approve_decision, "Approved"));
//
//		//checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_True));
//
//		checkiFail(EPM_set_task_result(tTask, EPM_RESULT_Approved));
//
//		checkiFail(EPM_trigger_action(tTask, EPM_complete_action, "completed signoff task"));
//
//		break;
//
//	case false:
//
//		checkiFail(EPM_set_task_result(tTask, EPM_RESULT_Rejected));
//
//		//checkiFail(EPM_set_signoff_decision(tSignoff[0], EPM_reject_decision, "Rejected"));
//
//		//checkiFail(EPM_set_task_result(tTasks[1], EPM_RESULT_True));
//
//		checkiFail(EPM_trigger_action(tTask, EPM_complete_action, "completed signoff task"));
//
//		break;
//
//	default:
//
//		break;
//
//	}
//
//	return 0;
//
//}
