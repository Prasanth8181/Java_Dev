#include"TCHeader.h"
#include<sa/person.h>


int CreateUserandPerson() {
	tag_t tPerson = NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tGroup = NULLTAG;

	// Create a person with the name "veru"
	checkiFail(SA_create_person2("veru", &tPerson));

	// Save the person without extensions
	AOM_save_without_extensions(tPerson);

	// Create a user with the username "VEERUU" and person "veru"
	checkiFail(SA_create_user2("VEERUU", "veru", "veru", &tUser));

	// Find the group "dba"
	checkiFail(SA_find_group("dba", &tGroup));

	// Check if tPerson, tUser, and tGroup are not NULLTAG
	if (tPerson != NULLTAG && tUser != NULLTAG && tGroup != NULLTAG) {
		// Set the user's login group
		checkiFail(SA_set_user_login_group(tUser, tGroup));

		// Set the OS user name for the user
		checkiFail(SA_set_os_user_name2(tUser, "Vin"));

		// Save the user without extensions
		AOM_save_without_extensions(tUser);
	}
	else {
		// Handle the error case where tPerson, tUser, or tGroup is NULLTAG
		cout<<"Error: tPerson, tUser, or tGroup is NULLTAG"<<endl;
		return -1;
	}

	return 0;
}
































//int CreateUserandPerson()
//{
//
//
//	tag_t tPerson = NULLTAG;
//	tag_t tUser = NULLTAG;
//	tag_t tGroup = NULLTAG;
//
//	checkiFail(SA_create_person2("veru", &tPerson));
//
//	AOM_save_without_extensions(tPerson);
//
//	checkiFail(SA_create_user2("VEERUU", "veru","veru", &tUser));
//	checkiFail(SA_find_group("dba",&tGroup));
//	checkiFail(SA_set_user_login_group(tUser,tGroup));
//	checkiFail(SA_set_os_user_name2(tUser, "Vin"));
//
//	AOM_save_without_extensions(tUser);
//
//	//SA_set_user_person(user, Person);
//	
//
//	return 0;
//}