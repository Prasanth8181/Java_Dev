#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <string>
#include"TCHeader.h"


using namespace std;


int DatasetWithNamedRef() {
	tag_t tDataset = NULLTAG;
	int iFound;
	tag_t *tRef = NULL;
	char *cName = NULL;
	

	// Find the dataset with type "pdf"
	checkiFail(AE_find_dataset2("pdf", &tDataset));

	// Check if tDataset is not NULLTAG
	if (tDataset != NULLTAG) {
		// Get the named references of the dataset
		checkiFail(AE_ask_dataset_named_refs(tDataset, &iFound, &tRef));

		for (int i = 0; i < iFound; i++) {
			// Get the name of the reference
			AOM_ask_name(tRef[i], &cName);
			cout << cName << endl;
		}
	}
	else {
		// Handle the error case where tDataset is NULLTAG
		cout<<"Error: tDataset is NULLTAG"<<endl;
		return -1;
	}

	cout << iFound << endl;

	return 0;
}




























//
//int DatasetWithNamedRef()
//{
//	
//
//	tag_t tDataset = NULLTAG;
//
//	int iFound;
//	tag_t *tRef = NULL;
//
//	char *cName = NULL;
//
//	AE_find_dataset2("pdf", &tDataset);
//
//	AE_ask_dataset_named_refs(tDataset, &iFound, &tRef);  
//	for (int i = 0; i < iFound; i++)
//	{
//		AOM_ask_name(tRef[i], &cName);
//		cout << cName << endl;
//
//	}
//
//	cout << iFound << endl;
//
//	return 0;
//}
//
//

