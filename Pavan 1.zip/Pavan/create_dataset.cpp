//#include<iostream>
//#include<ae/dataset.h>
//#include<ae/datasettype.h>
//#include<tcinit/tcinit.h>
#include"TCHeader.h"


int create_dataset() {
	tag_t tPdftype = NULLTAG;
	tag_t tdata = NULLTAG;

	// Find the dataset type "PDF"
	checkiFail(AE_find_datasettype2("PDF", &tPdftype)); // dataset type

	// Check if tPdftype is not NULLTAG
	if (tPdftype != NULLTAG) {
		// Create the dataset with ID "Pawan"
		checkiFail(AE_create_dataset_with_id(tPdftype, "Pawan", NULL, NULL, NULL, &tdata)); // create dataset

		// Check if tdata is not NULLTAG
		if (tdata != NULLTAG) {
			// Save the dataset
			AE_save_myself(tdata); // save dataset
		}
		else {
			// Handle the error case where tdata is NULLTAG
			cout<<"Error: tdata is NULLTAG"<<endl;
			return -1;
		}
	}
	else {
		// Handle the error case where tPdftype is NULLTAG
		cout <<"Error: tPdftype is NULLTAG"<<endl;
		return -1;
	}

	return 0;
}


















//
//using namespace std;
//
//int create_dataset()
//{
//	
//	tag_t tPdftype = NULLTAG;
//	tag_t tdata=NULLTAG;
//	
//
//	checkiFail(AE_find_datasettype2("PDF", &tPdftype));//dataset type
//
//	checkiFail(AE_create_dataset_with_id(tPdftype, "Pawan", NULL, NULL, NULL, &tdata));//create dataset
//	
//	AE_save_myself(tdata);//save dataset
//	
//	return 0;
//}
