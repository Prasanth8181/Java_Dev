#include"TCHeader.h"
#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include<tccore/grm.h>

using namespace std;

int ItemBaseLineRev()

{

	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tBaseLineRev = NULLTAG, tRelation = NULLTAG;

	char *cChildName = NULL;

	//tag_t tRev;

	const char* desc = "BaselineDesc";

	const char* rel_proc_name = "Custom Process";

	const char* jobName = "Baseline_000572-b_A.001";

	const char* jobDescription = "JobDesc";

	tag_t  new_rev_tag = NULLTAG;

	int deepCopiedObjCount;

	tag_t* deepCopiedObjs;

	int iHits = 0;

	tag_t* tList = NULL;

	// Find items with the name "exp"

	//checkiFail(WSOM_find2("exp", &iHits, &tList));

	// Initialize variables

	int iReferences = 0;

	int* iLevels = nullptr;

	tag_t *tReferences = nullptr, tRelation_type = NULLTAG;

	char** cRelations = nullptr;

	char* cName = nullptr;

	const char *ctopI = ITK_ask_cli_argument("-topI=");

	const char *ctopIR = ITK_ask_cli_argument("-topIR=");

	checkiFail(ITEM_find_item(ctopI, &tTopI));

	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));

	cout << "inside";

	//checkiFail(BOM_create_baseline(NULLTAG, "A.001", "Desc", "TCx Default Baseline Process","Baseline_000473-new_A.001","JobDesc",&tBaseLineRev));

	checkiFail(ITEM_baseline_rev(tTopIR, "A.001", desc, rel_proc_name, jobName, jobDescription, &new_rev_tag, &deepCopiedObjCount, &deepCopiedObjs));

	checkiFail(WSOM_where_referenced2(tTopIR, 1, &iReferences, &iLevels, &tReferences, &cRelations));

	//GRM_find_relation_type("")


	// Iterate through the references and print their names

	for (int i = 0; i < iReferences; i++) {

		checkiFail(GRM_find_relation_type("IMAN_reference", &tRelation_type));

		checkiFail(GRM_create_relation(tReferences[i], new_rev_tag, tRelation_type, NULLTAG, &tRelation));

		checkiFail(AOM_save_without_extensions(tRelation));

		checkiFail(AOM_ask_name(tReferences[i], &cName));

		if (cName != nullptr) {

			cout << cName << endl;

			MEM_free(cName);

		}

	}

	// Free allocated memory

	MEM_free(tReferences);

	MEM_free(iLevels);

	MEM_free(cRelations);

	checkiFail(AOM_save_without_extensions(new_rev_tag));

	return 0;

}
