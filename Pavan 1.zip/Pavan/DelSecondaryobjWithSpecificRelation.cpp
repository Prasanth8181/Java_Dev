//#include <iostream>
//#include<tccore/item.h>
//#include<tccore/grm.h>
//#include<tccore/aom.h>
#include"TCHeader.h"

using namespace std;



int DeleteSecondaryObjectsWithSpecificRelation()
{

	int ifail = 0;
	char * cerror = NULL;
	tag_t revision = NULLTAG;
	tag_t relation_type = NULLTAG;
	int count = 0;
	GRM_relation_t * secondary_list = NULL;
	tag_t class_id = NULLTAG;
	char * class_name = NULL;
	char * value = NULL;

	ifail = ITEM_find_rev("000509", "A", &revision);
	if (ifail == ITK_ok && revision != NULLTAG) 
	{
		cout << "revision found successfully\n";


		ifail = GRM_list_secondary_objects(revision, NULLTAG, &count, &secondary_list);
		cout << count << endl;
		for (int i = 0; i < count; i++)
		{

			AOM_ask_value_string(secondary_list[i].secondary, "object_type", &value);
			cout << value << endl;
			if (tc_strcmp(value, "PDF") == 0)
			{
				GRM_delete_relation(secondary_list[i].the_relation);
				cout << "pdf deleted successfull" << endl;
			}


		}
	}
	else
	{
		char* text = NULL;
		EMH_ask_error_text(ifail, &text);
		cout << text;
	}

	return ifail;

}













































//
//int  DeleteSecondaryObjectsWithSpecificRelation() {
//
//	tag_t tRev = NULLTAG;
//
//	int iCount = 0;
//
//	tag_t* tSecondary_list = NULL, tRtype = NULLTAG;
//
//	char* cName = NULL;
//
//	char* value = NULL;
//
//	// Find the item revision
//
//	checkiFail(ITEM_find_rev("000509", "A", &tRev));
//
//	if (tRev != NULLTAG) {
//
//		// List secondary objects only
//
//		checkiFail(GRM_list_secondary_objects_only(tRev, NULLTAG, &iCount, &tSecondary_list));
//
//		for (int i = 0; i < iCount; i++) {
//
//			checkiFail(AOM_ask_name(tSecondary_list[i], &cName));
//
//			if (cName != NULL) {
//
//				cout << cName << endl;
//
//				MEM_free(cName);
//
//			}
//
//		}
//
//		GRM_find_relation_type("IMAN_specification", &tRtype);
//
//		for (int i = 0; i < iCount; i++) {
//
//			checkiFail(AOM_ask_value_string(tSecondary_list[i], "object_type", &value));
//
//			if (value != NULL && strcmp(value, "PDF") == 0) {
//
//				//checkiFail(AOM_delete_from_parent(tSecondary_list[i], tRev));
//
//				checkiFail(GRM_delete_relation_type(tRtype));
//
//				cout << "inside if" << endl;
//
//				MEM_free(value);
//
//			}
//
//		}
//
//		// Free allocated memory
//
//		MEM_free(tSecondary_list);
//
//	}
//
//	else {
//
//		cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
//
//	}
//
//	return 0;
//
//}
//
//




















































//int DeleteSecondaryObjectsWithSpecificRelation()
//
//{
//	int ifail = 0;
//	char* errMsg;
//	tag_t tRev;
//	ITEM_find_rev("000509", "A", &tRev);
//	int icount;
//	tag_t* secondary_list = NULL;
//	tag_t relation_type = NULLTAG;
//
//	char *cType = NULL;
//
//
//	GRM_find_relation_type("IMAN_Specification",&relation_type);
//	GRM_list_secondary_objects_only(tRev, relation_type, &icount, &secondary_list);
//	for (int i = 0; i < icount; i++)
//	{
//		AOM_ask_value_string(secondary_list[i], "object_type", &cType);
//		if (strcmp(cType, "PDF") == 0)
//		{
//
//			//AOM_delete_from_parent(secondary_list[i], tRev);
//			GRM_delete_relation_type(relation_type);
//
//		}
//		return 0;
//	}
//}