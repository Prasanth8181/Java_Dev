#include <iostream>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <string>
#include"TCHeader.h"
#include<tccore/aom_prop.h>
#include<sa/user.h>
#include<fclasses/tc_string.h>

using namespace std;
int PrintAllDataSetWIthUser()
{
	int iInstances = 0;
	tag_t *tInstances = NULL;
	tag_t tValue = NULLTAG;
	tag_t tUser = NULLTAG;
	char *cValue, *cName;

	checkiFail(AE_dataset_extent(&iInstances, &tInstances));

	cout << tInstances;

	for (int i = 0; i < iInstances; i++) {
		checkiFail(AOM_ask_value_tag(tInstances[i], "owning_user", &tValue));

		if (tValue != NULLTAG && tUser!=NULLTAG) {
			checkiFail(SA_find_user2("izn", &tUser));
			checkiFail(AOM_ask_value_string(tValue, "user_name", &cName));

			if (tValue == tUser) {
				checkiFail(AOM_ask_value_string(tInstances[i], "object_name", &cValue));
				cout << cValue << endl;
			}
		}
	}

	return 0;
}










//int PrintAllDataSetWIthUser()
//
//{
//
//	int iInstances = 0;
//
//	tag_t *tInstances = NULL;
//
//	tag_t tValue = NULLTAG;
//
//	tag_t tUser = NULLTAG;
//
//	char *cValue, *cName;
//
//	checkiFail(AE_dataset_extent(&iInstances, &tInstances));
//
//	cout << tInstances;
//
//	for (int i = 0; i < iInstances; i++) {
//
//		checkiFail(AOM_ask_value_tag(tInstances[i], "owning_user", &tValue));
//
//		checkiFail(SA_find_user2("izn", &tUser));
//
//		checkiFail(AOM_ask_value_string(tValue, "user_name", &cName));
//
//		if ((tValue == tUser)) {
//
//		
//			checkiFail(AOM_ask_value_string(tInstances[i], "object_name", &cValue));
//
//			cout << cValue << endl;
//
//		}
//
//	}
//
//	return 0;
//
//}
//
