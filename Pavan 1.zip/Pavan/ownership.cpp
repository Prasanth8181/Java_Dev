#include<stdio.h>
#include <tccore/aom.h>//set ownership and save without extensions
#include <tccore/item.h>//find item
#include <sa/user.h>//find user
#include <sa/group.h>//find group
#include"TCHeader.h"
#include <iostream>

using namespace std;


int ownership()
{
	// Initialize variables
	tag_t object = NULLTAG;
	tag_t user = NULLTAG;
	tag_t group = NULLTAG;
	tag_t Rev = NULLTAG;

	// Find the item with ID "000501"
	checkiFail(ITEM_find_item("000501", &object));

	// Check if the item tag is not NULLTAG
	if (object != NULLTAG) {
		// Find the user with username "izn"
		checkiFail(SA_find_user2("izn", &user));

		// Check if the user tag is not NULLTAG
		if (user != NULLTAG) {
			// Find the group with name "izn"
			checkiFail(SA_find_group("izn", &group));

			// Check if the group tag is not NULLTAG
			if (group != NULLTAG) {
				// Find the item revision with ID "000501" and revision "A"
				checkiFail(ITEM_find_rev("000501", "A", &Rev));

				// Check if the revision tag is not NULLTAG
				if (Rev != NULLTAG) {
					// Set the ownership of the item to the specified user and group
					checkiFail(AOM_set_ownership(object, user, group));

					// Save the item without extensions
					AOM_save_without_extensions(object);
				}
				else {
					cout << "Error: Item revision not found or revision tag is NULLTAG." << endl;
				}
			}
			else {
				cout << "Error: Group not found or group tag is NULLTAG." << endl;
			}
		}
		else {
			cout << "Error: User not found or user tag is NULLTAG." << endl;
		}
	}
	else {
		cout << "Error: Item not found or item tag is NULLTAG." << endl;
	}

	return 0;
}










































































//int ownership()
//
//{
//
//	tag_t object=NULLTAG;
//	tag_t user=NULLTAG; 
//	tag_t group=NULLTAG;
//	tag_t Rev=NULLTAG;
//
//
//
//	checkiFail(ITEM_find_item("000503", &object));
//
//	checkiFail(SA_find_user2("izn", &user));
//
//	checkiFail(SA_find_group("Engine Design", &group));
//	
//	//checkiFail(ITEM_find_rev("000501", "A", &Rev));
//
//	checkiFail(AOM_set_ownership(object, user, group));
//
//	AOM_save_without_extensions(object);
//
//	return 0;
//
//}
