#include<tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include <tccore/item.h>
#include"TCHeader.h"

using namespace std;

int GlobalAlternate()

{
	int iFail = 0;
	tag_t  tItem1 = NULLTAG, tItem2 = NULLTAG;
	tag_t tFind = NULLTAG, tAddObj = NULLTAG;
	int iCount;

	char *cValue;

	const char *cFind = ITK_ask_cli_argument("-find=");

	const char *cSub1 = ITK_ask_cli_argument("-p1=");

	const char *cSub2 = ITK_ask_cli_argument("-p2=");

	checkiFail(ITEM_find_item(cFind, &tFind));

	checkiFail(ITEM_find_item(cSub1, &tItem1));

	checkiFail(ITEM_find_item(cSub2, &tItem2));

	if (tFind != NULLTAG && tItem1 != NULLTAG && tItem2 != NULLTAG) {
		tag_t tArrItems[] = { tItem1,tItem2 };
		checkiFail(ITEM_add_related_global_alternates(tFind, 2, tArrItems));
		if (tArrItems != NULL) {
			checkiFail(ITEM_prefer_global_alternate(tFind, tArrItems[0]));
		}
	}

	return 0;

}
















































//
//#include<tccore/item.h>
//#include <tccore/aom_prop.h>
//#include <tccore/aom.h>
//#include <tcinit/tcinit.h>
//#include <iostream>
//#include <tccore/item.h>
//#include"TCHeader.h"
//
//using namespace std;
//
//int GlobalAlternate()
//
//{
//
//	int iFail = 0;
//
//	tag_t  tItem1 = NULLTAG, tItem2 = NULLTAG;
//
//	tag_t tFind = NULLTAG, tAddObj = NULLTAG;
//
//	int iCount;
//
//	char *cValue;
//
//	const char *cFind = ITK_ask_cli_argument("-find=");
//
//	ITEM_find_item(cFind, &tFind);
//
//	cout << tFind << endl;
//
//	if (tFind != NULLTAG) {
//
//		ITEM_find_item("000478", &tItem1);
//
//		ITEM_find_item("000479", &tItem2);
//
//		tag_t tArrItems[] = { tItem1,tItem2 };
//
//
//		ITEM_add_related_global_alternates(tFind, 2, tArrItems);
//
//		//AOM_save_without_extensions(tFind);
//
//		ITEM_prefer_global_alternate(tFind, tArrItems[0]);
//
//		//AOM_save_without_extensions(tFind);
//
//	}
//
//
//	return 0;
//
//}
