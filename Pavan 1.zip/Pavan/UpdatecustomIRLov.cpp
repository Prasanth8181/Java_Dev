//Reading two values separated by a comma from a preference and update these values individually to two properties of Custom Item Revision consisting LOV.

#include"TCHeader.h"
#include<tc/preferences.h>


using namespace std;

int UpdatecustomIRLov()
{
	// Initialize variables
	tag_t tRev = NULLTAG;
	char* cValue = NULL;
	char* cValue1 = NULL;

	// Ask for the custom preference value
	checkiFail(PREF_ask_char_value("custompref", 0, &cValue));
	cout << cValue << endl;

	// Tokenize the preference value to get individual values
	char* cPrefValues = strtok(cValue, ",");
	char* val1 = cPrefValues;
	cout << val1 << endl;
	cPrefValues = strtok(NULL, ",");
	char* val2 = cPrefValues;
	cout << val2 << endl;

	// Find the item revision with ID "000471" and revision "A"
	checkiFail(ITEM_find_rev("000471", "A", &tRev));

	// Check if the item revision tag is not NULLTAG
	if (tRev != NULLTAG) {
		// Refresh the item revision
		AOM_refresh(tRev, 1);

		// Set the custom properties with the tokenized values
		checkiFail(AOM_UIF_set_value(tRev, "a2customprop1", val1));
		checkiFail(AOM_UIF_set_value(tRev, "a2customprop2", val2));

		// Save the item revision without extensions
		AOM_save_without_extensions(tRev);

		// Refresh the item revision again
		AOM_refresh(tRev, 0);
	}
	else {
		cout << "Error: Item revision not found or item revision tag is NULLTAG." << endl;
	}

	// Free allocated memory
	MEM_free(cValue);

	return 0;
}






















































//int UpdatecustomIRLov()
//{
//	tag_t tRev = NULLTAG;
//	char* value = ;
//	char* value1;
//
//
//	PREF_ask_char_value("custompref", 0, &value);
//	cout << value << endl;
//	
//	char* cPrefValues = strtok(value, ",");
//	char* val1=cPrefValues;	
//	cout << val1 << endl;
//	cPrefValues = strtok(NULL, ",");
//	char* val2 = cPrefValues;
//	cout << val2 << endl;
//	
//	
//	 ITEM_find_rev("000471", "A", &tRev);
//
//	
//	AOM_refresh(tRev, 1);
//	
//	AOM_UIF_set_value(tRev, "a2customprop1", val1);
//	
//	AOM_UIF_set_value(tRev, "a2customprop2", val2);
//	
//	AOM_save_without_extensions(tRev);
//	
//	AOM_refresh(tRev, 0);
//	
//	
//
//	return 0;
//}










































//
//int UpdatecustomIRLov()
//{
//
//
//	tag_t tRev;
//	char* value;
//	char* value1;
//	/*int ifail1 = 0, ifail2 = 0, ifail3 = 0, ifail4 = 0, ifail5 = 0, ifail6 = 0;
//	char  *err1 = NULL;
//	char *err3 = NULL;
//	char *err2 = NULL;
//	char *err4 = NULL;
//	char *err5 = NULL;
//	char *err6 = NULL;*/
//
//	ifail1=PREF_ask_char_value("custompref", 0, &value);
//	EMH_ask_error_text(ifail1, &err1);
//	cout << "1----"<< err1 << endl;
//	ifail2=PREF_ask_char_value("TC_customization_libraries", 1, &value1);
//	char* cPrefValues=strtok(value1,",");
//	while (cPrefValues != NULL)
//	{
//		cout<<cPrefValues;
//		cPrefValues = strtok(NULL, ",");
//	}
//	/*EMH_ask_error_text(ifail2, &err2);
//	cout << "2----" << err2 << endl;;*/
//	ifail3=ITEM_find_rev("000471", "A", &tRev);
//	EMH_ask_error_text(ifail3, &err3);
//	cout << "3----" << err3 << endl;
//	ifail4 = AOM_refresh(tRev, 0);
//	EMH_ask_error_text(ifail4, &err4);
//	cout << "4----" << err4 << endl;
//	ifail5 = AOM_set_value_string(tRev, "a2customprop1", value);
//	EMH_ask_error_text(ifail5, &err5);
//	cout << "5----" << err5 << endl;
//	/*ifail6 = AOM_set_value_string(tRev, "a2customprop2", value1);*/
//	EMH_ask_error_text(ifail6, &err6);
//	cout << "6----" << err6 << endl;
//	AOM_save_without_extensions(tRev);
//	cout << "7";
//	AOM_refresh(tRev, 1);
//	cout << "8";
//	/*AOM_refresh(tRev, 0);
//	AOM_save_without_extensions(tRev);
//	AOM_refresh(tRev, 1);*/
//
//	return 0;
//}