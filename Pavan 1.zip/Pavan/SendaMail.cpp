#include"TCHeader.h"
#include<tc/envelope.h>



int SendaMail()
{
	// Initialize variables
	tag_t Envelope = NULLTAG;
	tag_t user = NULLTAG;
	tag_t Recevier = NULLTAG;
	tag_t item = NULLTAG;
	tag_t rev = NULLTAG;

	// Create an item with ID "000791", name "item1", type "Item", and revision "A"
	checkiFail(ITEM_create_item("000791", "item1", "Item", "A", &item, &rev));

	// Save the created item
	ITEM_save_item(item);

	// Create an envelope with subject "ITK" and message "check"
	checkiFail(MAIL_create_envelope("ITK", "check", &Envelope));

	// Find the user with username "izn"
	checkiFail(SA_find_user2("izn", &user));

	// Find the user with username "infodba"
	checkiFail(SA_find_user2("infodba", &Recevier));

	// Check if the envelope and users are not NULLTAG
	if (Envelope != NULLTAG && user != NULLTAG && Recevier != NULLTAG) {
		// Add the receiver to the envelope
		MAIL_add_envelope_receiver(Envelope, Recevier);

		// Add the user as a CC receiver to the envelope
		MAIL_add_envelope_cc_receiver(Envelope, user);

		// Insert the item into the envelope
		checkiFail(FL_insert(Envelope, item, 1));

		// Send the envelope
		MAIL_send_envelope(Envelope);
	}
	else {
		cout << "Error: Envelope or user tags are NULLTAG." << endl;
	}

	
	return 0;
}









































//
//
//
//
//int SendaMAil()
//
//{
//	tag_t Envelope = NULLTAG;
//	tag_t user = NULLTAG;
//	tag_t Recevier = NULLTAG;
//
//	tag_t item = NULLTAG;
//	tag_t rev = NULLTAG;
//
//	checkiFail(ITEM_create_item("000791", "item1", "Item", "A", &item, &rev));
//	ITEM_save_item(item);
//
//	checkiFail(MAIL_create_envelope("ITK","check", &Envelope));
//
//	checkiFail(SA_find_user2("izn",&user));
//	checkiFail(SA_find_user2("infodba", &Recevier));
//
//	MAIL_add_envelope_receiver(Envelope, Recevier);
//
//	MAIL_add_envelope_cc_receiver(Envelope, user);
//
//	
//
//	checkiFail(FL_insert(Envelope, item,1));
//
//	MAIL_send_envelope(Envelope);
//
//	return 0;
//
//
//}