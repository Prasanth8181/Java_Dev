#include<tccore/item.h>
#include<ps/ps.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include<tccore/item.h>
#include<string>
#include <iostream>
#include"TCHeader.h"

using namespace std;


int localsubstitute() {
	tag_t tWindow = NULLTAG, tTopI = NULLTAG, tTopIR = NULLTAG, tBomLine = NULLTAG, tSubI = NULLTAG, tSubIR = NULLTAG, *child = NULL, tOut = NULLTAG;
	int count = 0;
	char *childName = NULL;
	const char *ctopI = ITK_ask_cli_argument("-topI=");
	const char *ctopIR = ITK_ask_cli_argument("-topIR=");
	const char *cFind = ITK_ask_cli_argument("-find=");
	const char *cSubI = ITK_ask_cli_argument("-subI=");
	const char *cSubIR = ITK_ask_cli_argument("-subIR=");

	// Find the items and their revisions
	checkiFail(ITEM_find_item(ctopI, &tTopI));
	checkiFail(ITEM_find_rev(ctopI, ctopIR, &tTopIR));
	checkiFail(ITEM_find_item(cSubI, &tSubI));
	checkiFail(ITEM_find_rev(cSubI, cSubIR, &tSubIR));

	if (tTopI != NULLTAG && tTopIR != NULLTAG && tSubI != NULLTAG && tSubIR != NULLTAG) {
		// Create BOM window
		checkiFail(BOM_create_window(&tWindow));

		if (tWindow != NULLTAG) {
			// Set top line for BOM window
			checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));

			if (tBomLine != NULLTAG) {
				// Get all child lines for the BOM line
				checkiFail(BOM_line_ask_all_child_lines(tBomLine, &count, &child));

				for (int i = 0; i < count; i++) {
					checkiFail(AOM_ask_value_string(child[i], "bl_item_item_id", &childName));

					if (strcmp(childName, cFind) == 0) {
						// Add substitute to the BOM line
						checkiFail(BOM_line_add_substitute(child[i], tSubI, tSubIR, NULLTAG, &tOut));

						if (tOut != NULLTAG) {
							checkiFail(AOM_save_without_extensions(tOut));
						}
					}

					if (childName != NULL) {
						MEM_free(childName);
					}
				}

				// Save and close the BOM window
				checkiFail(BOM_save_window(tWindow));
				checkiFail(BOM_close_window(tWindow));

				// Free allocated memory
				MEM_free(child);
			}
		}
	}
	return 0;
}
































//int AddLocalSubstitutetoChild()
//
//{
//
//	    tag_t tWindow = NULLTAG;
//		tag_t tTopI= NULLTAG;
//		tag_t tTopIR= NULLTAG;
//		tag_t tBomLine= NULLTAG;
//		tag_t tSubI= NULLTAG;
//		tag_t tSubIR= NULLTAG;
//		tag_t *child=NULLTAG;
//		tag_t	tOut= NULLTAG;
//	    int count;
//		char *childName = NULL;
//
//	checkiFail(ITEM_find_item("000472", &tTopI));
//
//	checkiFail(ITEM_find_rev("000472", "A", &tTopIR));
//
//	checkiFail(ITEM_find_item("000480", &tSubI));
//
//	checkiFail(ITEM_find_rev("000480", "A", &tSubIR));
//
//	checkiFail(BOM_create_window(&tWindow));
//
//	checkiFail(BOM_set_window_top_line(tWindow, tTopI, tTopIR, NULLTAG, &tBomLine));
//
//	checkiFail(BOM_line_ask_all_child_lines(tBomLine, &count, &child));
//
//	for (int i = 0; i < count; i++) {
//
//		checkiFail(AOM_ask_value_string(child[i], "bl_item_item_id", &childName));
//
//		if (strcmp(childName, "000473") == 0) {
//
//			checkiFail(BOM_line_add_substitute(child[i], tSubI, tSubIR, NULLTAG, &tOut));
//
//		}
//
//	}
//
//	AOM_save_without_extensions(tOut);
//
//	BOM_save_window(tWindow);
//
//	BOM_close_window(tWindow);
//
//	return 0;
//
//}
