#include"TCHeader.h"
//#include<Bom/bom.h>
//#include<ps/ps.h>



int createBom()

{
	tag_t item1, itemRev1, Bomview,Bvr, TopBomLine, item2, itemRev2, item3, itemRev3, NewLine1, NewLine2;


	ITEM_find_item("000472",&item1);
	ITEM_find_rev("000472", "A", &itemRev1);


	PS_create_bom_view(NULLTAG, NULL, NULL, item1, &Bomview);
	AOM_save_without_extensions(Bomview);
	AOM_save_without_extensions(item1);

	PS_create_bvr(Bomview, NULL, NULL, false, itemRev1, &Bvr);
	AOM_save_without_extensions(Bvr);
	AOM_save_without_extensions(itemRev1);

	BOM_create_window(&Bomview);
	AOM_save_without_extensions(Bomview);

	BOM_set_window_top_line(Bomview, item1, itemRev1, NULLTAG,&TopBomLine);
	AOM_save_without_extensions(TopBomLine);


	ITEM_find_item("000473", &item2);
	ITEM_find_rev("000473", "A", &itemRev2);

	ITEM_find_item("000474", &item3);
	ITEM_find_rev("000474", "A", &itemRev3);

	BOM_line_add(TopBomLine, item2, itemRev2, NULLTAG, &NewLine1);
	AOM_save_without_extensions(NewLine1);

	BOM_line_add(TopBomLine, item3, itemRev3, NULLTAG, &NewLine2);
	AOM_save_without_extensions(NewLine2);


	BOM_save_window(Bomview);
	BOM_close_window(Bomview);


	return 0;

}