#include <tcinit/tcinit.h>
#include <bom/bom.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <iostream>
#include"TCHeader.h"


using namespace std;

int BomCompare()
{

	int iFail = 0, iReportLen;

	char **cReportLines=NULL;


	tag_t tTopI1 = NULLTAG;
	tag_t tTopIR1 = NULLTAG;
	tag_t tBomLine1 = NULLTAG;
	tag_t tBomLine2 = NULLTAG;
	tag_t tTopI2 = NULLTAG;
	tag_t tTopIR2 = NULLTAG;
	tag_t *tReportItem = NULLTAG;

	tag_t tWindow1, tWindow2;

	/*const char *username = ITK_ask_cli_argument("-u=");

	const char *password = ITK_ask_cli_argument("-p=");

	const char *group = ITK_ask_cli_argument("-g=");

	iFail = TC_init_module(username, password, group);*/

	ITEM_find_item("000484", &tTopI1);

	ITEM_find_rev("000484", "A", &tTopIR1);

	ITEM_find_item("000165", &tTopI2);

	ITEM_find_rev("000165", "A", &tTopIR2);


	if (tTopI1!=NULLTAG && tTopIR1!=NULLTAG && tTopI2 != NULLTAG && tTopIR2 != NULLTAG){

		BOM_create_window(&tWindow1);

		BOM_create_window(&tWindow2);

		BOM_set_window_top_line(tWindow1, tTopI1, tTopIR1, NULLTAG, &tBomLine1);

		BOM_set_window_top_line(tWindow2, tTopI2, tTopIR2, NULLTAG, &tBomLine2);

		BOM_compare(tBomLine1, tBomLine2, 2, 4);

		BOM_compare_report(NULLTAG, &iReportLen, &cReportLines, &tReportItem);

		cout << iReportLen << endl;

		for (int i = 0; i < iReportLen; i++)

		{

			cout << cReportLines[i] << endl;

		}

		AOM_save_without_extensions(tBomLine1);

		AOM_save_without_extensions(tBomLine2);

		BOM_save_window(tWindow1);

		BOM_save_window(tWindow2);
	}

	

	return 0;

}

